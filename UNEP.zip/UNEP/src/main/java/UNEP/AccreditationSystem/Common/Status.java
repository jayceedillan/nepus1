/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

/**
 * Title: Status.java<br>
 * Description: FIXME Status.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 09, 2018
 */
public enum Status {
    PENDING(0), ACTIVE(1), INACTIVE(2), DELETED(3);

    private final int value;

    private Status(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
