/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

import org.springframework.http.HttpHeaders;

/**
 * Title: AlertResponse.java<br>
 * Description: FIXME AlertResponse.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since November 20, 2017
 */
public class AlertResponse {
    private static HttpHeaders createAlert(String message, String type) {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("X-ATMS-Alert-Message", message);
        httpHeaders.add("X-ATMS-Alert-Type", type);

        return httpHeaders;

    }

    public static HttpHeaders success(String message) {
        return createAlert(message, "success");
    }

    public static HttpHeaders info(String message) {
        return createAlert(message, "info");
    }

    public static HttpHeaders warning(String message) {
        return createAlert(message, "warning");
    }

    public static HttpHeaders error(String message) {
        return createAlert(message, "error");
    }
}
