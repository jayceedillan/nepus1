/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

/**
 * Title: EmailSubjects.java<br>
 * Description: FIXME EmailSubjects.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 05, 2018
 */
public class EmailSubjects {
    public static final String NEWACCREDITATION = "UNEP Accreditation System: New Accreditation -";
    public static final String REMINDER = "Reminder";
}

