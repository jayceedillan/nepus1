/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

import lombok.Data;

/**
 * Title: Pagination.java<br>
 * Description: FIXME Pagination.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 10, 2018
 */

@Data
public class Pagination {
    private String searchQuery = "";
    private Integer pageNumber = 1;
    private String sortBy = "";
    private String order = "ASC";
    private Integer limit = 0;
    private Integer offset = 10;
    private String specialQuery = "";
}
