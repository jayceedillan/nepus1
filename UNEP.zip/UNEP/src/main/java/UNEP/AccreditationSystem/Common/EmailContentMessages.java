/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

import org.springframework.stereotype.Component;

import UNEP.AccreditationSystem.Utilities.PropertyUtil;

/**
 * Title: EmailContentMessages.java<br>
 * Description: FIXME EmailContentMessages.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 22, 2018
 */

@Component
public class EmailContentMessages {

    public String NewUserRegistration(String name, String email, String roleName, String password) {

        return " <p> <strong>Notice of user Registration</strong></p> " + " <p> <strong>Hi " + name + "!</strong></p>  <p> "
                + " &nbsp;</p> <p>  We would like to inform you that you have been registered to the <strong>UNEP ACCREDITATION SYSTEM </strong>with the following credential:</p> "
                + " <p> &nbsp;</p> " + " <ul> " + " <li><span ><span ><strong>Email:" + email + "</strong></span></span></li> "
                + " <li><span ><span ><strong>Role: " + roleName + "</strong></span></span></li> " + " <li><span ><span ><strong>Password: "
                + password + " </strong></span></span></li> " + " </ul> <p> To continue,  <a href=" + PropertyUtil.emailHostIP
                + "/Login>Click here</a></p> " + "<p> Kind Regards,</p> <p> UNEP MGSB </p>";
    }

    public String RecoveryPassword(String name, String email, String roleName, String password) {

        return " <p> <strong>Password Recovery Notice</strong></p> " + " <p> <strong>Hi " + name + "!</strong></p>  <p> "
                + " &nbsp;</p> <p>  We would like to inform you that you have recently requested a password reset with the following credential:</p> "
                + "<p> To reset your password, please use below temporary password:</p> " + " <p> &nbsp;</p> " + " <ul> "
                + " <li><span ><span ><strong>Email:" + email + "</strong></span></span></li> " + " <li><span ><span ><strong>Role: " + roleName
                + "</strong></span></span></li> " + " <li><span ><span ><strong>Password: " + password + " </strong></span></span></li> "
                + " </ul> <p> To continue,  <a href=" + PropertyUtil.emailHostIP + "/Login>Click here</a></p> "
                + "<p> Kind Regards,</p> <p> UNEP MGSB </p>";
    }

    public String Approval(String organization, String remarks, String status) {

        return " <p>  <strong>New Accreditation Notification</strong> </p> "
                + " <p>  Good Day! </p> <p> This is to inform you that a new accreditation is for review: </p>" + " <p>  <strong>Organisation: "
                + organization + " </strong> </p> <p> <strong>Justification: " + remarks + " </strong> </p> " + " <p>  <strong>Approval:" + status
                + "</strong>  </p> <p> &nbsp;</p> " + " <p>   Kind Regards, </p><p> UNEP MGSB</p>";
    }

    public String Approval(String organization, String remarks) {

        return " <p>  <strong>New Accreditation Notification</strong> </p> "
                + " <p>  Good Day! </p> <p> This is to inform you that a new accreditation is for review: </p>" + " <p>  <strong>Organisation: "
                + organization + " </strong> </p> <p> <strong>Justification: " + remarks + " </strong> </p> " + " <p> &nbsp;</p> "
                + " <p>   Kind Regards, </p><p> UNEP MGSB</p>";
    }

    public String followUp(String organization, String message) {

        return " <p>  <strong>Follow Up Accreditation Notification</strong> </p> " + " <p> &nbsp;</p> "
                + " <p>  Good Day! </p> <p> This is to inform you that " + " <strong>" + organization + " </strong>"
                + " would like to follow up their accreditation application.</p>" + " <p> <strong>Organisation: </strong>" + organization + " </p> "
                + " <p> <strong>Message: </strong> </p>" + message + " <p> &nbsp;</p> " + " <p>   Kind Regards, </p><p> " + organization + "</p>";
    }

    public String NewAccreditation() {
        return " <p> <strong>New Accreditation Notification</strong></p> " + " <p>&nbsp;</p> <p> Good Day!</p> <p> &nbsp;</p> "
                + " <p>This is to inform you that a new accreditation is for review:</p>"
                + " <p>&nbsp;</p> <p> &nbsp;</p> <p> Kind Regards,</p> <p> UNEP MGSB</p>";
    }
}
