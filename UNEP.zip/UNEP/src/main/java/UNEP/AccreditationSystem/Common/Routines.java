/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

import java.text.SimpleDateFormat;
import java.util.Date;

import UNEP.AccreditationSystem.Security.SecurityUtil;

/**
 * Title: Routines.java<br>
 * Description: FIXME Routines.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 10, 2018
 */
public class Routines {
    public static String CurrentUser = "Test";
    public static int organization_id = 1;

    public static String imageFolder = "Logo";
    public static String additionalFolder = "AdditionalFolder";
    public static String documentFolder = "documentFolder";
    public static String communicateFolder = "communicateFolder";

    public static String getEkey() {
        return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()).toString();
    }

    public static String getCurrentUser() {
        return SecurityUtil.getCurrentLogin().getUsers().getName();
    }

    public static java.sql.Date getCurrentDate() {
        java.util.Date today = new java.util.Date();
        return new java.sql.Date(today.getTime());
    }

    public class SettingTables {
        public static final String majorGroup = "majorgroup";
        public static final String geographicalScope = "geographicalscope";
        public static final String headquarterOffice = "country";
        public static final String areasOfExpertise = "areaexpertise";
        public static final String crossCuttingAreas = "areacrosscutting";
        public static final String companyCategory = "companycategory";
    }
    
    public class SettingMessages {
        public static final String majorGroup = "Major Group";
        public static final String geographicalScope = "Geographical Scope";
        public static final String headquarterOffice = "Head Quarter Office";
        public static final String areasOfExpertise = "Area Of Expertise";
        public static final String crossCuttingAreas = "Cross Cutting Areas";
        public static final String companyCategory = "Company Category";
    }
}


