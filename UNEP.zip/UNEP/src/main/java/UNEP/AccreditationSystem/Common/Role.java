/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import UNEP.AccreditationSystem.Entities.AuthenticationData;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.Roles;
import UNEP.AccreditationSystem.Entities.Users;
import UNEP.AccreditationSystem.Repository.RolesRepo;
import UNEP.AccreditationSystem.Security.SecurityUtil;
import UNEP.AccreditationSystem.Services.AuthenticationService;

/**
 * Title: Roles.java<br>
 * Description: FIXME Roles.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 18, 2018
 */
@Component
public class Role {


    @Inject
    private RolesRepo rolesRepo;

    @Inject
    private AuthenticationService authenticationService;

    @Inject
    private Role roles;

    public String getEmailByRoles(int id) {

        AuthenticationData authenticationData = SecurityUtil.getCurrentLogin();
        int roleId = 0;
        if (authenticationData.getUsers() != null) {
            roleId = authenticationData.getUsers().getRoles().getId();
        }

        if (roleId == RoleName.AccreditationOfficer.getRoleId()) // accreditation
        {
            OrganizationProfile orgProfile = authenticationService.getDataById(id);

            if (orgProfile != null) {
                return orgProfile.getEmailAddress();
            }
        }

        if (roleId == RoleName.CivilSocietyUnitChief.getRoleId()) // Civil Society Unit Chief
        {
            Roles role = roles.GetOfficersById(RoleName.AccreditationOfficer.getRoleId());
            return role.getEmail();
        }

        if (roleId == RoleName.GovernanceOfficeSecretary.getRoleId()) // Governance Office
                                                                      // Secretary
        {
            Roles role = roles.GetOfficersById(RoleName.CivilSocietyUnitChief.getRoleId());
            return role.getEmail();
        }

        return null;
    }



    public Users getUserRoles() {
        AuthenticationData authenticationData = SecurityUtil.getCurrentLogin();

        return authenticationData.getUsers();
    }


    public int getRoles() {
        AuthenticationData authenticationData = SecurityUtil.getCurrentLogin();
        int roleId = 0;
        if (authenticationData.getUsers() != null) {
            return authenticationData.getUsers().getRoles().getId();
        }

        
        return 0;
    }

    public Roles getRoles(int id) {
        return rolesRepo.GetById(id);
    }

    public Roles GetOfficersById(int Id) {
        return rolesRepo.GetOfficersById(Id);
    }
}
