/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

/**
 * Title: RoleName.java<br>
 * Description: FIXME RoleName.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 18, 2018
 */
public enum RoleName {
    SysAdd(1), AccreditationOfficer(2), CivilSocietyUnitChief(3), GovernanceOfficeSecretary(4);

    private final int RoleId;

    RoleName(int RoleId) {
        this.RoleId = RoleId;
    }

    public int getRoleId() {
        return this.RoleId;
    }
}
