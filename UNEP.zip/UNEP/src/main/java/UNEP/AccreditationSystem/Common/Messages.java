/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

/**
 * Title: Messages.java<br>
 * Description: FIXME Messages.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 16, 2018
 */
public class Messages {

    public static final String INVALID_EMAIL_ADDRESS = "Invalid Email Address";
    public static final String PASSWORD_CHECKING = "Password does not match the confirm password.";
    public static final String PROFILE_SUCCESS = "Profile successfully created.";
    public static final String ERROR_SAVING = "Error's while saving data in the database.";
    public static final String ERROR_SYSTEM = "System error occured. Please try again later.";
    public static final String ERR_HEADER = "Error";
    public static final String ERR_EMAIL = "Email";
    public static final String SUCCESS_HEADER = "SUCCESS.";
    public static final String FAILED_HEADER = "FAILED.";

    public class Registration {
        public static final String SUCCESS_REGISTRATION = "Organization registration successfully saved.";
        public static final String SUCCESS_HEADER = "Successfull.";
        public static final String ERROR_REGISTRATION = "Organization registration failed.";
        public static final String SUCCESS_VERIFY = "Registration verification successful.";
        public static final String ERROR_VERIFY = "Registration verification failed. Verification code may be invalid.";
        public static final String PASSWORD_NOT_CONFIRMED = "Password does not match the confirm password.";
        public static final String EMAIL_ADDRESS_INVALID = "Email address invalid.";
        public static final String EMAIL_ADDRESS_EXIST = "Email address already exists.";
        public static final String VERIFY_HEADER = "Correct Successful Confirmation Message";
        public static final String VERIFY_HEADER_ERR = "Verification failed";
    }

    public class Login {
        public static final String SUCCESS_LOGIN = "Login successful.";
        public static final String ERROR_LOGIN = "Login failed. Email Address or password is invalid.";
        public static final String ERROR_VERIFY = "Your account is not yet activated.";
        public static final String ERROR_LOCKING = "Your account is already locked. Please try again within 5 minutes.";
    }

    public class ForgotPassword {
        public static final String SUCCESS = "Reset password successful. Please check your email.";
        public static final String ERROR = "Reset password failed. Email address not found.";
    }

    public class ChangePassword {
        public static final String SUCCESS = "Password was  successfully changed.";
        public static final String ERROR = "Change password failed. Please try again later.";
        public static final String PASSWORD_NOT_CONFIRMED = "New password does not match the confirm password.";
        public static final String PASSWORD_INCORRECT = "Old password is incorrect.";
        public static final String PASSWORD_FORMAT_INCORRECT =
                "Please provide an alphanumeric password with at least 10 characters, 1 upper case, 1 lower case and 1 special character.";
    }

    public class OrgInfo {
        public static final String ORG_NEW_HEADER = " New Organization Record.";
        public static final String ORG_UPDATE_HEADER = " Update Organization Record.";

        public static final String ORG_SUCCESS = " Organization entry successfully saved.";
        public static final String INT_SUCCESS = " International entry successfully saved.";
        public static final String INT_NEW_HEADER = " New International Record.";
        public static final String INT_UPDATE_HEADER = " Update International Record.";


        public static final String ADD_SUCCESS = " Additional entry successfully saved.";
        public static final String ADD_NEW_HEADER = " New Additional Record.";
        public static final String ADD_UPDATE_HEADER = " Update Additional Record.";

        public static final String ERR_UPLOAD_FILES = "Error during uploading files.";
        public static final String ERR_EMPTY_UPLOAD_FILES = "Please upload file at least one";

        public static final String DOC_SUCCESS = " Document entry successfully uploaded.";
        public static final String DOC_NEW_HEADER = " Document Upload.";
        public static final String RETURN_TO_ORG = " You already return this organization.";
        // public static final String ADD_UPDATE_HEADER = " Update Additional Record.";

        // public static final String ERR_UPLOAD_FILES = "Error during uploading files.";

    }

    public class AccreditationProcess {
        public static final String ACCRED_SUCCESS = " Accreditation Processing entry successfully uploaded.";
    }

    public class User {
        public static final String SUCCESS_USER = "User successfully saved.";
        public static final String DELETE_USER = "User successfully deleted.";
    }

    public class CommunicationOrg {
        public static final String SUCCESS_EMAIL = "Email successfully sent.";

    }

    public class OrganizationApproval {
        public static final String SUCCESS_APPROVAL = "You successfully approved the oranization.";
        public static final String SUCCESS_DISAPPROVAL = "You successfully dis approved the oranization.";

    }
}
