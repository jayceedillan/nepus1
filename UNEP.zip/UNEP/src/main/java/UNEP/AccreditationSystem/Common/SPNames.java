/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

/**
 * Title: SPNames.java<br>
 * Description: FIXME SPNames.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 10, 2018
 */
public final class SPNames {


    public static String AreasOfExpertise = "sp_area_of_expertise_get";
    public static String GeographicalScope = "sp_geographical_scope_get";
    public static String CrossCutttingAreas = "sp_cross_cuttting_areas_get";
    public static String MajorGroup = "sp_major_group_get";
    public static String Country = "sp_country_get";
    public static String CompanyCategory = "sp_companycategory_get";
    public static String Role = "sp_role_get";



}
