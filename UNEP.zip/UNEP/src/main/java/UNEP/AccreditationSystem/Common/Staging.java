/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Common;

/**
 * Title: Staging.java<br>
 * Description: FIXME Staging.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 18, 2018
 */
public enum Staging {
    Accreditation(2), CivilSocietyUnitChief(3), GovernanceOfficeSecretary(4), FinalApprover(4);

    private final int stagingNo;

    Staging(int stagingNo) {
        this.stagingNo = stagingNo;
    }

    public int getStagingNo() {
        return this.stagingNo;
    }
}
