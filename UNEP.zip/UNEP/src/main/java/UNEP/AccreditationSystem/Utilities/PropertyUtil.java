/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Utilities;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Title: Properties.java<br>
 * Description: FIXME Properties.java Description
 *
 * @author: jessie.furigay
 * @author jean.delacruz
 * @version: 1.0
 * @since April 24, 2018
 */

@Component
public class PropertyUtil {

    @Autowired
    private Environment env;

    public static String emailHost;
    public static String emailSender;
    public static String emailPort;
    public static String emailAuth;
    public static String emailUserName;
    public static String emailPassword;
    public static String emailHostIP;
    public static String quartzCronSchedule;

    @PostConstruct
    public void init() {
        emailHost = env.getProperty("email.smtp.host");
        emailSender = env.getProperty("email.smtp.sender");
        emailPort = env.getProperty("email.smtp.port");
        emailAuth = env.getProperty("email.smtp.auth");
        emailUserName = env.getProperty("email.smtp.username");
        emailPassword = env.getProperty("email.smtp.password");
        emailHostIP = env.getProperty("email.smtp.hostIP");
        quartzCronSchedule = env.getProperty("quartz.cron.schedule");
    }

}
