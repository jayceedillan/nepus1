/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Utilities;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Entities.Email;

@Service
public class EmailSender {

    static Properties mailServerProperties;
    static Session getMailSession;
    static MimeMessage generateMailMessage;



    public static String sendEmail(String subject, String contentMessage, String emailAddress) throws AddressException, MessagingException {

        Properties props = new Properties();

        props.put("mail.smtp.host", PropertyUtil.emailHost);
        props.put("mail.smtp.port", PropertyUtil.emailPort);


        Session session = Session.getInstance(props, getAuthenticator());
        try {

            Message message = new MimeMessage(session);

            message.setSentDate(new Date());
            message.setFrom(new InternetAddress(PropertyUtil.emailSender));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailAddress));
            message.setSubject(subject);
            message.setContent(contentMessage, "text/html");

            Transport.send(message);

            return null;

        } catch (MessagingException e) {
            System.out.println(e.getMessage());

            return e.getMessage();
        }
    }

    public static String sendEmail(String subject, String contentMessage, String emailAddress, String bcc)
            throws AddressException, MessagingException {

        Properties props = new Properties();

        props.put("mail.smtp.host", PropertyUtil.emailHost);
        props.put("mail.smtp.port", PropertyUtil.emailPort);


        Session session = Session.getInstance(props, getAuthenticator());
        try {

            Message message = new MimeMessage(session);

            message.setSentDate(new Date());
            message.setFrom(new InternetAddress(PropertyUtil.emailSender));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailAddress));
            message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(bcc));
            message.setSubject(subject);

            message.setContent(contentMessage, "text/html");

            Transport.send(message);

            return null;

        } catch (MessagingException e) {
            System.out.println(e.getMessage());

            return e.getMessage();
        }
    }

    public static String sendEmail(String subject, String contentMessage, String emailAddress, String cc, String bcc, String sourceFile,
            String fileName) throws AddressException, MessagingException, IOException {

        Properties props = new Properties();

        props.put("mail.smtp.host", PropertyUtil.emailHost);
        props.put("mail.smtp.port", PropertyUtil.emailPort);


        Session session = Session.getInstance(props, getAuthenticator());
        try {

            Message message = new MimeMessage(session);

            message.setSentDate(new Date());
            message.setFrom(new InternetAddress(PropertyUtil.emailSender));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailAddress));
            message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(cc));
            message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(bcc));
            message.setSubject(subject);

            MimeBodyPart messagePart = new MimeBodyPart();
            Multipart multipart = new MimeMultipart();

            messagePart.setContent(contentMessage, "text/html");

            if (!sourceFile.isEmpty()) {
                FileDataSource fileDataSource = new FileDataSource(sourceFile);

                MimeBodyPart attachmentPart = new MimeBodyPart();
                attachmentPart.setDataHandler(new DataHandler(fileDataSource));
                attachmentPart.setFileName(fileDataSource.getName());
                multipart.addBodyPart(attachmentPart);
            }

            multipart.addBodyPart(messagePart);
            message.setContent(multipart);

            Transport.send(message);

            return null;

        } catch (MessagingException e) {
            System.out.println(e.getMessage());

            return e.getMessage();
        }
    }

    public static String sendEmail(Email email) throws AddressException, MessagingException {

        Properties props = new Properties();

        props.put("mail.smtp.host", PropertyUtil.emailHost);
        props.put("mail.smtp.port", PropertyUtil.emailPort);


        Session session = Session.getInstance(props, getAuthenticator());
        try {

            Message message = new MimeMessage(session);

            message.setSentDate(new Date());
            message.setFrom(new InternetAddress(email.getSender()));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email.getRecipient()));
            message.setSubject(email.getSubject());
            message.setContent(email.getBody(), "text/html");

            Transport.send(message);

            return null;

        } catch (MessagingException e) {
            System.out.println(e.getMessage());

            return e.getMessage();
        }
    }

    private static Authenticator getAuthenticator() {
        Authenticator authenticator = new Authenticator() {};
        return authenticator;
    }


}
