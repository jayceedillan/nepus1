/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Utilities;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

/**
 * Title: WriteFile.java<br>
 * Description: FIXME WriteFile.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 10, 2018
 */

@Component
public class WriteFile {

    @Autowired
    private Environment env;



    public void CreateFolder() {
        String path = GetPath();
        writeFile(path);
    }

    public void CreateFolder(String FolderName) {
        String path = GetPath() + "/" + FolderName;
        writeFile(path);
    }

    private String GetPath() {
        return env.getProperty("mainFolder") + "/";
    }

    public void writeFile(String path) {
        File file = new File(path);

        if (!file.exists()) {
            file.mkdir();
        }
    }

    public String WriteFiles(MultipartFile[] files) {

        String fileName = null;
        String msg = "";
        if (files != null && files.length > 0) {
            for (int i = 0; i < files.length; i++) {
                try {
                    fileName = files[i].getOriginalFilename();
                    byte[] bytes = files[i].getBytes();
                    BufferedOutputStream buffStream = new BufferedOutputStream(new FileOutputStream(new File(GetPath() + "/" + fileName)));
                    buffStream.write(bytes);
                    buffStream.close();
                    msg += "You have successfully uploaded " + fileName + "<br/>";
                } catch (Exception e) {
                    return "You failed to upload " + fileName + ": " + e.getMessage() + "<br/>";
                }
            }
            return msg;
        } else {
            return "Unable to upload. File is empty.";
        }
    }
}
