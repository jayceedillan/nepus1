/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Title: ConvertImages.java<br>
 * Description: FIXME ConvertImages.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 30, 2018
 */

@Component
public class ConvertImages {

    @Autowired
    private Environment env;


    public void createMainFolder() {

        String path = env.getProperty("mainFolder");
        writeFile(path);
    }

    public void createMainFolder(String Folder) {

        String path = env.getProperty("mainFolder") + "/" + Folder;
        writeFile(path);
    }

    public void writeFile(String path) {
        File file = new File(path);

        if (!file.exists()) {
            file.mkdir();
        }
    }

    public void createImages(String base64, String fileName, String pathName) throws IOException {

        String base64Codes = getBase64Codes(base64);

        System.out.println(getPath() + pathName + "/" + fileName);
        byte[] btDataFile = new sun.misc.BASE64Decoder().decodeBuffer(base64Codes);
        File of = new File(getPath() + pathName + "/" + fileName);
        FileOutputStream osf = new FileOutputStream(of);
        osf.write(btDataFile);
        osf.flush();

    }

    public String getPath() {
        return env.getProperty("mainFolder") + "/";
    }

    public String getBase64Codes(String base64) {
        String getBase64Code[] = base64.split(",");


        if (getBase64Code.length == 1) {
            return getBase64Code[0];
        } else {
            return getBase64Code[1];
        }

    }

    public String convertImagestoBase64(String URLPath) throws IOException {

        String base64Image = encoder(getPath().concat(URLPath));
        return base64Image;
    }

    public static String encoder(String imagePath) {

        String base64Image = "";

        File file = new File(imagePath);

        try (FileInputStream imageInFile = new FileInputStream(file)) {
            byte imageData[] = new byte[(int) file.length()];
            imageInFile.read(imageData);

            base64Image = Base64.getEncoder().encodeToString(imageData);

        } catch (Exception e) {
            // TODO: handle exception
        }

        return base64Image;
    }



}
