package UNEP.AccreditationSystem.Utilities;

import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.DocumentAttach;

public class FileUtility {
	
	public static String getFileExternsion (String filename){
		return filename.substring(filename.lastIndexOf(".") + 1, filename.length());
	}
	
	public static String getContentType(String extension){
		String contentType = "";
		
		if (extension.equalsIgnoreCase("txt")) {
            contentType = "text/html";
        } else if (extension.equalsIgnoreCase("doc")) {
        	contentType = "application/msword";
        } else if (extension.equalsIgnoreCase("pdf")) {
        	contentType = "application/pdf";
        } else if (extension.equalsIgnoreCase("jpg")) {
        	contentType = "image/jpeg";
        } else if (extension.equalsIgnoreCase("jpeg")) {
        	contentType = "image/jpeg";
        }
		
		return contentType;
	}
	
	public static String getFilePath(String mainfolder, DocumentAttach document){
		String folder = "";
		if (document.getType().equalsIgnoreCase("additional")){
			folder = Routines.additionalFolder;
		} else if (document.getType().equalsIgnoreCase("documents")){
			folder = Routines.documentFolder;
		}
		return mainfolder + folder + "/" + document.getId() + "/" + document.getName();
	}
}
