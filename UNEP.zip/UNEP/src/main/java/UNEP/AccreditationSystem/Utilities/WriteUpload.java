/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Utilities;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import UNEP.AccreditationSystem.Common.Routines;



/**
 * Title: WriteUpload.java<br>
 * Description: FIXME WriteUpload.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 01, 2018
 */
@Component
public class WriteUpload {

    @Inject
    private ConvertImages convertImages;

    @Inject
    private Environment env;

    public boolean writeAdditionalFiles(MultipartFile[] file, String folderName, int organizationId) {

        try {
            convertImages.createMainFolder();
            convertImages.createMainFolder(folderName);
            convertImages.createMainFolder(folderName + "/" + organizationId);
           
            if (file != null && file.length > 0) {
 String path = env.getProperty("mainFolder") + "/" + folderName + "/" + organizationId + "/";
                for (MultipartFile multipartFile : file) {
                    String fileName = null;
                    fileName = multipartFile.getOriginalFilename();
                    byte[] bytes = multipartFile.getBytes();
                    BufferedOutputStream buffStream = new BufferedOutputStream(new FileOutputStream(new File(path + fileName)));
                    buffStream.write(bytes);
                    buffStream.close();
                }
            }

        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
        }
        return false;
    }

    public boolean writeAdditionalFiles(MultipartFile file, String folderName, int organizationId) {

        try {
            convertImages.createMainFolder();
            convertImages.createMainFolder(folderName);
            convertImages.createMainFolder(folderName + "/" + Routines.organization_id);
            String path = env.getProperty("mainFolder") + "/" + folderName + "/" + organizationId + "/";
            if (file != null) {

                String fileName = null;
                fileName = file.getOriginalFilename();
                byte[] bytes = file.getBytes();
                BufferedOutputStream buffStream = new BufferedOutputStream(new FileOutputStream(new File(path + fileName)));
                buffStream.write(bytes);
                buffStream.close();

            }

        } catch (Exception e) {
            // TODO: handle exception
        }
        return false;
    }
}
