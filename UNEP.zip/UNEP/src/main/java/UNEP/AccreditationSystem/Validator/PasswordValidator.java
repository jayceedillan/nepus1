package UNEP.AccreditationSystem.Validator;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.Users;
import UNEP.AccreditationSystem.Repository.OrganizationProfileRepo;
import UNEP.AccreditationSystem.Security.SecurityUtil;
import UNEP.AccreditationSystem.Services.UsersService;

/**
 * Copyright (c) ADEC Innovations Inc. 2018. All Rights Reserved.
 *
 * SDT DEV Team
 *
 * @author jean.delacruz
 * @version: 1.0
 * @since Jun 11, 2018
 */

@Service
public class PasswordValidator {

    @Inject
    OrganizationProfileRepo orgProfileRepo;

    @Inject
    private UsersService usersService;

    private static String alphaNumRegex = "a-zA-Z0-9";
    private static String specialNumListRegex = "_@!./#()&^$=%*+-";

    public String validate(String oldPassword, String newPassword, String confirmPassword) {
        if (!this.isOldPasswordCheck(oldPassword)) {
            return Messages.ChangePassword.PASSWORD_INCORRECT;
        }

        if (!this.isNewPasswordConfirmed(newPassword, confirmPassword)) {
            return Messages.ChangePassword.PASSWORD_NOT_CONFIRMED;
        }

        if (!isAlphaNumericWithUpperCase(newPassword)) {
            return Messages.ChangePassword.PASSWORD_FORMAT_INCORRECT;
        }

        return null;
    }

    private boolean isNewPasswordConfirmed(String newPassword, String confirmPassword) {
        return newPassword.equals(confirmPassword);
    }

    private boolean isOldPasswordCheck(String oldPassword) {
        OrganizationProfile orgProfile = null;
        boolean valid = true;

        try {

            if (SecurityUtil.getCurrentLogin().getOrganizationProfile() != null) {
                OrganizationProfile orgSession = SecurityUtil.getCurrentLogin().getOrganizationProfile();

                orgProfile = orgProfileRepo.getDataByAuthentication(orgSession.getEmailAddress(), oldPassword);

                if (orgProfile == null) {
                    valid = false;
                }
            }

            if (SecurityUtil.getCurrentLogin().getUsers() != null) {
                Users user = SecurityUtil.getCurrentLogin().getUsers();
                user = usersService.getData(user.getEmail(), oldPassword, 0);

                if (user == null) {
                    valid = false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return valid;
    }

    /**
     * checks if password followed the current password policy which states that password should
     * contain the ff:
     * 
     * 1. alphanumeric 2. special character 3. combination of both lower and upper case letters
     * 
     * @param password
     * @return boolean
     */
    public static boolean isAlphaNumericWithUpperCase(String password) {

        if (password.matches(
                "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[" + specialNumListRegex + "])[" + alphaNumRegex.concat(specialNumListRegex) + "]{10,}+$")) {
            return true;
        } else {
            return false;
        }
    }
}


