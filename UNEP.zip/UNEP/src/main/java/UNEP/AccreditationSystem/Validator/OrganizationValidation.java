/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Validator;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Common.Role;
import UNEP.AccreditationSystem.Common.RoleName;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.TrackingApplication;
import UNEP.AccreditationSystem.Repository.OrganizationProfileRepo;
import UNEP.AccreditationSystem.Services.TrackingApplicationService;

/**
 * Title: Validate.java<br>
 * Description: FIXME Validate.java Description
 *
 * @author: jessie.furigay
 * @author jean.delacruz
 * @version: 1.0
 * @since May 16, 2018
 */

@Service
public class OrganizationValidation {

    @Inject
    OrganizationProfileRepo orgProfileRepo;

    @Inject
    private TrackingApplicationService trackingApplicationService;

    @Inject
    private Role role;

    public String validate(OrganizationProfile organizationProfile) {
        if (!isEmailAddressValid(organizationProfile.getEmailAddress())) {
            return Messages.Registration.EMAIL_ADDRESS_INVALID;
        }

        if (isEmailAddressExist(organizationProfile.getEmailAddress())) {
            return Messages.Registration.EMAIL_ADDRESS_EXIST;
        }

        if (!isPasswordCheck(organizationProfile.getPassword(), organizationProfile.getConfirmPassword())) {
            return Messages.Registration.PASSWORD_NOT_CONFIRMED;
        }

        if (!PasswordValidator.isAlphaNumericWithUpperCase(organizationProfile.getPassword())) {
            return Messages.ChangePassword.PASSWORD_FORMAT_INCORRECT;
        }

        return null;
    }

    public boolean isEmailAddressValid(String emailAddress) {
        String EMAIL_REGEX =
                "^(([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";

        return !(emailAddress != null && emailAddress.trim().length() > 0) || emailAddress.matches(EMAIL_REGEX);
    }

    public boolean isEmailAddressExist(String emailAddress) {
        OrganizationProfile orgProfile = orgProfileRepo.getDataByEmailAddress(emailAddress);

        if (orgProfile == null) {
            return false;
        } else {
            return true;
        }
    }

    public boolean isPasswordCheck(String password, String confirmPassword) {
        return password.equals(confirmPassword);
    }

    public String allowedApproval(int id) {

        TrackingApplication trackingApplication = trackingApplicationService.getTrackingApp(id, 1, "");

        int stageNo = trackingApplication.getStageNo();

        int roleId = role.getRoles();

        if (roleId == RoleName.CivilSocietyUnitChief.getRoleId() && stageNo == 4) {
            return "This organization is already approved by secretary";
        }

        if (roleId == RoleName.GovernanceOfficeSecretary.getRoleId() && stageNo == 3) {
            return "This organization is not yet approved by the chief";
        }

        return null;
    }
}
