/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Validator;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.Role;
import UNEP.AccreditationSystem.Common.RoleName;
import UNEP.AccreditationSystem.Entities.TrackingApplication;
import UNEP.AccreditationSystem.Services.TrackingApplicationService;

/**
 * Title: AccreditationValidator.java<br>
 * Description: FIXME AccreditationValidator.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 18, 2018
 */

@Service
public class AccreditationValidator {

    @Inject
    private TrackingApplicationService trackingApplicationService;

    @Inject
    private Role role;

    public String isValid(int id) {

        TrackingApplication trackingApplication = trackingApplicationService.getTrackingApp(id, 1, "");

        int roleId = role.getRoles();

        if (roleId == RoleName.AccreditationOfficer.getRoleId()) {
            if (trackingApplication.getStageNo() == 3 || trackingApplication.getStageNo() == 4) {
                return "Governance Office Secretary is already approved";
            }
        }
        if (roleId == RoleName.CivilSocietyUnitChief.getRoleId()) {
            if (trackingApplication.getStageNo() == 4) {
                return "Governance Office Secretary is already approved";
            }
        }

        else if (roleId == RoleName.GovernanceOfficeSecretary.getRoleId()) {
            if (trackingApplication.getStageNo() == 1) {
                return "Accreditation Officer is not yet approve";
            }
        }

        return null;
    }
}
