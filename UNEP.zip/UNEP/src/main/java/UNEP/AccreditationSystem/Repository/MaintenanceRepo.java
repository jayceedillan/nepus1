package UNEP.AccreditationSystem.Repository;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import UNEP.AccreditationSystem.Entities.Maintenance;
import UNEP.AccreditationSystem.IRepository.ICommonRepo;
import UNEP.AccreditationSystem.Mapper.MaintenanceMapper;

/**
 * Copyright (c) ADEC Innovations Inc. 2018. All Rights Reserved.
 *
 * SDT DEV Team
 *
 * @author jean.delacruz
 * @version: 1.0
 * @since May 30, 2018
 */

@Transactional(readOnly = false)
@Repository
public class MaintenanceRepo extends JdbcDaoSupport implements ICommonRepo<Maintenance> {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    @Override
    public Maintenance getDataById(int id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Maintenance getDataByName(String name) {
        try {
            final String sql = "call sp_maintenance_getbyname (?)";

            return getJdbcTemplate().queryForObject(sql, new MaintenanceMapper(), name);
        } catch (Exception e) {
            // TODO: handle exception
            return new Maintenance();
        }

    }

    @Override
    public boolean add(Maintenance orgProfile) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean update(Maintenance obj) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean delete(int id) {
        // TODO Auto-generated method stub
        return false;
    }
}


