/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.AdditionalInfo;
import UNEP.AccreditationSystem.Entities.DocumentsUploads;
import UNEP.AccreditationSystem.Entities.MultiSelect;
import UNEP.AccreditationSystem.IRepository.MyBase;
import UNEP.AccreditationSystem.Mapper.AdditionalInfoMapper;
import UNEP.AccreditationSystem.Mapper.DocumentsUploadsMapper;
import UNEP.AccreditationSystem.Mapper.MultiSelectMapper;


/**
 * Title: AdditionalInfoRepo.java<br>
 * Description: FIXME AdditionalInfoRepo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 01, 2018
 */

@Repository
public class AdditionalInfoRepo extends JdbcDaoSupport implements MyBase<AdditionalInfo> {

    @Inject
    private DataSource dataSource;


    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    @Override
    public int saveData(AdditionalInfo dataItems) throws SQLException, IOException {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_organization_additionalinfo_add (?,?,?,?,?,?,?,?,?,?,?,?)";

            Connection connection;
            connection = getJdbcTemplate().getDataSource().getConnection();
            CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

            ps.setInt(1, Routines.organization_id);
            ps.setDate(2, dataItems.getRegistrationdate());
            ps.setInt(3, dataItems.getCountry().getId());
            ps.setInt(4, dataItems.getCompanyCategory().getId());
            ps.setString(5, dataItems.getCompanycategoryother());
            ps.setBoolean(6, dataItems.isIsnetworkmember1());
            ps.setString(7, dataItems.getDocument1());
            ps.setString(8, dataItems.getRemarks1());
            ps.setBoolean(9, dataItems.isIsnetworkmember2());
            ps.setString(10, dataItems.getDocument2());
            ps.setString(11, dataItems.getRemarks2());
            ps.setString(12, dataItems.getFundsource());

            ps.executeQuery();
            return 1;
        } catch (Exception e) {
            // TODO: handle exception
            return 0;
        }
    }

    @Override
    public AdditionalInfo getData(String Name, String Status) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public AdditionalInfo getData(int Id, String Status) throws IOException {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_organization_additionalinfo_get (?,?)";

            return getJdbcTemplate().queryForObject(sql, new AdditionalInfoMapper(), Id, Status);
        } catch (Exception e) {
            // TODO: handle exception
            return new AdditionalInfo();
        }
    }

    @Override

    public List<AdditionalInfo> getData(Pagination pagination) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int totalRows(Pagination pagination) {
        // TODO Auto-generated method stub
        return 0;
    }

    public int saveAdditionalUploads(String constitution, String financialreport) {
        try {
            final String sql = "call sp_organization_document_add (?,?,?)";

            Connection connection;
            connection = getJdbcTemplate().getDataSource().getConnection();
            CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

            ps.setInt(1, Routines.organization_id);
            ps.setString(2, constitution);
            ps.setString(3, financialreport);

            ps.executeQuery();
            return 1;
        } catch (Exception e) {
            // TODO: handle exception
            return 0;
        }
    }


    public int updateDocumentOtherUploads() {
        try {
            final String sql = "call sp_organization_documentother_update (?)";

            Connection connection;
            connection = getJdbcTemplate().getDataSource().getConnection();
            CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

            ps.setInt(1, Routines.organization_id);

            ps.executeQuery();
            return 1;
        } catch (Exception e) {
            // TODO: handle exception
            return 0;
        }
    }

    public int saveDocumentOtherUploads(String fileName) {
        try {
            final String sql = "call sp_organization_documentother_add (?,?)";

            Connection connection;
            connection = getJdbcTemplate().getDataSource().getConnection();
            CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

            ps.setInt(1, Routines.organization_id);
            ps.setString(2, fileName);
            ps.executeQuery();
            return 1;
        } catch (Exception e) {
            // TODO: handle exception
            return 0;
        }
    }
    
	 public   DocumentsUploads getDocumentsUploads(int id) {
		 try {
	            final String sql = "call sp_organization_documentuploads_get (?)";

	            return getJdbcTemplate().queryForObject(sql, new DocumentsUploadsMapper(), id);
	        } catch (Exception e) {
	            // TODO: handle exception
	            return new DocumentsUploads();
	        } 
	 }

	 public   List<MultiSelect> getDocumentsOthers(int id) {
		 try {
	            final String sql = "call sp_organization_documentother_get (?)";

	            return getJdbcTemplate().query(sql, new MultiSelectMapper(), id);
	        } catch (Exception e) {
	            // TODO: handle exception
	            return null;
	        } 
	 }
	 
	 
	 


}
