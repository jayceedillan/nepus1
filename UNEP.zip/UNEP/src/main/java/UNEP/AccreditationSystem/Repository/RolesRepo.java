/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Entities.Roles;
import UNEP.AccreditationSystem.Mapper.RolesMapper;

/**
 * Title: Roles.java<br>
 * Description: FIXME Roles.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 23, 2018
 */

@Repository
public class RolesRepo extends JdbcDaoSupport {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public Roles GetById(int Id) {

        final String sql = "call sp_roles_get_by_id (?)";

        return getJdbcTemplate().queryForObject(sql, new RolesMapper(), Id);

    }

    public Roles GetOfficersById(int Id) {

        final String sql = "call sp_officers_emails_get (?)";

        return getJdbcTemplate().queryForObject(sql, new RolesMapper(), Id);

    }
}
