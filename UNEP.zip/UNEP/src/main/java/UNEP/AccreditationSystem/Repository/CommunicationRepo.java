/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Entities.Communicate;
import UNEP.AccreditationSystem.Mapper.CommunicateMapper;

/**
 * Title: CommunicationOrgRepo.java<br>
 * Description: FIXME CommunicationOrgRepo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 18, 2018
 */

@Repository
public class CommunicationRepo extends JdbcDaoSupport {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public int saveCommunicateOrg(Communicate communicateOrg) {
        try {
            final String sql = "call sp_organization_communicate_add (?,?,?,?,?,?)";
            return getJdbcTemplate().update(sql, communicateOrg.getOrganization_id(), communicateOrg.getSubject(), communicateOrg.getContent(),
                    communicateOrg.getAttach() == "" ? "NULL" : communicateOrg.getAttach(), communicateOrg.getFrom_role_id(),
                    communicateOrg.getTo_role_id() == 0 ? null : communicateOrg.getTo_role_id());

        } catch (Exception e) {
            System.out.println(e.getMessage());
            // TODO: handle exception
        }
        return 0;
    }

    // sp_organization_communication_get
    public List<Communicate> getCommunicate(int id) {
        final String sql = "call sp_organization_communication_get(?)";

        return getJdbcTemplate().query(sql, new CommunicateMapper(), id);
    }

    public List<Communicate> getCommunicateSubjects(int id, int roleId) {
        final String sql = "call sp_organization_communication_subject_get(?,?)";

        return getJdbcTemplate().query(sql, new CommunicateMapper(), id, roleId);
    }


}
