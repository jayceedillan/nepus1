package UNEP.AccreditationSystem.Repository;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.Users;
import UNEP.AccreditationSystem.IRepository.MyBase;
import UNEP.AccreditationSystem.Mapper.UsersMapper;

@Repository
public class UsersRepo extends JdbcDaoSupport implements MyBase<Users> {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }


    @Override
    public int saveData(Users dataItems) throws SQLException, IOException {
        // TODO Auto-generated method stub
        try {

            final String sql = "call sp_users_add (?,?,?,?,?,?,?,?)";

            Connection connection;
            connection = getJdbcTemplate().getDataSource().getConnection();
            CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

            boolean istemp = dataItems.getId() == 0 ? false : true;
            istemp = dataItems.getPassword() == null ? true : istemp;

            ps.setInt(1, dataItems.getId());
            ps.setString(2, dataItems.getName());
            ps.setString(3, Routines.getEkey());
            ps.setString(4, dataItems.getPassword());
            ps.setString(5, dataItems.getEmail());
            ps.setInt(6, dataItems.getRoles().getId());
            ps.setBoolean(7, istemp);
            ps.setInt(8, dataItems.getChangePassword());

            ps.executeQuery();

            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            // TODO: handle exception
        }

        return 0;
    }

    @Override
    public Users getData(String Name, String Status) {
        // TODO Auto-generated method stub

        try {
            final String sql = "call sp_user_email_exist (?)";

            return getJdbcTemplate().queryForObject(sql, new UsersMapper(), Name);
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
            return new Users();
        }
    }

    @Override
    public Users getData(int Id, String Status) throws IOException {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_users_get_by_id (?,?)";

            return getJdbcTemplate().queryForObject(sql, new UsersMapper(), Id, Status);
        } catch (Exception e) {
            // TODO: handle exception
            return new Users();
        }
    }

    public Users getData(String email, String password, int y) throws IOException {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_users_get_by_email_password (?,?)";

            return getJdbcTemplate().queryForObject(sql, new UsersMapper(), email, password);
        } catch (Exception e) {
            // TODO: handle exception
            return new Users();
        }
    }

    @Override
    public List<Users> getData(Pagination pagination) {
        // TODO Auto-generated method stub
        final String sql = "call sp_users_get (?,?,?,?,?)";

        return getJdbcTemplate().query(sql, new UsersMapper(), pagination.getSearchQuery(), pagination.getSortBy(), pagination.getOrder(),
                pagination.getLimit(), pagination.getOffset());
    }

    @Override
    public int totalRows(Pagination pagination) {
        // TODO Auto-generated method stub
        final String sql = "call sp_users_count (?)";
        return getJdbcTemplate().queryForObject(sql, Integer.class, pagination.getSearchQuery());
    }

    public int updateStatus(int id, String status) {
        try {
            final String sql = "call sp_users_update (?,?)";

            return getJdbcTemplate().update(sql, id, status);

        } catch (Exception e) {
            // TODO: handle exception
            return 0;
        }
    }
}
