package UNEP.AccreditationSystem.Repository;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Entities.AuthenticationData;
import UNEP.AccreditationSystem.Entities.DocumentAttach;
import UNEP.AccreditationSystem.Entities.extend.Accreditation;
import UNEP.AccreditationSystem.Mapper.DocumentAttachMapper;
import UNEP.AccreditationSystem.Security.SecurityUtil;

@Repository
public class AccreditationProcessRepo extends JdbcDaoSupport {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public List<DocumentAttach> getAccreditationDocuments(int id) {
        try {
            final String sql = "call sp_organization_accreditation_get (?)";

            return getJdbcTemplate().query(sql, new DocumentAttachMapper(), id);
        } catch (Exception e) {
            // TODO: handle exception
            return null;
        }
    }

    public int SaveAccreditationProcess(int id, Accreditation documentAttach) {

        try {

            AuthenticationData authenticationData = SecurityUtil.getCurrentLogin();

            final String sqlUpdate = "call sp_organization_accreditation_update (?,?)";
            getJdbcTemplate().update(sqlUpdate, id, authenticationData.getUsers().getName());

            final String sqlAdd = "call sp_organization_accreditation_recommendation_add (?,?)";
            getJdbcTemplate().update(sqlAdd, id, documentAttach.getContent());


            final String sql = "call sp_organization_accreditation_add (?,?,?,?)";
            getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {

                @Override
                public void setValues(java.sql.PreparedStatement ps, int i) throws SQLException {

                    DocumentAttach DocumentAttach = documentAttach.getDocumentAttach().get(i);

                    ps.setInt(1, id);
                    ps.setString(2, DocumentAttach.getName());
                    ps.setBoolean(3, DocumentAttach.isDecision());
                    ps.setString(4, authenticationData.getUsers().getName());
                }

                @Override
                public int getBatchSize() {
                    return documentAttach.getDocumentAttach().size();
                }
            });

            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            // TODO: handle exception
        }
        return 0;
    }

    public String getRecommendation(int id) {
        try {
            final String sql = "call sp_organization_accreditation_recommendation_get (?)";

            String recommendationContent = (String) getJdbcTemplate().queryForObject(sql, new Object[] {id}, String.class);

            return recommendationContent;

        } catch (Exception e) {
            // TODO: handle exception
            return null;
        }
    }
}
