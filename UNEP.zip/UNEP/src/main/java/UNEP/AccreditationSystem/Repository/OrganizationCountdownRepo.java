/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.Mapper.CountdownMapper;

/**
 * Title: OrganizationCountdown.java<br>
 * Description: FIXME OrganizationCountdown.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 06, 2018
 */

@Repository
public class OrganizationCountdownRepo extends JdbcDaoSupport {
    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }



    public List<OrganizationInfo> get10DaysCountdown() {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_organization_countdown_get()";

            return getJdbcTemplate().query(sql, new CountdownMapper());

        } catch (Exception e) { // TODO: handle exception
            System.out.println(e.getMessage());
        }

        return null;
    }

    public List<OrganizationInfo> get30DaysCountdown() {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_organization_countdown_30days()";

            return getJdbcTemplate().query(sql, new CountdownMapper());

        } catch (Exception e) { // TODO: handle exception
            System.out.println(e.getMessage());
        }

        return null;
    }

    public int organization_deleted(int trackingId, int organizationId) {
        try {
            final String sql = "call sp_organization_delete (?,?)";

            return getJdbcTemplate().update(sql, trackingId, organizationId);

        } catch (Exception e) {
            // TODO: handle exception
            return 0;
        }
    }
}
