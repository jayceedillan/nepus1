/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Entities.Dashboard;
import UNEP.AccreditationSystem.Mapper.DashboardMapper;

/**
 * Title: DashboardRepo.java<br>
 * Description: FIXME DashboardRepo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 27, 2018
 */

@Repository
public class DashboardRepo extends JdbcDaoSupport {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public Dashboard getDashboard() {

        final String sql = "call sp_dashboard_get";

        return getJdbcTemplate().queryForObject(sql, new DashboardMapper());
    }

}
