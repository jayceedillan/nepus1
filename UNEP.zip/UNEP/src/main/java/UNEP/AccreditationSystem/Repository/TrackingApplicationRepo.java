/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import java.sql.CallableStatement;
import java.sql.Connection;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.TrackingApplication;
import UNEP.AccreditationSystem.Mapper.TrackingApplicationMapper;

/**
 * Title: TrackingApplicationRepo.java<br>
 * Description: FIXME TrackingApplicationRepo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 05, 2018
 */

@Repository
public class TrackingApplicationRepo extends JdbcDaoSupport {

    @Inject
    private DataSource dataSource;


    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }


    public int saveAppTracking(int id, String status, String remarks, int stageNo) {
        try {
            final String sql = "call sp_organization_applicationtracking_update (?,?,?,?,?,?)";

            Connection connection;
            connection = getJdbcTemplate().getDataSource().getConnection();
            CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

            ps.setInt(1, id);
            ps.setDate(2, Routines.getCurrentDate());
            ps.setInt(3, stageNo);
            ps.setString(4, status);
            ps.setString(5, remarks);
            ps.setString(6, Routines.CurrentUser);
            ps.executeQuery();
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }

    public TrackingApplication getTrackingApp(int id, int stageNo, String stageQuery) {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_organization_applicationtracking_get (?,?,?)";

            return getJdbcTemplate().queryForObject(sql, new TrackingApplicationMapper(), id, stageNo, stageQuery);
        } catch (Exception e) {
            // TODO: handle exception
            return new TrackingApplication();
        }

    }

    private java.sql.Date getCurrentDate() {
        java.util.Date today = new java.util.Date();
        return new java.sql.Date(today.getTime());
    }

    public int saveFollowUp(int id, String content) {
        try {
            final String sql = "call sp_organization_complain_add (?,?)";

            Connection connection;
            connection = getJdbcTemplate().getDataSource().getConnection();
            CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

            ps.setInt(1, id);
            ps.setString(2, content);

            ps.executeQuery();
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }
}
