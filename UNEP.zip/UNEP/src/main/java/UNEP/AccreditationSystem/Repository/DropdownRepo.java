/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Entities.MultiSelect;
import UNEP.AccreditationSystem.IRepository.IDropdown;
import UNEP.AccreditationSystem.Mapper.MultiSelectMapper;

/**
 * Title: DropdownRepo.java<br>
 * Description: FIXME DropdownRepo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 10, 2018
 */

@Repository
public class DropdownRepo extends JdbcDaoSupport implements IDropdown<MultiSelect> {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }


    @Override
    public List<MultiSelect> getData(String spName) {
        // TODO Auto-generated method stub
        final String sql = "call " + spName;

        return getJdbcTemplate().query(sql, new MultiSelectMapper());
    }

    @Override
    public MultiSelect getData(int Id, String spName) {
        // TODO Auto-generated method stub
        return null;
    }

}
