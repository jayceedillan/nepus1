/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.support.TransactionTemplate;

import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.AccreditationList;
import UNEP.AccreditationSystem.Entities.CommonModel;
import UNEP.AccreditationSystem.Entities.InternationalScope;
import UNEP.AccreditationSystem.Entities.MultiSelect;
import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.IRepository.MyBase;
import UNEP.AccreditationSystem.Mapper.AccreditationListMapper;
import UNEP.AccreditationSystem.Mapper.CommonModelMapper;
import UNEP.AccreditationSystem.Mapper.OrganizationInfoMapper;
import UNEP.AccreditationSystem.Utilities.ConvertImages;


/**
 * Title: OrganizationInfoRepo.java<br>
 * Description: FIXME OrganizationInfoRepo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 29, 2018
 */

@Repository
public class OrganizationInfoRepo extends JdbcDaoSupport implements MyBase<OrganizationInfo> {

    @Inject
    private DataSource dataSource;

    @Inject
    private TransactionTemplate transactionTemplate;

    @Inject
    private ConvertImages convertImages;


    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }


    @Override
    public int saveData(OrganizationInfo dataItems) throws SQLException, IOException {
        // TODO Auto-generated method stub

        writeImages(dataItems.getFilesInfo().getFileName(), dataItems.getFilesInfo().getContent());
        System.out.println(dataItems.getFilesInfo().getFileName());
        try {
            final String sql = "call sp_organization_info_add (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            Connection connection;
            connection = getJdbcTemplate().getDataSource().getConnection();
            CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

            ps.setInt(1, Routines.organization_id);
            ps.setString(2, dataItems.getFormername());
            ps.setString(3, dataItems.getAcronym());
            ps.setInt(4, dataItems.getMajorgroup().getId());
            ps.setString(5, dataItems.getPostaladdress());
            ps.setString(6, dataItems.getPostalzipcode());
            ps.setString(7, dataItems.getCity());
            ps.setString(8, dataItems.getWebSite());
            ps.setInt(9, dataItems.getCountry().getId());
            ps.setString(10, dataItems.getFilesInfo().getFileName());
            ps.setString(11, dataItems.getFirstname1());
            ps.setString(12, dataItems.getLastname1());
            ps.setString(13, dataItems.getEmail1());
            ps.setString(14, dataItems.getDesignation1());
            ps.setString(15, dataItems.getFirstname2());
            ps.setString(16, dataItems.getLastname2());
            ps.setString(17, dataItems.getEmail2());
            ps.setString(18, dataItems.getDesignation2());

            ps.executeQuery();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            // TODO: handle exception
            return 0;
        }
    }

    public boolean writeImages(String fileName, String Content) {
        try {

            if (!fileName.isEmpty() && !Content.isEmpty()) {
                convertImages.createMainFolder();
                convertImages.createMainFolder(Routines.imageFolder);
                convertImages.createMainFolder(Routines.imageFolder + "/" + Routines.organization_id);
                convertImages.createImages(Content, fileName, Routines.imageFolder + "/" + Routines.organization_id);
            }
            return true;
        } catch (Exception e) {
            // TODO: handle exception

        }
        return false;
    }

    public int saveDataInternational(InternationalScope internationalScope) throws SQLException {

        int hasError = 1;
        transactionTemplate.execute(transactionStatus -> {

            final String sql = "call sp_organization_geographicalscope_add (?,?)";
            Connection connection;
            try {

                connection = getJdbcTemplate().getDataSource().getConnection();

                if (internationalScope.getOtherRegisteredOffices() != null) {
                    String sqlRegionalOffice = "call sp_organization_regionaloffice_update (?,?)";
                    CallableStatement psRegOff = (CallableStatement) connection.prepareCall(sqlRegionalOffice);
                    psRegOff.setInt(1, Routines.organization_id);
                    psRegOff.setString(2, internationalScope.getOtherRegisteredOffices());
                    psRegOff.executeQuery();
                }

                String sqlGeoUpdate = "call sp_organization_geographicalscope_update (?)";
                CallableStatement ps = (CallableStatement) connection.prepareCall(sqlGeoUpdate);

                ps.setInt(1, Routines.organization_id);
                ps.executeQuery();

                CallableStatement ps2 = (CallableStatement) connection.prepareCall(sql);
                for (MultiSelect geographical : internationalScope.getGeographicalScope()) {
                    if (geographical.isIsSelected()) {
                        ps2.setInt(1, Routines.organization_id);
                        ps2.setInt(2, geographical.getId());
                        ps2.executeQuery();
                    }
                }

                String sqlExpertiseUpd = "call sp_organization_areaexpertise_update (?)";
                CallableStatement ps3 = (CallableStatement) connection.prepareCall(sqlExpertiseUpd);
                ps3.setInt(1, Routines.organization_id);
                ps3.executeQuery();

                String sqlExpertiseAdd = "call sp_organization_areaexpertise_add (?,?)";
                CallableStatement ps4 = (CallableStatement) connection.prepareCall(sqlExpertiseAdd);

                for (MultiSelect expertise : internationalScope.getAreasOfExpertise()) {
                    if (expertise.isIsSelected()) {
                        ps4.setInt(1, Routines.organization_id);
                        ps4.setInt(2, expertise.getId());
                        ps4.executeQuery();

                        if (expertise.getOthers() != null) {
                            String sqlExpertiseOthers = "call sp_organization_areaexpertiseother_update (?,?)";
                            CallableStatement psOthers = (CallableStatement) connection.prepareCall(sqlExpertiseOthers);
                            psOthers.setInt(1, Routines.organization_id);
                            psOthers.setString(2, expertise.getOthers());
                            psOthers.executeQuery();
                        }
                    }
                }

                String sqlCrossCuttingUpd = "call sp_organization_areacrosscutting_update (?)";
                CallableStatement psCrossCuttingUpd = (CallableStatement) connection.prepareCall(sqlCrossCuttingUpd);
                psCrossCuttingUpd.setInt(1, Routines.organization_id);
                psCrossCuttingUpd.executeQuery();

                String sqlCrossCuttingAdd = "call sp_organization_areacrosscutting_add (?,?)";
                CallableStatement psCrossCutting = (CallableStatement) connection.prepareCall(sqlCrossCuttingAdd);

                for (MultiSelect crossCutting : internationalScope.getCrossCuttingAreas()) {
                    if (crossCutting.isIsSelected()) {
                        psCrossCutting.setInt(1, Routines.organization_id);
                        psCrossCutting.setInt(2, crossCutting.getId());
                        psCrossCutting.executeQuery();

                        if (crossCutting.getOthers() != null) {
                            String sqlCrossCuttingOthers = "call sp_organization_areacrosscuttingother_update (?,?)";
                            CallableStatement psCrossOthers = (CallableStatement) connection.prepareCall(sqlCrossCuttingOthers);
                            psCrossOthers.setInt(1, Routines.organization_id);
                            psCrossOthers.setString(2, crossCutting.getOthers());
                            psCrossOthers.executeQuery();
                        }
                    }
                }

                return 1;

            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                // hasError = 0;
            }
            return 0;
        });



        return hasError;
    }


    @Override
    public OrganizationInfo getData(int Id, String Status) {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_organization_get_by_org_id (?,?)";

            return getJdbcTemplate().queryForObject(sql, new OrganizationInfoMapper(), Id, Status);
        } catch (Exception e) {
            // TODO: handle exception
            return new OrganizationInfo();
        }

    }

    @Override
    public OrganizationInfo getData(String Name, String Status) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<OrganizationInfo> getData(Pagination pagination) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int totalRows(Pagination pagination) {
        // TODO Auto-generated method stub
        return 0;
    }

    public String getText(String spName) {
        try {
            final String sql = "call " + spName + "(?) ";

            return (String) getJdbcTemplate().queryForObject(sql, String.class, Routines.organization_id);


        } catch (Exception e) {
            // TODO: handle exception
        }
        return null;
    }

    public CommonModel getInternationalInfo(int Id) {
        try {
            final String sql = "call sp_organization_internal_get (?) ";

            return getJdbcTemplate().queryForObject(sql, new CommonModelMapper(), Id);


        } catch (Exception e) {
            // TODO: handle exception
        }
        return null;
    }


    public List<CommonModel> getMultiSelectIDList(String spName, int id) {
        try {
            final String sql = "call " + spName + "(?)";

            return getJdbcTemplate().query(sql, new CommonModelMapper(), id);


        } catch (Exception e) {
            // TODO: handle exception
        }

        return null;
    }



    public List<AccreditationList> getAccreditationList(Pagination pagination) {
        // TODO Auto-generated method stub
        try {
            final String sql = "call sp_accreditationList_get(?,?,?,?,?)";

            return getJdbcTemplate().query(sql, new AccreditationListMapper(), pagination.getSpecialQuery(), pagination.getSortBy(),
                    pagination.getOrder(), pagination.getLimit(), pagination.getOffset());

        } catch (Exception e) { // TODO: handle exception
            System.out.println(e.getMessage());
        }

        return null;
    }

    public int totalRow(Pagination pagination) {
        final String sql = "call sp_accreditationList_count (?)";
        return getJdbcTemplate().queryForObject(sql, Integer.class, pagination.getSpecialQuery());
    }

    public List<String> stateUserPermission() {

        final String sql = "call sp_user_permissions ()";

        List<String> permissionList = (List<String>) getJdbcTemplate().queryForList(sql, String.class);

        return permissionList;
    }


}
