/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.UserLocking;
import UNEP.AccreditationSystem.Entities.Users;
import UNEP.AccreditationSystem.IRepository.ICommonRepo;
import UNEP.AccreditationSystem.Mapper.OrganizationProfileMapper;
import UNEP.AccreditationSystem.Mapper.UserLockingMapper;
import UNEP.AccreditationSystem.Mapper.UsersMapper;

/**
 * 
 * @author jean.delacruz
 * @version: 1.0
 * @since May 29, 2018
 */

@Transactional(readOnly = false)
@Repository
public class OrganizationProfileRepo extends JdbcDaoSupport implements ICommonRepo<OrganizationProfile> {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    @Override
    public OrganizationProfile getDataById(int id) {
        // TODO Auto-generated method stub
        final String sql = "call sp_organization_by_id (?)";

        try {
            return getJdbcTemplate().queryForObject(sql, new OrganizationProfileMapper(), id);
        } catch (Exception e) {

            return null;
        }
    }


    @Override
    public OrganizationProfile getDataByName(String name) {
        // TODO Auto-generated method stub
        return null;
    }


    @Override
    public boolean add(OrganizationProfile orgProfile) {
        Boolean isSuccess = true;

        final String sql = "CALL sp_organization_add(?,?,?,?,?,?);";

        try {
            getJdbcTemplate().update(sql, orgProfile.getName(), orgProfile.getWebSite(), orgProfile.getEmailAddress(), orgProfile.getPassword(),
                    Routines.getEkey(), orgProfile.getVerificationCode());
        } catch (Exception e) {
            throw e;
        }

        return isSuccess;
    }

    public boolean verifyRegistration(String verificationCode) {
        Boolean isSuccess = true;

        final String sql = "CALL sp_organization_verificationcode_verify(?);";

        try {
            int affected = getJdbcTemplate().update(sql, verificationCode);

            if (affected == 0) {
                isSuccess = false;
            }
        } catch (Exception e) {
            throw e;
        }

        return isSuccess;
    }


    public OrganizationProfile getDataByVerificationCode(String verificationCode) {
        try {
            final String sql = "call sp_organization_getbyverificationcode (?)";

            return getJdbcTemplate().queryForObject(sql, new OrganizationProfileMapper(), verificationCode);
        } catch (Exception e) {
            // TODO: handle exception
            return new OrganizationProfile();
        }

    }

    public OrganizationProfile getDataByAuthentication(String emailAddress, String password) {
        final String sql = "call sp_organization_getbyauthentication (?, ?)";

        try {
            return getJdbcTemplate().queryForObject(sql, new OrganizationProfileMapper(), emailAddress, password);
        } catch (Exception e) {
            return null;
        }
    }

    public UserLocking validateUserLocking(String emailAddress) {
        final String sql = "call sp_validate_user_locked (?)";

        try {
            return getJdbcTemplate().queryForObject(sql, new UserLockingMapper(), emailAddress);
        } catch (Exception e) {

            return new UserLocking();
        }
    }



    public Users getUserByAuthentication(String emailAddress, String password) {
        final String sql = "call sp_user_authentication (?, ?)";

        try {
            return getJdbcTemplate().queryForObject(sql, new UsersMapper(), emailAddress, password);
        } catch (Exception e) {
            return null;
        }
    }


    public OrganizationProfile getDataByVerifiedEmailAddress(String emailAddress) {
        final String sql = "call sp_organization_getverified (?)";

        try {
            return getJdbcTemplate().queryForObject(sql, new OrganizationProfileMapper(), emailAddress);
        } catch (Exception e) {
            return null;
        }
    }

    public OrganizationProfile getDataByEmailAddress(String emailAddress) {
        final String sql = "call sp_organization_getbyemailaddress (?)";

        try {
            return getJdbcTemplate().queryForObject(sql, new OrganizationProfileMapper(), emailAddress);
        } catch (Exception e) {
            return null;
        }
    }

    public int updateLocking(String emailAddress, String isLogin) {
        final String sql = "call sp_user_locking_update (?,?)";

        try {
            return getJdbcTemplate().update(sql, emailAddress, isLogin);
        } catch (Exception e) {
            return 0;
        }
    }

    public int addLocking(String emailAddress) {
        final String sql = "call sp_logaccess_add (?)";

        try {
            return getJdbcTemplate().update(sql, emailAddress);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public boolean update(OrganizationProfile obj) {
        // TODO Auto-generated method stub
        return false;
    }


    @Override
    public boolean delete(int id) {
        // TODO Auto-generated method stub
        return false;
    }
}
