/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.CommonModel;
import UNEP.AccreditationSystem.Mapper.CommonModelMapper;

/**
 * Title: SettingRepo.java<br>
 * Description: FIXME SettingRepo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 03, 2018
 */

@Repository
public class SettingRepo extends JdbcDaoSupport {

    @Inject
    private DataSource dataSource;


    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }


    public List<CommonModel> getData(Pagination pagination, String tableName) {
        // TODO Auto-generated method stub
        final String sql = "call sp_settings_get (?,?,?,?,?,?)";

        return getJdbcTemplate().query(sql, new CommonModelMapper(), pagination.getSearchQuery(),tableName,pagination.getSortBy(), pagination.getOrder(), 
        		pagination.getLimit(), pagination.getOffset());
    }

    public int totalRows(Pagination pagination, String tableName) {
        final String sql = "call sp_settings_count (?,?)";
        return getJdbcTemplate().queryForObject(sql, Integer.class, pagination.getSearchQuery(), tableName);
    }

    public int saveSettings(StringBuilder sb) {
        try {
            return getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int saveSettings(StringBuilder sbUpdate,StringBuilder Add) {
        try {
             getJdbcTemplate().update(sbUpdate.toString());
             getJdbcTemplate().update(Add.toString());
             return 1;
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int updateSettings(StringBuilder sbUpdate) {
        try {
        	getJdbcTemplate().update(sbUpdate.toString());
        	return 1;
        } catch (Exception e) {
            // TODO: handle exception
        	System.out.println(e.getMessage());
            return 0;
        }
    }
    
}
