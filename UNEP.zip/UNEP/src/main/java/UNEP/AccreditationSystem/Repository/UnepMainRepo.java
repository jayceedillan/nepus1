/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.support.TransactionTemplate;

import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Common.Status;
import UNEP.AccreditationSystem.Entities.CommonModel;
import UNEP.AccreditationSystem.Entities.InternationalScope;
import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.IRepository.IUNEPMain;
import UNEP.AccreditationSystem.Mapper.OrganizationInfoMapper;



/**
 * Title: OrganizationInformationRepo.java<br>
 * Description: FIXME OrganizationInformationRepo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@Repository
public class UnepMainRepo extends JdbcDaoSupport implements IUNEPMain {

    @Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    @Inject
    private TransactionTemplate transactionTemplate;

    @Override
    public int SaveData(OrganizationInfo organizationInformation) throws SQLException {
        // TODO Auto-generated method stub
        final String sql = "call sp_organization_information_AddOrUpdate (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        Connection connection;
        connection = getJdbcTemplate().getDataSource().getConnection();
        CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

        ps.setInt(1, organizationInformation.getId());
        // ps.setString(2, organizationInformation.getFormerName());
        // ps.setString(3, organizationInformation.getAcronym());
        // ps.setInt(4, organizationInformation.getMajorGroup());
        // ps.setString(5, organizationInformation.getPostalAddress());
        // ps.setString(6, organizationInformation.getZipPostalCode());
        // ps.setString(7, organizationInformation.getCityTown());
        // ps.setString(8, organizationInformation.getEmailAddress());
        // ps.setString(9, organizationInformation.getWebSite());
        // ps.setInt(10, organizationInformation.getHQOffice());
        // ps.setString(11, organizationInformation.getLogoName());
        // ps.setString(12, organizationInformation.getFirstName1());
        // ps.setString(13, organizationInformation.getLastName1());
        // ps.setString(14, organizationInformation.getDesignation1());
        // ps.setString(15, organizationInformation.getFirstName2());
        // ps.setString(16, organizationInformation.getLastName2());
        // ps.setString(17, organizationInformation.getDesignation2());
        ps.setString(18, Status.ACTIVE.toString());
        ps.setString(19, "TestUser");
        ps.registerOutParameter(20, java.sql.Types.INTEGER);
        ps.executeQuery();


        int Id = ps.getInt(20);;

        return Id;
    }

    public int saveInternationalScope(InternationalScope internationalScope) throws SQLException {

        transactionTemplate.execute(transactionStatus -> {
            final String sql = "call sp_international_scope_AddOrUpdate (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?)";
            Connection connection;
            try {
                connection = getJdbcTemplate().getDataSource().getConnection();
                CallableStatement ps = (CallableStatement) connection.prepareCall(sql);

                ps.setInt(1, internationalScope.getId());
                // ps.setInt(2, internationalScope.getOrganization_Information_Id());
                // ps.setString(3, internationalScope.getRegionalOffices());
                // ps.setString(4, internationalScope.getOthers());
                // ps.setString(5, internationalScope.getSummarizeGoals());
                // ps.setString(6, internationalScope.getGiveExamplesInternationActivities());
                // ps.setBoolean(7, internationalScope.isUNInternationalConference());
                // ps.setString(8, internationalScope.getUNInternationalConferenceExplain());
                // ps.setBoolean(9, internationalScope.isHasOrganizationInPast());
                // ps.setString(10, internationalScope.getHasOrganizationInPastDescription());
                ps.setString(11, "ACTIVE");
                ps.setString(12, Routines.CurrentUser);
                ps.registerOutParameter(13, java.sql.Types.INTEGER);
                ps.executeQuery();

                int InternationalScopeId = ps.getInt(13);

                String strQuery = "call _international_scope_geographical_add(?,?,?)";

                for (CommonModel Geographical : internationalScope.getGeographicalScope()) {
                    CallableStatement ps2 = (CallableStatement) connection.prepareCall(strQuery);
                    ps2.setInt(1, InternationalScopeId);
                    ps2.setInt(2, Geographical.getId());
                    ps2.setString(3, Routines.CurrentUser);
                    ps2.executeQuery();

                }

                strQuery = "call sp_international_scope_international_scope_expertise_add(?,?,?)";

                for (CommonModel AreasOfExpertise : internationalScope.getAreasOfExpertise()) {
                    CallableStatement ps3 = (CallableStatement) connection.prepareCall(strQuery);
                    ps3.setInt(1, InternationalScopeId);
                    ps3.setInt(2, AreasOfExpertise.getId());
                    ps3.setString(3, Routines.CurrentUser);
                    ps3.executeQuery();
                }

                strQuery = "call international_scope_cross_cutting_add(?,?,?)";
                for (CommonModel CrossCuttingAreas : internationalScope.getCrossCuttingAreas()) {
                    CallableStatement ps4 = (CallableStatement) connection.prepareCall(strQuery);
                    ps4.setInt(1, InternationalScopeId);
                    ps4.setInt(2, CrossCuttingAreas.getId());
                    ps4.setString(3, Routines.CurrentUser);
                    ps4.executeQuery();
                }


            } catch (SQLException e) {
                e.printStackTrace();
            }

            return null;
        });

        return 0;
    }

    @Override
    public OrganizationInfo GetOrganizationInformation(int id) {
        // TODO Auto-generated method stub

        try {
            final String sql = "call sp_organization_information_get (?)";

            return getJdbcTemplate().queryForObject(sql, new OrganizationInfoMapper(), id);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        return null;
    }



}
