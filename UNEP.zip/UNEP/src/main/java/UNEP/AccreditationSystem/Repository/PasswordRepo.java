package UNEP.AccreditationSystem.Repository;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;

/**
 * Copyright (c) ADEC Innovations Inc. 2018. All Rights Reserved.
 *
 * SDT DEV Team
 *
 * @author jean.delacruz
 * @version: 1.0
 * @since Jun 1, 2018
 */

@Transactional(readOnly = false)
@Repository
public class PasswordRepo extends JdbcDaoSupport {
	@Inject
    private DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }
	
	public boolean add(OrganizationProfile orgProfile) {
		Boolean isSuccess = true;
	
		final String sql = "CALL sp_organization_password_add(?,?,?,?);";
	
		try {
			getJdbcTemplate().update(sql, orgProfile.getId(), orgProfile.getPassword(), Routines.getEkey(), orgProfile.getIsTemporaryPassword());
		} catch (Exception e) {
			throw e;
		}
		
		return isSuccess;
	}

}


