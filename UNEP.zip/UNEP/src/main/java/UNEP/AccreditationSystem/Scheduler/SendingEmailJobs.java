/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Scheduler;

import javax.inject.Inject;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import UNEP.AccreditationSystem.Services.OrganizationCountdownService;

/**
 * Title: SendingEmailJobs.java<br>
 * Description: FIXME SendingEmailJobs.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 02, 2018
 */
public class SendingEmailJobs implements Job {

    Logger logger = LoggerFactory.getLogger(getClass());


    @Inject
    private OrganizationCountdownService organizationCountdownService;

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {

            organizationCountdownService.sendEmail10Days();
            organizationCountdownService.process30Days();
        } catch (RuntimeException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
