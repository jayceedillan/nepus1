/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Scheduler;

import javax.annotation.PostConstruct;

import org.quartz.JobDetail;
import org.quartz.Trigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.scheduling.quartz.SpringBeanJobFactory;

import UNEP.AccreditationSystem.Utilities.PropertyUtil;



/**
 * Title: SpringQuartzScheduler.java<br>
 * Description: FIXME SpringQuartzScheduler.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 02, 2018
 */

@Configuration
@ConditionalOnExpression("'${using.spring.schedulerFactory}'=='true'")
public class SpringQuartzScheduler {

    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private ApplicationContext applicationContext;

    @PostConstruct
    public void init() {
        logger.info("Hello world from Spring...");
    }

    @Bean
    public SpringBeanJobFactory springBeanJobFactory() {
        AutoWiringSpringBeanJobFactory jobFactory = new AutoWiringSpringBeanJobFactory();
        logger.debug("Configuring Job factory");

        jobFactory.setApplicationContext(applicationContext);
        return jobFactory;
    }

    @Bean
    public SchedulerFactoryBean scheduler(Trigger trigger, JobDetail job) {

        SchedulerFactoryBean schedulerFactory = new SchedulerFactoryBean();
        schedulerFactory.setConfigLocation(new ClassPathResource("quartz.properties"));

        logger.debug("Setting the Scheduler up");
        schedulerFactory.setJobFactory(springBeanJobFactory());
        schedulerFactory.setJobDetails(job);
        schedulerFactory.setTriggers(trigger);

        return schedulerFactory;
    }

    @Bean
    public JobDetailFactoryBean jobDetail() {

        JobDetailFactoryBean jobDetailFactory = new JobDetailFactoryBean();
        jobDetailFactory.setJobClass(SendingEmailJobs.class);
        jobDetailFactory.setName("Qrtz_Job_Detail");
        jobDetailFactory.setDescription("Invoke Sample Job service...");
        jobDetailFactory.setDurability(true);
        return jobDetailFactory;
    }

    // @Bean
    // public SimpleTriggerFactoryBean trigger(JobDetail job) {
    //
    // SimpleTriggerFactoryBean trigger = new SimpleTriggerFactoryBean();
    // trigger.setJobDetail(job);
    //
    // int frequencyInSec = 10;
    // logger.info("Configuring trigger to fire every {} seconds", frequencyInSec);
    //
    // trigger.setRepeatInterval(frequencyInSec * 1000);
    // trigger.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
    // trigger.setName("Qrtz_Trigger");
    // return trigger;
    // }

    @Bean
    public CronTriggerFactoryBean cronTriggerFactoryBean() {
        CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
        stFactory.setJobDetail(jobDetail().getObject());
        stFactory.setStartDelay(3000);
        stFactory.setName("Qrtz_Trigger");
        stFactory.setCronExpression(PropertyUtil.quartzCronSchedule);
        return stFactory;
    }

}
