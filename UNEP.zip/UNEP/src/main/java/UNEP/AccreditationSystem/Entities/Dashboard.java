/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: Dashboard.java<br>
 * Description: FIXME Dashboard.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 27, 2018
 */

@Data
public class Dashboard {

    private int newAccredited;
    private int accredited;
    private int registeredEmails;
    private int participants;
    private int complaints;
    private int countdown10Days;
    private int followup;
}
