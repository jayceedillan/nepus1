/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import org.hibernate.validator.constraints.NotBlank;

import lombok.Data;

/**
 * Title: Users.java<br>
 * Description: FIXME Users.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 13, 2018
 */

@Data
public class Users {

    private int id;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Email Address is required")
    private String email;


    private String password;
    private Roles roles;
    private int changePassword;
    private Boolean isTemporaryPassword;
}
