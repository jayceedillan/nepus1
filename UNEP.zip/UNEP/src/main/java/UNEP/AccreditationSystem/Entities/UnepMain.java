/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import java.util.List;

import lombok.Data;

/**
 * Title: UnepMain.java<br>
 * Description: FIXME UnepMain.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@Data
public class UnepMain {

    private OrganizationInfo organizationInfo;
    private InternationalScope internationalScopeInfo;
    private AdditionalInfo additionalInfo;
    private DocumentsUploads documents;
    private OrganizationProfile orgProfile;
    private TrackingApplication trackingApplication;
    private Users users;
    private List<MultiSelect> documentsOthers;
    
}
