/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: AccreditationList.java<br>
 * Description: FIXME AccreditationList.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 11, 2018
 */

@Data
public class AccreditationList {

    private int organization_id;
    private String organizationName;
    private String majorGroupName;
    private String stagingStatus;
}
