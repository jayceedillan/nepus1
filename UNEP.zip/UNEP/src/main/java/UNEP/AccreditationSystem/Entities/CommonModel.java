/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import java.sql.Timestamp;

import lombok.Data;

/**
 * Title: CommonModel.java<br>
 * Description: FIXME CommonModel.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@Data
public class CommonModel {

    private int Id;
    private String name;
    private String createstatus;
    private Timestamp createdate;
    private String createby;
}
