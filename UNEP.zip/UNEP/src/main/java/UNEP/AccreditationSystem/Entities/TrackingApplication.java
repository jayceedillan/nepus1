/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import java.sql.Date;

import lombok.Data;

/**
 * Title: TrackingApplication.java<br>
 * Description: FIXME TrackingApplication.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 05, 2018
 */
@Data
public class TrackingApplication {

    private int id;
    private int remainingDays;
    private int returnDays;
    private Date submittedDate;
    private int stageNo;
    private String status;


}
