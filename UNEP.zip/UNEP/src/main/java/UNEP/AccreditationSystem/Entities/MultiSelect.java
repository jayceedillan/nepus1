/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: MultiSelect.java<br>
 * Description: FIXME MultiSelect.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 28, 2018
 */
@Data
public class MultiSelect extends CommonModel {

    private boolean IsSelected;
    private String others;
    private boolean IsSelectedOthers;
    private String fileName;
}
