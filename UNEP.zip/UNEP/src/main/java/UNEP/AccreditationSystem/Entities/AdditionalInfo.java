/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import java.sql.Date;

import lombok.Data;

/**
 * Title: AdditionalInformation.java<br>
 * Description: FIXME AdditionalInformation.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@Data
public class AdditionalInfo extends CommonModel {


    private Date registrationdate;
    private MultiSelect country;
    private MultiSelect companyCategory;
    private String companycategoryother;
    private boolean isnetworkmember1;
    private String document1;
    private String remarks1;
    private boolean isnetworkmember2;
    private String document2;
    private String remarks2;
    private String fundsource;


}

