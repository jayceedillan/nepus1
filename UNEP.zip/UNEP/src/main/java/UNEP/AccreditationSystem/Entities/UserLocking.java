/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import java.sql.Timestamp;

import lombok.Data;

/**
 * Title: UserLocking.java<br>
 * Description: FIXME UserLocking.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 19, 2018
 */

@Data
public class UserLocking {

    private int id;
    private String email;
    private Timestamp createdate;
    private String totaltime;
    private Timestamp servertime;
    private int attemps;

}
