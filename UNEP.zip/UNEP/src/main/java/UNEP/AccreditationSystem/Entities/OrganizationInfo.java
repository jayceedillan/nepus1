/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: OrganizationInformation.java<br>
 * Description: FIXME OrganizationInformation.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@Data
public class OrganizationInfo extends Organization {

    private int organization_id;
    private String formername;
    private String Acronym;
    private MultiSelect majorgroup;
    private String postaladdress;
    private String postalzipcode;
    private String city;
    private String email;
    private String webSite;
    private MultiSelect country;
    private String logo;
    private String firstname1;
    private String lastname1;
    private String email1;
    private String designation1;
    private String firstname2;
    private String lastname2;
    private String email2;
    private String designation2;
    private FilesInfo filesInfo;
    private String profileImage;
}

