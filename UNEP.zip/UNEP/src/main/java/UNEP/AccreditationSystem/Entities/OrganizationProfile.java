/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import java.sql.Date;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import lombok.Data;

/**
 * Title: Account.java<br>
 * Description: FIXME Account.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@Data
public class OrganizationProfile extends CommonModel {

    @NotBlank(message = "Organization Name is required")
    private String name;

    @NotBlank(message = "Organization Website is required")
    private String webSite;

    @NotBlank(message = "Email Address is required")
    private String emailAddress;

    @NotBlank(message = "Password is required")
    @Size(min = 10, message = "Password can only accept up to 10 characters")
    private String password;

    @NotBlank(message = "Confirm Password is required")
    private String confirmPassword;

    private String eKey;

    private String verificationCode;

    private Boolean isTemporaryPassword;

    private Date verifieddate;
}
