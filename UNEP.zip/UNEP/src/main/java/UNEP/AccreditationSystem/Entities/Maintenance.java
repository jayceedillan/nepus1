package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Copyright (c) ADEC Innovations Inc. 2018. All Rights Reserved.
 *
 * SDT DEV Team
 *
 * @author jean.delacruz
 * @version: 1.0
 * @since May 30, 2018
 */
@Data
public class Maintenance extends CommonModel{
	
	private String name;
	private String description;
	private String value;
	
	public final static String ACCREDOFFICEREMAIL = "ACCREDOFFICEREMAIL";
}


