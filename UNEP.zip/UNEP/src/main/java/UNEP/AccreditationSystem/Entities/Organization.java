/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: Organization.java<br>
 * Description: FIXME Organization.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 29, 2018
 */

@Data
public class Organization extends CommonModel {

    private String name;
    // private String website;
    private String email;
}
