/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: ResponseMessage.java<br>
 * Description: FIXME ResponseMessage.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 31, 2018
 */
@Data
public class ResponseMessage {

    private String header;
    private String success;
    private String error;
}
