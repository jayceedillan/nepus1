/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import java.util.List;

import lombok.Data;

/**
 * Title: InternationalScope.java<br>
 * Description: FIXME InternationalScope.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */
@Data
public class InternationalScope extends CommonModel {


    private String otherRegisteredOffices;


    private List<MultiSelect> GeographicalScope;
    private List<MultiSelect> AreasOfExpertise;
    private List<MultiSelect> CrossCuttingAreas;
}
