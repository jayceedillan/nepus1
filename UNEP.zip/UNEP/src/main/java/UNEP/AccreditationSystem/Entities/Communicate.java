/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: CommunicateOrg.java<br>
 * Description: FIXME CommunicateOrg.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 18, 2018
 */

@Data
public class Communicate {

    private int organization_id;
    private String subject;
    private String content;
    private String attach;
    private int from_role_id;
    private int to_role_id;
}
