package UNEP.AccreditationSystem.Entities.extend;

import java.util.List;

import UNEP.AccreditationSystem.Entities.DocumentAttach;
import lombok.Data;

@Data
public class Accreditation {

	  private List<DocumentAttach> documentAttach;
	  private String content;
}
