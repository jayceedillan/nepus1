package UNEP.AccreditationSystem.Entities;

import lombok.Data;

@Data
public class AuthenticationData {

	private OrganizationProfile organizationProfile;
	private Users users;
}
