/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: FilesInfo.java<br>
 * Description: FIXME FilesInfo.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 30, 2018
 */
@Data
public class FilesInfo {
    private int id;
    private String content;
    private String fileName;
    private String fileType;
}
