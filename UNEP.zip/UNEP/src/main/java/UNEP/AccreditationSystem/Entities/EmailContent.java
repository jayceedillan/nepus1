/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: EmailContent.java<br>
 * Description: FIXME EmailContent.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 22, 2018
 */
@Data
public class EmailContent {

    private String SourceTag;
    private String Subject;
    private String Content;
}
