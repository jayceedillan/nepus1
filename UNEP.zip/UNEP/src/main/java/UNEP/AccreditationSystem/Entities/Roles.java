/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: RoleName.java<br>
 * Description: FIXME RoleName.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 15, 2018
 */

@Data
public class Roles extends CommonModel {

    private String email;
}
