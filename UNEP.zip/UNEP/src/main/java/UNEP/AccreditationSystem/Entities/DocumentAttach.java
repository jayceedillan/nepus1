package UNEP.AccreditationSystem.Entities;

import lombok.Data;

@Data
public class DocumentAttach {

    private int id;
    private String name;
    private boolean decision;
    private boolean hasEmpty;
    private String typeName;
    private String type;
    private int typeId;
    private boolean hasDownloaded;
}
