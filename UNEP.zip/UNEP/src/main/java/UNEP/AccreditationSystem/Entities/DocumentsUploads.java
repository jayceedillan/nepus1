/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Entities;

import lombok.Data;

/**
 * Title: Documents.java<br>
 * Description: FIXME Documents.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@Data
public class DocumentsUploads extends CommonModel {
    
    private String constitution;
    private String financialreport;
    private String other;
}
