/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.IRepository;

import java.sql.SQLException;

import UNEP.AccreditationSystem.Entities.OrganizationInfo;

/**
 * Title: IUNEPMain.java<br>
 * Description: FIXME IUNEPMain.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 09, 2018
 */
public interface IUNEPMain {

    int SaveData(OrganizationInfo organizationInformation) throws SQLException;

    OrganizationInfo GetOrganizationInformation(int id);
}
