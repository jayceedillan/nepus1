/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.IRepository;

import java.util.List;

/**
 * Title: IDropdown.java<br>
 * Description: FIXME IDropdown.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 10, 2018
 */
public interface IDropdown<T> {

    List<T> getData(String spName);

    T getData(int Id, String spName);
}
