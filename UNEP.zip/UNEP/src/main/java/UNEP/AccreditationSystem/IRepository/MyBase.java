/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.IRepository;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import UNEP.AccreditationSystem.Common.Pagination;

/**
 * Title: MyBase.java<br>
 * Description: FIXME MyBase.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */
public interface MyBase<T> {

    int saveData(T dataItems) throws SQLException, IOException;

    T getData(String Name, String Status);

    T getData(int Id, String Status) throws IOException;

    List<T> getData(Pagination pagination);

    int totalRows(Pagination pagination);
}
