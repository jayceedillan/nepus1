package UNEP.AccreditationSystem.IRepository;


/**
 * Copyright (c) ADEC Innovations Inc. 2018. All Rights Reserved.
 *
 * SDT DEV Team
 *
 * @author jean.delacruz
 * @version: 1.0
 * @since May 29, 2018
 */
public interface ICommonRepo<T> {

    // /**
    // * Retrieves data using the search parameters
    // * Also returns the total number of rows retrieved
    // *
    // * @param searchParameter
    // * @return
    // */
    // Map<String, Object> getList(SearchParameter searchParameter);

    /**
     * Retrieves data using id
     * 
     * @param id
     * @return
     */
    T getDataById(int id);

    /**
     * Retrieves data using name
     * 
     * @param id
     * @return
     */
    T getDataByName(String name);

    /**
     * Adds new record
     * 
     * @param obj
     * @return
     */
    boolean add(T obj);

    /**
     * Updates existing record
     * 
     * @param obj
     * @return
     */
    boolean update(T obj);

    /**
     * Deletes existing record
     * 
     * @param id
     * @return
     */
    boolean delete(int id);

}
