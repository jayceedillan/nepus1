package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.DocumentsUploads;


public class DocumentsUploadsMapper implements RowMapper<DocumentsUploads> {

	@Override
	public DocumentsUploads mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return new DocumentsUploads() {
            {
                setId(rs.getInt("odoc.id"));
                setConstitution(rs.getString("odoc.constitution") == null ? "" : rs.getString("odoc.constitution"));
                setFinancialreport(rs.getString("odoc.financialreport")==null ? "" : rs.getString("odoc.financialreport"));
            }
        };
	}

}
