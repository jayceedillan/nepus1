/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.Roles;

/**
 * Title: RolesMapper.java<br>
 * Description: FIXME RolesMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 23, 2018
 */
public class RolesMapper implements RowMapper<Roles> {

    @Override
    public Roles mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new Roles() {
            {
                setId(rs.getInt("r.Id"));
                setName(rs.getString("r.Name"));

                try {
                    setEmail(rs.getString("emails"));
                } catch (Exception e) {
                    // TODO: handle exception
                }
            }
        };
    }

}
