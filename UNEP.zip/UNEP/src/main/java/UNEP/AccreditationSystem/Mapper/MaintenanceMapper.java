package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.EmailContent;
import UNEP.AccreditationSystem.Entities.Maintenance;

/**
 * Copyright (c) ADEC Innovations Inc. 2018. All Rights Reserved.
 *
 * SDT DEV Team
 *
 * @author jean.delacruz
 * @version: 1.0
 * @since May 30, 2018
 */
public class MaintenanceMapper implements RowMapper<Maintenance> {

    @Override
    public Maintenance mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new Maintenance() {
            {
                setName(rs.getString("name"));
                setDescription(rs.getString("description"));
                setValue(rs.getString("value"));
            }
        };
    }

}


