/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.MultiSelect;

/**
 * Title: CompanyCategoryMapper.java<br>
 * Description: FIXME CompanyCategoryMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 01, 2018
 */
public class CompanyCategoryMapper implements RowMapper<MultiSelect> {

    @Override
    public MultiSelect mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new MultiSelect() {
            {
                setId(rs.getInt("cc.id"));
                setName(rs.getString("cc.name"));
            }
        };
    }

}
