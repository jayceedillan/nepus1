/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.UserLocking;

/**
 * Title: UserLockingMapper.java<br>
 * Description: FIXME UserLockingMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 19, 2018
 */
public class UserLockingMapper implements RowMapper<UserLocking> {

    @Override
    public UserLocking mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new UserLocking() {
            {
                setEmail(rs.getString("email"));
                setCreatedate(rs.getTimestamp("createdate"));
                setTotaltime(rs.getString("totaltime"));
                // setServertime(rs.getTimestamp("now"));
                setAttemps(rs.getInt("attemps"));
            }
        };
    }

}
