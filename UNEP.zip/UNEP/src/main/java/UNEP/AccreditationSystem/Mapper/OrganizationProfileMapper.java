/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.OrganizationProfile;

/**
 * Title: AccountProfileMapper.java<br>
 * Description: FIXME AccountProfileMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 23, 2018
 */
public class OrganizationProfileMapper implements RowMapper<OrganizationProfile> {

    @Override
    public OrganizationProfile mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new OrganizationProfile() {
            {
                setId(rs.getInt("id"));
                setName(rs.getString("name"));
                setWebSite(rs.getString("website"));
                setEmailAddress(rs.getString("email"));
                setVerificationCode(rs.getString("verificationcode"));
                setVerifieddate(rs.getDate("verifieddate"));
                setIsTemporaryPassword(rs.getBoolean("istemporary"));
                setCreatestatus(rs.getString("createstatus"));
            }
        };
    }

}
