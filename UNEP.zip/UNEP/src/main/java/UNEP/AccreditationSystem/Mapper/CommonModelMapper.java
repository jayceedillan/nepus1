/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.CommonModel;

/**
 * Title: CommonModelMapper.java<br>
 * Description: FIXME CommonModelMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 28, 2018
 */
public class CommonModelMapper implements RowMapper<CommonModel> {

    @Override
    public CommonModel mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new CommonModel() {
            {
                setId(rs.getInt("Id"));
                setName(rs.getString("Name"));
            }
        };
    }

}
