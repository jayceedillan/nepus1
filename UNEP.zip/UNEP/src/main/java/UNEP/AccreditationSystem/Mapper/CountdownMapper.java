/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.OrganizationInfo;

/**
 * Title: CountdownMapper.java<br>
 * Description: FIXME CountdownMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 06, 2018
 */
public class CountdownMapper implements RowMapper<OrganizationInfo> {

    @Override
    public OrganizationInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new OrganizationInfo() {
            {
                setId(rs.getInt("id"));
                setName(rs.getString("organizationName"));
                try {
                    setOrganization_id(rs.getInt("orgId"));
                } catch (Exception e) {
                    // TODO: handle exception
                }

            }
        };
    }

}
