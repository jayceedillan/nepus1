/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.TrackingApplication;

/**
 * Title: TrackingApplicationMapper.java<br>
 * Description: FIXME TrackingApplicationMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 05, 2018
 */
public class TrackingApplicationMapper implements RowMapper<TrackingApplication> {

    @Override
    public TrackingApplication mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new TrackingApplication() {
            {
                setId(rs.getInt("oapp.id"));
                setRemainingDays(rs.getInt("remainingDays"));
                setReturnDays(rs.getInt("returnDays"));
                setSubmittedDate(rs.getDate("oapp.submissiondate"));
                setStageNo(rs.getInt("oapp.stageno"));
                setStatus(rs.getString("oapp.createstatus"));
            }
        };
    }

}
