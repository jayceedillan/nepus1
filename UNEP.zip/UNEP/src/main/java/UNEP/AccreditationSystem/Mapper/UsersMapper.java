package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.Users;

public class UsersMapper implements RowMapper<Users> {

    @Override
    public Users mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub

        RolesMapper roleMapper = new RolesMapper();
        return new Users() {
            {
                setId(rs.getInt("u.Id"));
                setName(rs.getString("u.Name"));
                setEmail(rs.getString("u.email"));
                setIsTemporaryPassword(rs.getBoolean("u.istemporary"));
                setRoles(roleMapper.mapRow(rs, rowNum));
            }
        };
    }

}
