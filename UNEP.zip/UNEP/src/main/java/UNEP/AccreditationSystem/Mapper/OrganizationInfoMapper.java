/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.OrganizationInfo;



/**
 * Title: OrganizationInformationMapper.java<br>
 * Description: FIXME OrganizationInformationMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 09, 2018
 */
public class OrganizationInfoMapper implements RowMapper<OrganizationInfo> {

    @Override
    public OrganizationInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        MajorGroupMapper majorGroupMapper = new MajorGroupMapper();
        CountryMapper countryMapper = new CountryMapper();
        return new OrganizationInfo() {
            {
                setId(rs.getInt("oi.id"));
                setOrganization_id(rs.getInt("oi.organization_id"));
                // setName(rs.getString("oi.name"));
                setFormername(rs.getString("oi.formername"));
                setLogo(rs.getString("oi.logo"));
                setAcronym(rs.getString("oi.acronym"));
                setPostaladdress(rs.getString("oi.postaladdress"));
                setPostalzipcode(rs.getString("oi.postalzipcode"));
                setCity(rs.getString("oi.city"));
                // setEmail(rs.getString("oi.email"));
                setWebSite(rs.getString("oi.website"));
                setFirstname1(rs.getString("oi.firstname1"));
                setLastname1(rs.getString("oi.lastname1"));
                setEmail1(rs.getString("oi.email1"));
                setDesignation1(rs.getString("oi.designation1"));
                setFirstname2(rs.getString("oi.firstname2"));
                setLastname2(rs.getString("oi.lastname2"));
                setEmail2(rs.getString("oi.email2"));
                setDesignation2(rs.getString("oi.designation2"));

                setMajorgroup(majorGroupMapper.mapRow(rs, rowNum));
                setCountry(countryMapper.mapRow(rs, rowNum));
                // setFormerName(rs.getString("oi.FormerName"));
            }
        };
    }

}
