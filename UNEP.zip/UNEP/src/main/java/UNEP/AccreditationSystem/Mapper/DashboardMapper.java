/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.Dashboard;

/**
 * Title: DashboardMapper.java<br>
 * Description: FIXME DashboardMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 27, 2018
 */
public class DashboardMapper implements RowMapper<Dashboard> {

    @Override
    public Dashboard mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new Dashboard() {
            {
                setAccredited(rs.getInt("ACCREDITED"));
                setNewAccredited(rs.getInt("NEWACCREDITED"));
                setFollowup(rs.getInt("FOLLOWUP"));
            }
        };
    }

}
