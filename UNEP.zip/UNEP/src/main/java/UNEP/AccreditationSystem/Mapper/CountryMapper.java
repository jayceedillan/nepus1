/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.MultiSelect;

/**
 * Title: CountryMapper.java<br>
 * Description: FIXME CountryMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 29, 2018
 */
public class CountryMapper implements RowMapper<MultiSelect> {

    @Override
    public MultiSelect mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        return new MultiSelect() {
            {
                setId(rs.getInt("c.id"));
                setName(rs.getString("c.name"));
            }
        };
    }

}
