package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.DocumentAttach;

public class DocumentAttachMapper implements RowMapper<DocumentAttach>{

	@Override
	public DocumentAttach mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return new DocumentAttach() {
            {
                setId(rs.getInt("oacc.id"));
                setName(rs.getString("oacc.document"));    
                setDecision(rs.getBoolean("oacc.decision"));            
            }
        };
	}

}
