/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import UNEP.AccreditationSystem.Entities.AdditionalInfo;

/**
 * Title: AdditionalInfoMapper.java<br>
 * Description: FIXME AdditionalInfoMapper.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 01, 2018
 */
public class AdditionalInfoMapper implements RowMapper<AdditionalInfo> {

    @Override
    public AdditionalInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
        // TODO Auto-generated method stub
        CountryMapper countryMapper = new CountryMapper();
        CompanyCategoryMapper companyCategoryMapper = new CompanyCategoryMapper();
        return new AdditionalInfo() {
            {
                setId(rs.getInt("oa.id"));
                setRegistrationdate(rs.getDate("oa.registrationdate"));
                setCountry(countryMapper.mapRow(rs, rowNum));
                setCompanyCategory(companyCategoryMapper.mapRow(rs, rowNum));
                setCompanycategoryother(rs.getString("oa.companycategoryother"));
                setIsnetworkmember1(rs.getBoolean("oa.isnetworkmember1"));
                setDocument1(rs.getString("oa.document1") == null ? "" : rs.getString("oa.document1"));
                setRemarks1(rs.getString("oa.remarks1"));
                setIsnetworkmember2(rs.getBoolean("oa.isnetworkmember2"));
                setDocument2(rs.getString("oa.document2") ==null ? "" : rs.getString("oa.document2"));
                setRemarks2(rs.getString("oa.remarks2"));
                setFundsource(rs.getString("oa.fundsource") == null ? "" : rs.getString("oa.fundsource"));
            }
        };
    }

}
