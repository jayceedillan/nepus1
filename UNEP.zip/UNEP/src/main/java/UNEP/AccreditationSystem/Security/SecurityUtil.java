package UNEP.AccreditationSystem.Security;

import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import UNEP.AccreditationSystem.Entities.AuthenticationData;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;



public class SecurityUtil {

    public final static String NO_USER = "No user currently logged in";

    public static AuthenticationData getCurrentLogin() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        if (authentication != null) {
            if (authentication.getPrincipal() instanceof AuthenticationData) {

                return (AuthenticationData) authentication.getPrincipal();
            }
        }
        throw new AuthenticationCredentialsNotFoundException(NO_USER);
    }
}
