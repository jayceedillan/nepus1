/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Config;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Title: WebConfig.java<br>
 * Description: FIXME WebConfig.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since April 23, 2018
 */
public class WebConfig extends WebMvcConfigurerAdapter {

    @Controller
    static class DefaultRoute {
        @RequestMapping({"/", "Login", "VerifyRegistration/**", "Organization/**", "Register", "ForgotPassword", "AccreditationProcessing",
                "Maintenance/**", "Accreditation/**", "Dashboard", "PrintPDF/**"})
        public String index() {
            return "forward:/main/WebApp/app/mainpage/Main.html";
        }
    }
}
