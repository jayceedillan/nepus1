package UNEP.AccreditationSystem.Services;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.UserLocking;
import UNEP.AccreditationSystem.Entities.Users;
import UNEP.AccreditationSystem.Repository.OrganizationProfileRepo;

/**
 * Copyright (c) ADEC Innovations Inc. 2018. All Rights Reserved.
 *
 * SDT DEV Team
 *
 * @author jean.delacruz
 * @version: 1.0
 * @since May 31, 2018
 */

@Service
public class AuthenticationService {

    @Inject
    private OrganizationProfileRepo orgProfileRepo;

    public boolean validateUserLocking(String emailAddress) {

        UserLocking userLocking = orgProfileRepo.validateUserLocking(emailAddress);
        return userLocking.getAttemps() >= 3;
    }

    public OrganizationProfile authenticateLogin(String emailAddress, String password) {

        try {
            return orgProfileRepo.getDataByAuthentication(emailAddress, password);
        } catch (Exception e) {
            e.printStackTrace();
            return new OrganizationProfile();
        }
    }

    public OrganizationProfile getDataById(int id) {
        return orgProfileRepo.getDataById(id);
    }

    public Users getUserAuthentication(String emailAddress, String password) {
        return orgProfileRepo.getUserByAuthentication(emailAddress, password);
    }

    public int addLocking(String emailAddress) {
        return orgProfileRepo.addLocking(emailAddress);
    }

    public int updateLocking(String emailAddress, String isLogin) {
        return orgProfileRepo.updateLocking(emailAddress, isLogin);
    }
}


