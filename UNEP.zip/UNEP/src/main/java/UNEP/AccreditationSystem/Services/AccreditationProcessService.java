package UNEP.AccreditationSystem.Services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.EmailContentMessages;
import UNEP.AccreditationSystem.Common.EmailSubjects;
import UNEP.AccreditationSystem.Common.Role;
import UNEP.AccreditationSystem.Common.RoleName;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Common.Status;
import UNEP.AccreditationSystem.Entities.AdditionalInfo;
import UNEP.AccreditationSystem.Entities.DocumentAttach;
import UNEP.AccreditationSystem.Entities.DocumentsUploads;
import UNEP.AccreditationSystem.Entities.MultiSelect;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.TrackingApplication;
import UNEP.AccreditationSystem.Entities.extend.Accreditation;
import UNEP.AccreditationSystem.Repository.AccreditationProcessRepo;
import UNEP.AccreditationSystem.Repository.AdditionalInfoRepo;
import UNEP.AccreditationSystem.Utilities.ConvertImages;
import UNEP.AccreditationSystem.Utilities.EmailSender;

@Service
public class AccreditationProcessService {


    @Inject
    private AdditionalInfoRepo additionalInfoRepo;

    @Inject
    private AccreditationProcessRepo accreditationProcessRepo;

    @Inject
    private Role role;

    @Inject
    private TrackingApplicationService trackingApplicationService;

    @Inject
    private ConvertImages convertImages;

    @Inject
    private EmailSender emailSender;

    @Inject
    AuthenticationService authService;

    @Inject
    private EmailContentMessages emailContentMessages;

    public Accreditation getDocumentList(int id) throws IOException {

        List<DocumentAttach> docList = new ArrayList<DocumentAttach>();
        DocumentAttach documentAttach1 = null;

        AdditionalInfo additionalInfo = additionalInfoRepo.getData(id, Status.ACTIVE.toString());


        documentAttach1 = new DocumentAttach();
        documentAttach1.setId(docList.size() + 1);
        documentAttach1.setTypeName("fundsource");
        documentAttach1.setHasEmpty(additionalInfo.getFundsource().isEmpty());
        documentAttach1.setName("SOURCE OF FUNDING");
        documentAttach1.setType("additional");
        docList.add(documentAttach1);

        documentAttach1 = new DocumentAttach();
        documentAttach1.setId(docList.size() + 1);
        documentAttach1.setTypeName("document1");
        documentAttach1.setHasEmpty(additionalInfo.getDocument1().isEmpty());
        documentAttach1.setName("PREDIMONANTLY IN THE FIELD OF ENVIRONMENT1");
        documentAttach1.setType("additional");
        docList.add(documentAttach1);

        documentAttach1 = new DocumentAttach();
        documentAttach1.setId(docList.size() + 1);
        documentAttach1.setTypeName("document2");
        documentAttach1.setName("PREDIMONANTLY IN THE FIELD OF ENVIRONMENT2");
        documentAttach1.setHasEmpty(additionalInfo.getDocument2().isEmpty());
        documentAttach1.setType("additional");
        docList.add(documentAttach1);

        DocumentsUploads documentUploads = additionalInfoRepo.getDocumentsUploads(id);

        documentAttach1 = new DocumentAttach();
        documentAttach1.setId(docList.size() + 1);
        documentAttach1.setTypeName("constitution");
        documentAttach1.setName("CONSTITUTION/CHARACTER & ALL AMENDMENT");
        documentAttach1.setHasEmpty(documentUploads.getConstitution().isEmpty());
        documentAttach1.setType("documents");
        docList.add(documentAttach1);

        documentAttach1 = new DocumentAttach();
        documentAttach1.setId(docList.size() + 1);
        documentAttach1.setTypeName("financialreport");
        documentAttach1.setName("AUDITED FINANCIAL REPORTS FOR THE LAST TWO YEARS");
        documentAttach1.setHasEmpty(documentUploads.getFinancialreport().isEmpty());
        documentAttach1.setType("documents");
        docList.add(documentAttach1);

        List<MultiSelect> documentOthers = additionalInfoRepo.getDocumentsOthers(id);
        int i = 1;

        for (MultiSelect multiData : documentOthers) {
            documentAttach1 = new DocumentAttach();
            documentAttach1.setId(docList.size() + 1);
            documentAttach1.setTypeId(multiData.getId());
            documentAttach1.setName("ANY OTHER RELEVANT DOCUMENT " + i++);
            documentAttach1.setHasEmpty(multiData.getName().isEmpty());
            documentAttach1.setType("documentsothers");
            docList.add(documentAttach1);
        }

        List<DocumentAttach> listAccred = accreditationProcessRepo.getAccreditationDocuments(id);

        for (DocumentAttach documentAttach : docList) {

            String fileName = documentAttach.getName();
            DocumentAttach documentAttached = listAccred.stream().filter(x -> fileName.equals(x.getName())).findAny().orElse(null);

            if (documentAttached != null) {
                documentAttach.setDecision(documentAttached.isDecision());
            }

        }

        Accreditation accreditation = new Accreditation();
        accreditation.setDocumentAttach(docList);

        return accreditation;
    }

    public String getRecommendationContent(int id) {

        int roleId = role.getRoles();
        String recommendation = "";
        if (roleId != 0) {
            if (roleId == RoleName.CivilSocietyUnitChief.getRoleId()) {
                recommendation = accreditationProcessRepo.getRecommendation(id);
                if (recommendation != null) {
                    recommendation = recommendation.replaceAll("\\<.*?>", "");
                }
            }
        }

        return recommendation;
    }

    public TrackingApplication getOrganizationStatus(int id, int stageNo) {

        return trackingApplicationService.getTrackingApp(id, stageNo, Integer.toString(stageNo));

    }

    public List<DocumentAttach> getAccreditationDocuments(int id) {
        return accreditationProcessRepo.getAccreditationDocuments(id);
    }

    public int saveAccreditationProcess(int id, Accreditation documentAttach) throws AddressException, MessagingException {

        int save1 = accreditationProcessRepo.SaveAccreditationProcess(id, documentAttach);
        int save2 = 0;

        int roleId = role.getRoles();

        if (roleId == RoleName.AccreditationOfficer.getRoleId()) {
            save2 = trackingApplicationService.saveAppTracking(id, "ACTIVE", "");

            OrganizationProfile orgProfile = authService.getDataById(id);

            emailSender.sendEmail(EmailSubjects.NEWACCREDITATION + orgProfile.getName(), emailContentMessages.NewAccreditation(),
                    role.GetOfficersById(RoleName.CivilSocietyUnitChief.getRoleId()).getEmail());

        } else if (roleId == RoleName.CivilSocietyUnitChief.getRoleId()) {
            save2 = trackingApplicationService.saveAppTracking(id, "ACTIVE", "");
        }

        else if (roleId == RoleName.GovernanceOfficeSecretary.getRoleId()) {
            save2 = trackingApplicationService.saveAppTracking(id, "ACTIVE", "");
        }

        return save1 = save2 == 1 ? 1 : 0;
    }

    public String getPath(int id, DocumentAttach documentAttach) throws IOException {


        if (documentAttach.getType().equals("additional")) {
            AdditionalInfo additionalInfo = additionalInfoRepo.getData(id, Status.ACTIVE.toString());

            if (documentAttach.getTypeName().equals("fundsource")) {
                return convertImages.getPath() + Routines.additionalFolder + "/" + id + "/" + additionalInfo.getFundsource();
            }

            if (documentAttach.getTypeName().equals("document1")) {
                return convertImages.getPath() + Routines.additionalFolder + "/" + id + "/" + additionalInfo.getDocument1();
            }

            if (documentAttach.getTypeName().equals("document2")) {
                return convertImages.getPath() + Routines.additionalFolder + "/" + id + "/" + additionalInfo.getDocument2();
            }
        }

        if (documentAttach.getType().equals("documents")) {
            DocumentsUploads documentUploads = additionalInfoRepo.getDocumentsUploads(id);

            if (documentAttach.getTypeName().equals("constitution")) {
                return convertImages.getPath() + Routines.additionalFolder + "/" + id + "/" + documentUploads.getConstitution();
            }

            if (documentAttach.getTypeName().equals("financialreport")) {
                return convertImages.getPath() + Routines.additionalFolder + "/" + id + "/" + documentUploads.getFinancialreport();
            }
        }

        if (documentAttach.getType().equals("documentsothers")) {
            List<MultiSelect> listAccred = additionalInfoRepo.getDocumentsOthers(id);
            MultiSelect multiSelect = listAccred.stream().filter(x -> documentAttach.getTypeId() == x.getId()).findAny().orElse(null);
            return convertImages.getPath() + Routines.additionalFolder + "/" + id + "/" + multiSelect.getName();
        }
        return null;
    }   
}
