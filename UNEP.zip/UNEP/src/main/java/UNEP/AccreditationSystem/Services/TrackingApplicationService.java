/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.EmailContentMessages;
import UNEP.AccreditationSystem.Common.Role;
import UNEP.AccreditationSystem.Common.RoleName;
import UNEP.AccreditationSystem.Common.Staging;
import UNEP.AccreditationSystem.Entities.AuthenticationData;
import UNEP.AccreditationSystem.Entities.Email;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.TrackingApplication;
import UNEP.AccreditationSystem.Repository.TrackingApplicationRepo;
import UNEP.AccreditationSystem.Security.SecurityUtil;
import UNEP.AccreditationSystem.Utilities.EmailSender;

/**
 * Title: TrackingApplicationService.java<br>
 * Description: FIXME TrackingApplicationService.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 05, 2018
 */

@Service
public class TrackingApplicationService {


    @Inject
    private TrackingApplicationRepo trackingApplicationRepo;

    @Inject
    private Role role;

    @Inject
    private EmailSender emailSender;

    @Inject
    private AuthenticationService authService;

    @Inject
    private EmailContentMessages emailContentMessages;
    
    @Inject
    private Role roles;
    
    public int saveAppTracking(int id, String status, String remarks) {
        int result = trackingApplicationRepo.saveAppTracking(id, status, remarks, getStaging());

        OrganizationProfile orgProfile = authService.getDataById(id);

        if (result == 1) {
            if (status.equals("REJECTED")) {
                try {
                    String content = emailContentMessages.Approval(orgProfile.getName(), remarks);
                    emailSender.sendEmail("UNEP Accreditation System: Declined Accreditation - " + orgProfile.getName(), content,
                            orgProfile.getEmailAddress());
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } else {
                int roleId = role.getRoles();

                if (roleId == RoleName.CivilSocietyUnitChief.getRoleId()) {
                    String email = role.getEmailByRoles(RoleName.GovernanceOfficeSecretary.getRoleId());
                    String content = emailContentMessages.Approval(orgProfile.getName(), remarks, status == "APPROVED" ? "Yes" : "No");

                    try {
                        emailSender.sendEmail("NEP Accreditation System: New Accreditation – " + orgProfile.getName(), content, email);
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }

        }
        return result;
    }

    private int getStaging() {

        AuthenticationData authenticationData = SecurityUtil.getCurrentLogin();

        if (authenticationData.getOrganizationProfile() != null) {
            return 1;
        }

        int roleId = role.getRoles();

        if (roleId == RoleName.AccreditationOfficer.getRoleId()) {
            return Staging.Accreditation.getStagingNo();
        }

        if (roleId == RoleName.CivilSocietyUnitChief.getRoleId()) {
            return Staging.CivilSocietyUnitChief.getStagingNo();
        }

        if (roleId == RoleName.GovernanceOfficeSecretary.getRoleId()) {
            return Staging.GovernanceOfficeSecretary.getStagingNo();
        }

        return 0;
    }



    public TrackingApplication getTrackingApp(int id, int stageNo, String stageQuery) {
        if (!stageQuery.isEmpty()) {
            stageQuery = " and oapp.stageno =" + stageNo;
        }
        return trackingApplicationRepo.getTrackingApp(id, stageNo, stageQuery);
    }

    public int sendFollowUp(String content, String orgProfileName, String orgEmailAddress, int orgId) throws AddressException, MessagingException {

        int result = trackingApplicationRepo.saveFollowUp(orgId, content);
        
        if (result == 1) {
        	   
            String recipients = roles.GetOfficersById(RoleName.AccreditationOfficer.getRoleId()).getEmail() 
            		+ "," + roles.GetOfficersById(RoleName.CivilSocietyUnitChief.getRoleId()).getEmail();
        	   
            Email email = new Email();
            email.setSubject("UNEP Accreditation System: Follow Up Accreditation — " + orgProfileName);
            email.setSender(orgEmailAddress);
            email.setRecipient(recipients);
            email.setBody(emailContentMessages.followUp(orgProfileName, content));

            EmailSender.sendEmail(email);
        }

        return result;
    }
}
