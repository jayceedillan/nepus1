package UNEP.AccreditationSystem.Services;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.EmailContentMessages;
import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Entities.Users;
import UNEP.AccreditationSystem.IRepository.MyBase;
import UNEP.AccreditationSystem.Repository.UsersRepo;
import UNEP.AccreditationSystem.Utilities.EmailSender;

@Service
public class UsersService implements MyBase<Users> {

    @Inject
    private UsersRepo usersRepo;

    @Inject
    private EmailContentMessages emailUserContentMessages;

    @Inject
    private PasswordService passwordService;

    @Override
    public int saveData(Users dataItems) throws SQLException, IOException {
        // TODO Auto-generated method stub
        int userId = dataItems.getId();
        String verificationCode = "";

        if (userId == 0) {
            verificationCode = passwordService.generateTemporaryPassword();
            dataItems.setPassword(verificationCode);
        }

        int result = usersRepo.saveData(dataItems);

        if (result == 1) {
            try {
                if (userId == 0) {
                    String emailContent = emailUserContentMessages.NewUserRegistration(dataItems.getName(), dataItems.getEmail(),
                            dataItems.getRoles().getName(), verificationCode);
                    EmailSender.sendEmail("UNEP Accreditation System: User Registration", emailContent, dataItems.getEmail());
                }
            } catch (Exception e) {
                // TODO: handle exception
            }
        }

        return result;
    }

    @Override
    public Users getData(String Name, String Status) {
        // TODO Auto-generated method stub
        return usersRepo.getData(Name, Status);
    }

    public Users getData(String email, String password, int y) throws IOException {
        return usersRepo.getData(email, password, y);
    }

    @Override
    public Users getData(int Id, String Status) throws IOException {
        // TODO Auto-generated method stub
        return usersRepo.getData(Id, Status);
    }

    @Override
    public List<Users> getData(Pagination pagination) {
        // TODO Auto-generated method stub
        return usersRepo.getData(pagination);
    }

    @Override
    public int totalRows(Pagination pagination) {
        // TODO Auto-generated method stub
        return usersRepo.totalRows(pagination);
    }

    public int updateStatus(int id, String status) {
        return usersRepo.updateStatus(id, status);
    }
}
