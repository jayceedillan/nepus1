/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

/**
 * Title: ApplicationService.java<br>
 * Description: FIXME ApplicationService.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 03, 2018
 */

public class ApplicationService {

}
