/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Entities.MultiSelect;
import UNEP.AccreditationSystem.IRepository.IDropdown;
import UNEP.AccreditationSystem.Repository.DropdownRepo;

/**
 * Title: DroddownServices.java<br>
 * Description: FIXME DroddownServices.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 10, 2018
 */

@Service
public class DropdownServices implements IDropdown<MultiSelect> {

    @Inject
    private DropdownRepo dropdownRepo;


    @Override
    public List<MultiSelect> getData(String spName) {
        // TODO Auto-generated method stub
        return dropdownRepo.getData(spName);
    }

    @Override
    public MultiSelect getData(int Id, String spName) {
        // TODO Auto-generated method stub
        return dropdownRepo.getData(Id, spName);
    }

}
