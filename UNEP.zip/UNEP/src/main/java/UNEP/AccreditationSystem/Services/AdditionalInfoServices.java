/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Entities.AdditionalInfo;
import UNEP.AccreditationSystem.Entities.DocumentsUploads;
import UNEP.AccreditationSystem.Entities.MultiSelect;
import UNEP.AccreditationSystem.IRepository.MyBase;
import UNEP.AccreditationSystem.Repository.AdditionalInfoRepo;

/**
 * Title: AdditionalInfoServices.java<br>
 * Description: FIXME AdditionalInfoServices.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 01, 2018
 */
@Service
public class AdditionalInfoServices implements MyBase<AdditionalInfo> {

    @Inject
    private AdditionalInfoRepo additionalInfoRepo;

    @Inject
    private TrackingApplicationService trackingApplicationService;

    @Override
    public int saveData(AdditionalInfo dataItems) throws SQLException, IOException {
        // TODO Auto-generated method stub
        return additionalInfoRepo.saveData(dataItems);
    }

    @Override
    public AdditionalInfo getData(String Name, String Status) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public AdditionalInfo getData(int Id, String Status) throws IOException {
        // TODO Auto-generated method stub
        return additionalInfoRepo.getData(Id, Status);
    }

    @Override
    public List<AdditionalInfo> getData(Pagination pagination) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int totalRows(Pagination pagination) {
        // TODO Auto-generated method stub
        return 0;
    }

    public int saveAdditionalUploads(MultipartFile[] file, String[] colTagging, int id, boolean isSubmit) {

        String constitution = "";
        String financialreport = "";
        String other1 = "";
        String other2 = "";
        int isTracking = 0;
        for (int i = 0; i < file.length; i++) {
            String fileName = file[i].getOriginalFilename();
            String colHeader = colTagging[i];

            switch (colHeader) {
                case "constitution":
                    constitution = fileName;
                    isTracking++;
                    break;
                case "audit":
                    financialreport = fileName;
                    isTracking++;
                    break;
                case "other1":
                    other1 = fileName;
                    isTracking++;
                    break;
                case "other2":
                    other2 = fileName;
                    isTracking++;
                    break;
            }
        }

        int result = 1;
        // if (!constitution.isEmpty() || !financialreport.isEmpty()) {
        DocumentsUploads docUpload = getDocumentsUploads(id);
        if (docUpload.getConstitution() != null){
        	if (constitution.isEmpty() && !docUpload.getConstitution().isEmpty()){
            	constitution = docUpload.getConstitution();
            }
        }
        
        if (docUpload.getFinancialreport() != null){
        	if (financialreport.isEmpty() && !docUpload.getFinancialreport().isEmpty()){
            	financialreport = docUpload.getFinancialreport();
            }
        }
        
        result = additionalInfoRepo.saveAdditionalUploads(constitution, financialreport);
        // }
        // if (result != 0 && (!other1.isEmpty() || !other2.isEmpty())) {
        additionalInfoRepo.updateDocumentOtherUploads();
        // }
        
        if (!other1.isEmpty()) {
        	additionalInfoRepo.saveDocumentOtherUploads(other1);
        }

        if (!other2.isEmpty()) {
        	additionalInfoRepo.saveDocumentOtherUploads(other2);
        }

        if (isSubmit) {
            trackingApplicationService.saveAppTracking(id, "ACTIVE", "");
        }

        return result;
    }

    public DocumentsUploads getDocumentsUploads(int id) {
        return additionalInfoRepo.getDocumentsUploads(id);
    }

    public List<MultiSelect> getDocumentsOthers(int id) {
        return additionalInfoRepo.getDocumentsOthers(id);
    }
}
