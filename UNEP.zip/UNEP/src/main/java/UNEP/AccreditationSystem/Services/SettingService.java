/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.CommonModel;
import UNEP.AccreditationSystem.Repository.SettingRepo;

/**
 * Title: SettingService.java<br>
 * Description: FIXME SettingService.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 03, 2018
 */

@Service
public class SettingService {

    @Inject
    private SettingRepo settingRepo;

    String tableName = "";
    public List<CommonModel> getData(Pagination pagination, int settingType) {
        // TODO Auto-generated method stub
        return settingRepo.getData(pagination, this.getTable(settingType));
    }

    public int totalRows(Pagination pagination, int settingType) {
        // TODO Auto-generated method stub
        return settingRepo.totalRows(pagination, this.getTable(settingType));
    }

    public int SaveSettings(int id, String name, int settingType) {

        StringBuilder sbAdd = new StringBuilder(getQueryAdd(id, name, settingType));

        if (id !=0){
        	StringBuilder sbUpdate = new StringBuilder();

        	sbUpdate.append(" UPDATE " + tableName + " SET createstatus = 'UPDATED' " +  "WHERE  id =" + id );
        	 return settingRepo.saveSettings(sbUpdate,sbAdd); 
        	 
        }
        return settingRepo.saveSettings(sbAdd);
    }
    
    public int updateSettings(int id, int settingType) {
//    	StringBuilder sbAdd = new StringBuilder(getQueryAdd(id, name, settingType));
    		System.out.println("settingtype = "+ settingType);
        	tableName = this.getTable(settingType);
    		StringBuilder sbUpdate = new StringBuilder();
        	sbUpdate.append(" UPDATE " + tableName + " SET createstatus = 'DELETED' " +  "WHERE  id =" + id );
        	return settingRepo.updateSettings(sbUpdate); 

    }

    public String getTable(int settingType) {
        switch (settingType) {
            case 0:
                return Routines.SettingTables.majorGroup;

            case 1:
                return Routines.SettingTables.headquarterOffice;

            case 2:
                return Routines.SettingTables.geographicalScope;

            case 3:
                return Routines.SettingTables.areasOfExpertise;

            case 4:
                return Routines.SettingTables.crossCuttingAreas;

            case 6:
                return Routines.SettingTables.companyCategory;
        }

        return null;
    }

    public String getMessage(int settingType) {
        switch (settingType) {
            case 0:
                return Routines.SettingMessages.majorGroup;

            case 1:
                return Routines.SettingMessages.headquarterOffice;

            case 2:
                return Routines.SettingMessages.geographicalScope;

            case 3:
                return Routines.SettingMessages.areasOfExpertise;

            case 4:
                return Routines.SettingMessages.crossCuttingAreas;

            case 6:
                return Routines.SettingMessages.companyCategory;
        }

        return null;
    }

    
    public StringBuilder getQueryAdd(int id, String name, int settingType) {

        // StringBuilder sb = new StringBuilder("IF NOT EXISTS(SELECT * FROM ");
        StringBuilder sb = new StringBuilder();
      
        switch (settingType) {
            case 0:
                tableName = Routines.SettingTables.majorGroup;
                break;
            case 1:
                tableName = Routines.SettingTables.headquarterOffice;
                break;
            case 2:
                tableName = Routines.SettingTables.geographicalScope;
                break;
            case 3:
                tableName = Routines.SettingTables.areasOfExpertise;
                break;
            case 4:
                tableName = Routines.SettingTables.crossCuttingAreas;
                break;
            case 6:
                tableName = Routines.SettingTables.companyCategory;

        }
            sb.append(" INSERT INTO " + tableName + " (name)  "+ "VALUES(" + "'" + name + "'" + ");");

        return sb;
    }
}
