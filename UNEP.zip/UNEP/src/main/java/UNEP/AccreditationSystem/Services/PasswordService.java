package UNEP.AccreditationSystem.Services;

import java.util.UUID;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.EmailContentMessages;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.Users;
import UNEP.AccreditationSystem.Repository.OrganizationProfileRepo;
import UNEP.AccreditationSystem.Repository.PasswordRepo;
import UNEP.AccreditationSystem.Security.SecurityUtil;
import UNEP.AccreditationSystem.Utilities.EmailSender;

/**
 * Copyright (c) ADEC Innovations Inc. 2018. All Rights Reserved.
 *
 * SDT DEV Team
 *
 * @author jean.delacruz
 * @version: 1.0
 * @since Jun 1, 2018
 */

@Service
public class PasswordService {

    @Inject
    private OrganizationProfileRepo orgProfileRepo;

    @Inject
    private PasswordRepo passwordRepo;

    // @Inject
    // private UsersRepo usersRepo;

    @Inject
    private UsersService usersService;

    @Inject
    private EmailContentMessages emailUserContentMessages;


    public boolean forgotPassword(String emailAddress) {
        Boolean success = false;

        try {
            OrganizationProfile orgProfile = orgProfileRepo.getDataByVerifiedEmailAddress(emailAddress);

            if (orgProfile != null) {
                orgProfile.setPassword(this.generateTemporaryPassword());
                orgProfile.setIsTemporaryPassword(true);
                passwordRepo.add(orgProfile);

                EmailService emailService = new EmailService(EmailService.FORGETPASSWORD, orgProfile);
                Thread t2 = new Thread(emailService);
                t2.start();

                success = true;
            }

            Users users = usersService.getData(emailAddress, "");

            if (users != null) {
                users.setPassword(this.generateTemporaryPassword());
                users.setIsTemporaryPassword(true);
                users.setChangePassword(1);
                success = true;

                if (usersService.saveData(users) == 1) {

                    String emailContent = emailUserContentMessages.RecoveryPassword(users.getName(), users.getEmail(), users.getRoles().getName(),
                            users.getPassword());
                    EmailSender.sendEmail("UNEP Accreditation System:Recover Password Notification", emailContent, users.getEmail());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

        return success;
    }

    public boolean changePassword(String newPassword, boolean isChangePassword) {
        Boolean success = false;

        try {

            if (SecurityUtil.getCurrentLogin().getOrganizationProfile() != null) {
                OrganizationProfile orgSession = SecurityUtil.getCurrentLogin().getOrganizationProfile();

                if (orgSession != null) {
                    orgSession.setPassword(newPassword);
                    orgSession.setIsTemporaryPassword(isChangePassword);
                    passwordRepo.add(orgSession);
                    success = true;
                }
            }

            if (SecurityUtil.getCurrentLogin().getUsers() != null) {
                Users user = SecurityUtil.getCurrentLogin().getUsers();
                user.setPassword(newPassword);
                user.setChangePassword(1);
                usersService.saveData(user);
                success = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            // throw e;
        }

        return success;
    }

    public String generateTemporaryPassword() {
        return (String) UUID.randomUUID().toString().replaceAll("-", "").subSequence(0, 8);
    }
}


