/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Entities.Dashboard;
import UNEP.AccreditationSystem.Repository.DashboardRepo;

/**
 * Title: DashboardService.java<br>
 * Description: FIXME DashboardService.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 27, 2018
 */

@Service
public class DashboardService {

    @Inject
    private DashboardRepo dashboardRepo;

    @Inject
    private OrganizationCountdownService organizationCountdownService;

    public Dashboard getDashboard() {

        Dashboard dashboard = new Dashboard();
        dashboard = dashboardRepo.getDashboard();
        dashboard.setCountdown10Days(organizationCountdownService.get10DaysCountdown().size());

        return dashboard;
    }
}
