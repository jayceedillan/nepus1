/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import UNEP.AccreditationSystem.Entities.ResponseMessage;

/**
 * Title: ResponseService.java<br>
 * Description: FIXME ResponseService.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 31, 2018
 */
public class RespService {


    public static ResponseMessage responseSuccess(String Header, String message) {

        ResponseMessage responseMessage = new ResponseMessage();

        responseMessage.setSuccess(message);
        responseMessage.setHeader(Header);

        return responseMessage;
    }

    public static ResponseMessage responseError(String Header, String message) {

        ResponseMessage responseMessage = new ResponseMessage();

        responseMessage.setError(message);
        responseMessage.setHeader(Header);

        return responseMessage;
    }
}
