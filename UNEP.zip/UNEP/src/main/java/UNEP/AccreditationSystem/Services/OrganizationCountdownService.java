/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import java.util.List;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.EmailContentMessages;
import UNEP.AccreditationSystem.Common.EmailSubjects;
import UNEP.AccreditationSystem.Common.Role;
import UNEP.AccreditationSystem.Common.RoleName;
import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.Repository.OrganizationCountdownRepo;
import UNEP.AccreditationSystem.Utilities.EmailSender;

/**
 * Title: OrganizationCountdownService.java<br>
 * Description: FIXME OrganizationCountdownService.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 06, 2018
 */

@Service
public class OrganizationCountdownService {

    @Inject
    private OrganizationCountdownRepo organizationCountdownRepo;

    @Inject
    private EmailSender emailSender;

    @Inject
    private EmailContentMessages emailContentMessages;

    @Inject
    private Role roles;

    public List<OrganizationInfo> get10DaysCountdown() {
        return organizationCountdownRepo.get10DaysCountdown();
    }

    public boolean sendEmail10Days() throws AddressException, MessagingException {

        List<OrganizationInfo> organizationInfo = organizationCountdownRepo.get10DaysCountdown();

        for (OrganizationInfo organizationInfos : organizationInfo) {

            String emailContent = emailContentMessages.followUp(organizationInfos.getName(), "Follow up");
            String emailAddress = roles.GetOfficersById(RoleName.CivilSocietyUnitChief.getRoleId()).getEmail();
            emailAddress += "," + roles.GetOfficersById(RoleName.GovernanceOfficeSecretary.getRoleId()).getEmail();
            emailSender.sendEmail(EmailSubjects.REMINDER, emailContent, emailAddress);
        }

        return true;
    }

    public void process30Days() {

        List<OrganizationInfo> organizationInfo = organizationCountdownRepo.get30DaysCountdown();

        for (OrganizationInfo organizationInfos : organizationInfo) {
            organizationCountdownRepo.organization_deleted(organizationInfos.getId(), organizationInfos.getOrganization_id());
        }

    }

}
