/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Common.SPNames;
import UNEP.AccreditationSystem.Common.Status;
import UNEP.AccreditationSystem.Entities.AccreditationList;
import UNEP.AccreditationSystem.Entities.CommonModel;
import UNEP.AccreditationSystem.Entities.InternationalScope;
import UNEP.AccreditationSystem.Entities.MultiSelect;
import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.IRepository.MyBase;
import UNEP.AccreditationSystem.Repository.OrganizationInfoRepo;
import UNEP.AccreditationSystem.Utilities.ConvertImages;

/**
 * Title: OrganizationServices.java<br>
 * Description: FIXME OrganizationServices.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 29, 2018
 */

@Service
public class OrganizationInfoServices implements MyBase<OrganizationInfo> {

    @Inject
    private OrganizationInfoRepo organizationInfoRepo;

    @Inject
    private DropdownServices dropdownServices;

    @Inject
    private ConvertImages convertImages;

    @Inject
    private OrganizationCountdownService organizationCountdownService;

    @Override
    public int saveData(OrganizationInfo dataItems) throws SQLException, IOException {
        // TODO Auto-generated method stub
        return organizationInfoRepo.saveData(dataItems);
    }

    public int saveDataInternational(InternationalScope internationalScope) throws SQLException {
        // TODO Auto-generated method stub
        return organizationInfoRepo.saveDataInternational(internationalScope);
    }

    @Override
    public OrganizationInfo getData(String Name, String Status) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public OrganizationInfo getData(int Id, String Status) throws IOException {
        // TODO Auto-generated method stub

        return organizationInfoRepo.getData(Id, Status);
    }

    public String getLogoByBase64(int id) throws IOException {

        OrganizationInfo organizationInfo = organizationInfoRepo.getData(id, Status.ACTIVE.toString());

        if (organizationInfo != null) {
            String imageBase64 =
                    convertImages.convertImagestoBase64(Routines.imageFolder + "/" + Routines.organization_id + "/" + organizationInfo.getLogo());
            organizationInfo.setProfileImage(imageBase64);

            return imageBase64;
        }
        return null;
    }

    public InternationalScope getData(int id) {
        // TODO Auto-generated method stub
        InternationalScope internationalScope = new InternationalScope();

        CommonModel regional = organizationInfoRepo.getInternationalInfo(id);
        if (regional != null) {
            internationalScope.setId(regional.getId());
            internationalScope.setOtherRegisteredOffices(regional.getName());
        }
        List<MultiSelect> geographicalScope = dropdownServices.getData(SPNames.GeographicalScope);
        List<MultiSelect> areasOfExpertise = dropdownServices.getData(SPNames.AreasOfExpertise);
        List<MultiSelect> crossCutttingAreas = dropdownServices.getData(SPNames.CrossCutttingAreas);


        List<CommonModel> geographicalIDList = organizationInfoRepo.getMultiSelectIDList("sp_organization_geographicalscope_get", id);
        List<CommonModel> expertiseIDList = organizationInfoRepo.getMultiSelectIDList("sp_organization_areaexpertise_get", id);
        List<CommonModel> areasCrossCuttingIDList = organizationInfoRepo.getMultiSelectIDList("sp_organization_areacrosscutting_get", id);

        setSelectedMulti(geographicalScope, geographicalIDList, "");
        setSelectedMulti(areasOfExpertise, expertiseIDList, "sp_organization_areaexpertiseother_get");
        setSelectedMulti(crossCutttingAreas, areasCrossCuttingIDList, "sp_organization_areacrosscuttingother_get");

        internationalScope.setGeographicalScope(geographicalScope);
        internationalScope.setAreasOfExpertise(areasOfExpertise);
        internationalScope.setCrossCuttingAreas(crossCutttingAreas);

        return internationalScope;
    }

    public void setSelectedMulti(List<MultiSelect> setItemsTo, List<CommonModel> setItemsFrom, String spName) {

        for (MultiSelect items : setItemsTo) {
            CommonModel selectedModel = setItemsFrom.stream().filter(x -> items.getId() == x.getId()).findAny().orElse(null);
            if (selectedModel != null) {
                items.setIsSelected(true);

                if (selectedModel.getName().toUpperCase().contains("OTHER")) {
                    String others = organizationInfoRepo.getText(spName);
                    items.setOthers(others);
                    items.setIsSelectedOthers(true);
                }
            }
        }
    }

    @Override
    public List<OrganizationInfo> getData(Pagination pagination) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int totalRows(Pagination pagination) {
        // TODO Auto-generated method stub
        return 0;
    }

    public List<AccreditationList> getAccreditationList(Pagination pagination) {

        organizationCountdownService.process30Days();

        pagination.setSpecialQuery(initFilter(pagination.getSpecialQuery()));
        return organizationInfoRepo.getAccreditationList(pagination);
    }

    public int totalRow(Pagination pagination) {

        // pagination.setSpecialQuery(initFilter(pagination.getSpecialQuery()));
        return organizationInfoRepo.totalRow(pagination);
    }

    private String initFilter(String filterByStatus) {
        String filter = "";

        if (!filterByStatus.toUpperCase().equals("ALL") && !filterByStatus.isEmpty()) {
            filter = "and stageStatus= " + "\'" + filterByStatus + "\'";
        }

        return filter;
    }

    public boolean stateHasPermission(String eventName) {

        List<String> lines = Arrays.asList("ORGANIZATION", "UNDEFINED", "PRINTPDF");

        List<String> result = lines.stream().filter(line -> eventName.toUpperCase().equals(line)).collect(Collectors.toList());

        return result.isEmpty();
    }



}
