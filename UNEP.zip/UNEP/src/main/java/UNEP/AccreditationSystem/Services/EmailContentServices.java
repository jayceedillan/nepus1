/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Entities.EmailContent;
import UNEP.AccreditationSystem.Repository.EmailContentRepo;

/**
 * Title: EmailContentServices.java<br>
 * Description: FIXME EmailContentServices.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 22, 2018
 */

@Service
public class EmailContentServices {

    @Inject
    private EmailContentRepo emailContentRepo;

    public EmailContent GetEmailContent(String SourceTag) {
        return emailContentRepo.GetEmailContent(SourceTag);
    }
}
