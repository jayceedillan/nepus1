/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import java.sql.SQLException;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Entities.InternationalScope;
import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.IRepository.IUNEPMain;
import UNEP.AccreditationSystem.Repository.UnepMainRepo;

/**
 * Title: UnepMainServices.java<br>
 * Description: FIXME UnepMainServices.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@Service
public class UnepMainServices implements IUNEPMain {

    @Inject
    private UnepMainRepo unepMainRepo;


    @Override
    public int SaveData(OrganizationInfo organizationInformation) throws SQLException {
        // TODO Auto-generated method stub
        return unepMainRepo.SaveData(organizationInformation);
    }

    public int saveInternationalScope(InternationalScope internationalScope) throws SQLException {
        // TODO Auto-generated method stub
        return unepMainRepo.saveInternationalScope(internationalScope);
    }

    @Override
    public OrganizationInfo GetOrganizationInformation(int id) {
        // TODO Auto-generated method stub
        return unepMainRepo.GetOrganizationInformation(id);
    }



}
