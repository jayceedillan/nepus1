package UNEP.AccreditationSystem.Services;

import org.springframework.stereotype.Component;

import UNEP.AccreditationSystem.Entities.Email;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Utilities.EmailUtil;
import UNEP.AccreditationSystem.Utilities.PropertyUtil;

@Component
public class EmailService extends Thread {

    private OrganizationProfile orgProfile;
    private String type;
    private String officerEmail;

    public static final String REGISTRATION = "New";
    public static final String REGISTRATION_VERIFICATION_CC = "Registration Verified CC Officer";
    public static final String FORGETPASSWORD = "Forget Password";

    EmailUtil emailUtil = new EmailUtil();

    public EmailService() {

    }

    public EmailService(String type, OrganizationProfile orgProfile) {
        this.type = type;
        this.orgProfile = orgProfile;
    }

    public EmailService(String type, OrganizationProfile orgProfile, String officerEmail) {
        this.type = type;
        this.orgProfile = orgProfile;
        this.officerEmail = officerEmail;
    }

    private static final String SUBJECT_FORGOTPASSWORD = "UNEP: Password Reset";
    private static final String SUBJECT_REGISTRATION = "UNEP: Organization Registration";
    private static final String SUBJECT_REGISTRATION_VERIFY_CC = "UNEP: New Organization Registration";
    private static final String SUBJECT_NEW_USER = "UNEP Accreditation System: User Registration";
    
    
    public void run() {
        switch (this.type) {
            case REGISTRATION:
                sendRegistrationEmail();
                break;
            case REGISTRATION_VERIFICATION_CC:
                ccOfficer();
                break;
            case FORGETPASSWORD:
                sendForgotPasswordEmail();
                break;
        }
    }

    private void sendRegistrationEmail() {
        Email email = new Email();
        email.setRecipient(orgProfile.getEmailAddress());
        email.setSubject(SUBJECT_REGISTRATION);
        email.setBody(getRegistrationContent());

        try {
            emailUtil.sendEmail(email);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getRegistrationContent() {
        StringBuffer content = new StringBuffer("Hello " + this.orgProfile.getName() + "!" + "<br /><br />Thank you for pre-registering at UNEP!"
                + "<br /><br />To complete your registration, please click the link below:" + "<br /><br /><a href=" + PropertyUtil.emailHostIP
                + "/VerifyRegistration/" + this.orgProfile.getVerificationCode() + "'>Please click here to verify account.</a>"
                + "</b><br/><br/>Best Regards," + "<br /><br />The UNEP Team");

        return content.toString();
    }

    private void ccOfficer() {
        Email email = new Email();
        email.setRecipient(this.officerEmail);
        email.setSubject(SUBJECT_REGISTRATION_VERIFY_CC);
        email.setBody(getCCOfficer());

        try {
            emailUtil.sendEmail(email);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    

    private String getCCOfficer() {
        StringBuffer content =
                new StringBuffer("Hello Officer!" + "<br /><br />This is to inform you that a new organization has registered for accreditation."
                        + "<br /><br />Please see details below: " + "<br />Organization Name: " + this.orgProfile.getName()
                        + "<br />Organization Website: " + this.orgProfile.getWebSite() + "<br />Email Address: " + this.orgProfile.getEmailAddress()
                        + "</b><br/><br/>Best Regards," + "<br /><br />The UNEP Team");

        return content.toString();
    }

    private void sendForgotPasswordEmail() {
        Email email = new Email();
        email.setRecipient(this.orgProfile.getEmailAddress());
        email.setSubject(SUBJECT_FORGOTPASSWORD);
        email.setBody(getForgotPasswordContent());

        try {
            emailUtil.sendEmail(email);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getForgotPasswordContent() {

        StringBuffer content = new StringBuffer("Hi " + this.orgProfile.getName() + "!" + "<br /><br />You recently requested to reset your password."
                + "<br /><br />To reset your password, please use below temporary password upon  login." + "<br /><br />Temporary Password: <b>"
                + this.orgProfile.getPassword() + "</b>" + "<br /><br />Best Regards," + "<br /><br />The UNEP Team");

        return content.toString();
    }
    
    
    private void sendNewUserRegistration() {
        Email email = new Email();
        email.setRecipient(orgProfile.getEmailAddress());
        email.setSubject(SUBJECT_REGISTRATION);
        email.setBody(getRegistrationContent());

        try {
            emailUtil.sendEmail(email);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    public OrganizationProfile getOrgProfile() {
        return orgProfile;
    }

    public void setOrgProfile(OrganizationProfile orgProfile) {
        this.orgProfile = orgProfile;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

}
