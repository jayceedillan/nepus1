/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import UNEP.AccreditationSystem.Common.Role;
import UNEP.AccreditationSystem.Common.RoleName;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Common.Status;
import UNEP.AccreditationSystem.Entities.Communicate;
import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.Repository.CommunicationRepo;
import UNEP.AccreditationSystem.Utilities.EmailSender;

/**
 * Title: CommunicationOrg.java<br>
 * Description: FIXME CommunicationOrg.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 18, 2018
 */
@Service
public class CommunicationService {


    @Inject
    private EmailSender emailSender;

    @Inject
    private Role role;

    @Inject
    private CommunicationRepo communicationRepo;

    @Inject
    private Environment env;

    @Inject
    private OrganizationInfoServices organizationInfoServices;

    public int saveCommunicateOrg(MultipartFile[] file, String subject, String content, int id) {

        Communicate communicateOrg = new Communicate();

        communicateOrg.setOrganization_id(id);
        communicateOrg.setSubject(subject);
        communicateOrg.setContent(content);
        communicateOrg.setAttach(file.length != 0 ? file[0].getOriginalFilename() : null);

        int roleId = role.getRoles();

        if (roleId == RoleName.AccreditationOfficer.getRoleId()) {
            communicateOrg.setFrom_role_id(roleId);
        } else if (roleId == RoleName.CivilSocietyUnitChief.getRoleId()) {
            communicateOrg.setTo_role_id(RoleName.AccreditationOfficer.getRoleId());
            communicateOrg.setFrom_role_id(roleId);
        } else if (roleId == RoleName.GovernanceOfficeSecretary.getRoleId()) {
            communicateOrg.setTo_role_id(RoleName.CivilSocietyUnitChief.getRoleId());
            communicateOrg.setFrom_role_id(roleId);
        }

        return communicationRepo.saveCommunicateOrg(communicateOrg);
    }

    public int saveCommunicate(String subject, String content, int id) {

        Communicate communicateOrg = new Communicate();

        communicateOrg.setOrganization_id(id);
        communicateOrg.setSubject(subject);
        communicateOrg.setContent(content);

        int roleId = role.getRoles();

        communicateOrg.setTo_role_id(RoleName.CivilSocietyUnitChief.getRoleId());
        communicateOrg.setFrom_role_id(roleId);

        return communicationRepo.saveCommunicateOrg(communicateOrg);
    }

    public List<Communicate> getCommunicate(int id) {
        return communicationRepo.getCommunicate(id);
    }

    public String sendEmail(String subject, String content, int id, MultipartFile[] file) throws AddressException, MessagingException, IOException {

        String emailAddress = role.getEmailByRoles(id);

        String path = "";
        String fileName = "";
        if (file.length != 0) {
            fileName = file[0].getOriginalFilename();
            path = env.getProperty("mainFolder") + "/" + Routines.communicateFolder + "/" + id + "/" + file[0].getOriginalFilename();
        }

        OrganizationInfo organizationInfo = organizationInfoServices.getData(id, Status.ACTIVE.toString());
        String cc = "";
        if (organizationInfo != null) {
            cc = organizationInfo.getEmail1() + ",";
        }

        cc += role.GetOfficersById(RoleName.AccreditationOfficer.getRoleId()).getEmail();

        String bcc = role.GetOfficersById(RoleName.CivilSocietyUnitChief.getRoleId()).getEmail();
        return emailSender.sendEmail(subject, content, emailAddress, cc, bcc, path, fileName);
    }

    public String sendEmailReturnOfficer(String subject, String content, int id) throws AddressException, MessagingException, IOException {


        String emailAddress = role.GetOfficersById(RoleName.AccreditationOfficer.getRoleId()).getEmail();

        return emailSender.sendEmail(subject, content, emailAddress);
    }

    public List<Communicate> getCommunicateSubjects(int id, int roleId) {
        return communicationRepo.getCommunicateSubjects(id, roleId);
    }

}
