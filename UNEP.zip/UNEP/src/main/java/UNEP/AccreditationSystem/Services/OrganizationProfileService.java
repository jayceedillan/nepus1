/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Services;

import java.util.UUID;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import UNEP.AccreditationSystem.Entities.Maintenance;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Repository.MaintenanceRepo;
import UNEP.AccreditationSystem.Repository.OrganizationProfileRepo;

/**
 * Title: AccountServices.java<br>
 * Description: FIXME AccountServices.java Description
 *
 * @author: jessie.furigay
 * @author jean.delacruz
 * @version: 1.0
 * @since May 10, 2018
 */

@Service
public class OrganizationProfileService implements ICommonService<OrganizationProfile> {

    @Inject
    private OrganizationProfileRepo orgProfileRepo;

    @Inject
    private MaintenanceRepo maintenanceRepo;

    @Override
    public boolean add(OrganizationProfile orgProfile) {
        Boolean success = true;

        String generateCode = UUID.randomUUID().toString();
        String verificationCode = (String) generateCode.replaceAll("-", "").subSequence(0, 25);

        try {
            orgProfile.setVerificationCode(verificationCode);
            success = orgProfileRepo.add(orgProfile);

            EmailService emailOrganization = new EmailService(EmailService.REGISTRATION, orgProfile);
            Thread t2 = new Thread(emailOrganization);
            t2.start();
        } catch (Exception e) {
            success = false;
        }

        return success;
    }

    public boolean verifyRegistration(String verificationCode) {
        Boolean success = false;

        try {
            success = orgProfileRepo.verifyRegistration(verificationCode);

            if (success) {
                OrganizationProfile orgProfile = orgProfileRepo.getDataByVerificationCode(verificationCode);
                String officerEmail = maintenanceRepo.getDataByName(Maintenance.ACCREDOFFICEREMAIL).getValue();

                EmailService emailServiceAdmin = new EmailService(EmailService.REGISTRATION_VERIFICATION_CC, orgProfile, officerEmail);
                Thread t2 = new Thread(emailServiceAdmin);
                t2.start();
            }
        } catch (Exception e) {
            throw e;
        }

        return success;
    }

    @Override
    public boolean update(OrganizationProfile orgProfile) {
        // TODO Auto-generated method stub
        return false;
    }


    @Override
    public boolean delete(int id) {
        // TODO Auto-generated method stub
        return false;
    }


    @Override
    public OrganizationProfile getDataById(int id) {
        // TODO Auto-generated method stub
        return null;
    }


    @Override
    public OrganizationProfile getDataByName(String name) {
        // TODO Auto-generated method stub
        return null;
    }

}
