/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Common.SPNames;
import UNEP.AccreditationSystem.Entities.MultiSelect;
import UNEP.AccreditationSystem.Services.DropdownServices;

/**
 * Title: DropdownAPI.java<br>
 * Description: FIXME DropdownAPI.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 10, 2018
 */

@RestController
@RequestMapping(value = "UNEP/Dropdown")
public class DropdownAPI {

    @Inject
    private DropdownServices dropdownServices;


    @RequestMapping(value = "/AreasOfExpertise", method = RequestMethod.GET)
    public List<MultiSelect> GetAreasOfExpertise() throws Exception {
        return dropdownServices.getData(SPNames.AreasOfExpertise);
    }

    @RequestMapping(value = "/GeographicalScope", method = RequestMethod.GET)
    public List<MultiSelect> GetGeographicalScope() throws Exception {
        return dropdownServices.getData(SPNames.GeographicalScope);
    }

    @RequestMapping(value = "/CrossCutttingAreas", method = RequestMethod.GET)
    public List<MultiSelect> CrossCutttingAreas() throws Exception {
        return dropdownServices.getData(SPNames.CrossCutttingAreas);
    }

    @RequestMapping(value = "/MajorGroup", method = RequestMethod.GET)
    public List<MultiSelect> MajorGroup() throws Exception {
        return dropdownServices.getData(SPNames.MajorGroup);
    }

    @RequestMapping(value = "/Country", method = RequestMethod.GET)
    public List<MultiSelect> Country() throws Exception {
        return dropdownServices.getData(SPNames.Country);
    }

    @RequestMapping(value = "/Role", method = RequestMethod.GET)
    public List<MultiSelect> GetRole() throws Exception {
        return dropdownServices.getData(SPNames.Role);
    }

    @RequestMapping(value = "/GetDropdownOrg", method = RequestMethod.GET)
    public Map<String, Object> GetDropdownOrg() throws Exception {

        Map<String, Object> DropdownList = new HashMap<>();

        DropdownList.put("majorGroup", dropdownServices.getData(SPNames.MajorGroup));
        DropdownList.put("country", dropdownServices.getData(SPNames.Country));
        DropdownList.put("companyCategory", dropdownServices.getData(SPNames.CompanyCategory));

        return DropdownList;

    }


    @RequestMapping(value = "/GetCheckboxInter", method = RequestMethod.GET)
    public Map<String, Object> GetCheckboxInter() throws Exception {

        Map<String, Object> CheckboxList = new HashMap<>();

        CheckboxList.put("geographicalScope", dropdownServices.getData(SPNames.GeographicalScope));
        CheckboxList.put("areasOfExpertise", dropdownServices.getData(SPNames.AreasOfExpertise));
        CheckboxList.put("crossCutttingAreas", dropdownServices.getData(SPNames.CrossCutttingAreas));

        return CheckboxList;

    }


}
