package UNEP.AccreditationSystem.Api;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import UNEP.AccreditationSystem.Common.AlertResponse;
import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Entities.TrackingApplication;
import UNEP.AccreditationSystem.Services.CommunicationService;
import UNEP.AccreditationSystem.Services.RespService;
import UNEP.AccreditationSystem.Services.TrackingApplicationService;
import UNEP.AccreditationSystem.Utilities.WriteUpload;
import UNEP.AccreditationSystem.Validator.OrganizationValidation;

@RestController
@RequestMapping(value = "UNEP/Communication")
public class CommunicationAPI {

    @Inject
    private WriteUpload writeUpload;

    @Inject
    private CommunicationService communicationService;

    @Inject
    private TrackingApplicationService trackingApplicationService;

    @Inject
    private OrganizationValidation organizationValidation;

    @RequestMapping(value = "/getEmailDocs/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getEmailDocs(@PathVariable int id) throws SQLException, IOException {


        Map<String, Object> result = new HashMap<>();
        result.put("emaildocs", communicationService.getCommunicate(id));

        return result;

    }

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<Object> sendEmail(@RequestParam(value = "file", required = true) MultipartFile[] file, String subject, String content,
            String id, boolean isReturn)
            throws IOException, SQLException, ParseException, AddressException, NumberFormatException, MessagingException {

        if (!writeUpload.writeAdditionalFiles(file, Routines.communicateFolder, Integer.parseInt(id))) {

            if (communicationService.sendEmail(subject, content, Integer.parseInt(id), file) == null) {

                if (isReturn) {
                    TrackingApplication trackingApplication = trackingApplicationService.getTrackingApp(Integer.parseInt(id), 1, "");

                    if (trackingApplication.getStatus().equals("RETURN")) {
                        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                                .body(RespService.responseError(Messages.ERR_HEADER, Messages.OrgInfo.RETURN_TO_ORG));
                    }

                    trackingApplicationService.saveAppTracking(Integer.parseInt(id), "RETURN", "");
                }

                if (communicationService.saveCommunicateOrg(file, subject, content, Integer.parseInt(id)) != 0) {
                    return ResponseEntity.ok().headers(AlertResponse.success(""))
                            .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.CommunicationOrg.SUCCESS_EMAIL));
                }
                return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                        .body(RespService.responseError(Messages.ERR_HEADER, Messages.ERROR_SAVING));

            }

        }

        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.ERR_HEADER, Messages.OrgInfo.ERR_UPLOAD_FILES));

    }

    @RequestMapping(value = "/returnOfficer/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> approved(@PathVariable int id, @RequestParam(required = true) String subject,
            @RequestParam(required = true) String content) {

        try {
            if (communicationService.sendEmailReturnOfficer(subject, content, id) == null) {

                if (communicationService.saveCommunicate(subject, content, id) != 0) {
                    return ResponseEntity.ok().headers(AlertResponse.success(""))
                            .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.CommunicationOrg.SUCCESS_EMAIL));
                }
                return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                        .body(RespService.responseError(Messages.ERR_HEADER, Messages.ERROR_SAVING));

            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                    .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SYSTEM));
        }

        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SYSTEM));
    }


    @RequestMapping(value = "/Approved/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> approved(@PathVariable int id, @RequestParam(required = true) boolean isApproved,
            @RequestParam(required = true) String remarks) {

        try {
            String isValid = organizationValidation.allowedApproval(id);
            if (isValid != null) {
                return ResponseEntity.badRequest().headers(AlertResponse.error("")).body(RespService.responseError(Messages.FAILED_HEADER, isValid));
            }

            trackingApplicationService.saveAppTracking(id, isApproved == true ? "APPROVED" : "REJECTED", remarks);

            return ResponseEntity.ok().headers(AlertResponse.success("")).body(RespService.responseError(Messages.SUCCESS_HEADER,
                    isApproved == true ? Messages.OrganizationApproval.SUCCESS_APPROVAL : Messages.OrganizationApproval.SUCCESS_DISAPPROVAL));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                    .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SYSTEM));
        }
    }

}
