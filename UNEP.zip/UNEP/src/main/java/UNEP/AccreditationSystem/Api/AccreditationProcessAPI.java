package UNEP.AccreditationSystem.Api;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Common.AlertResponse;
import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Common.RoleName;
import UNEP.AccreditationSystem.Entities.DocumentAttach;
import UNEP.AccreditationSystem.Entities.extend.Accreditation;
import UNEP.AccreditationSystem.Services.AccreditationProcessService;
import UNEP.AccreditationSystem.Services.AuthenticationService;
import UNEP.AccreditationSystem.Services.CommunicationService;
import UNEP.AccreditationSystem.Services.RespService;
import UNEP.AccreditationSystem.Validator.AccreditationValidator;

@RestController
@RequestMapping(value = "UNEP/AccreditationProcess")
public class AccreditationProcessAPI {

    @Inject
    private AccreditationProcessService accreditationProcessService;

    @Inject
    private AccreditationValidator accreditationValidator;

    @Inject
    private CommunicationService communicationService;

    @Inject
    AuthenticationService authService;

    @RequestMapping(value = "{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> GetOrganizationById(@PathVariable int id) throws SQLException, IOException {

        Map<String, Object> result = new HashMap<>();
        result.put("docList", accreditationProcessService.getDocumentList(id));
        result.put("recommendationContent", accreditationProcessService.getRecommendationContent(id));
        result.put("chief", accreditationProcessService.getOrganizationStatus(id, 3));
        result.put("secretary", accreditationProcessService.getOrganizationStatus(id, 4));
        result.put("subjectChief", communicationService.getCommunicateSubjects(id, RoleName.CivilSocietyUnitChief.getRoleId()));
        result.put("subjectsecretary", communicationService.getCommunicateSubjects(id, RoleName.GovernanceOfficeSecretary.getRoleId()));
        return result;
    }

    @RequestMapping(value = "{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> saveAccreditation(@PathVariable int id, @RequestBody Accreditation documentAttach)
            throws SQLException, IOException, AddressException, MessagingException {

        String message = accreditationValidator.isValid(id);

        if (message != null) {
            return ResponseEntity.badRequest().headers(AlertResponse.error("")).body(RespService.responseError(Messages.ERR_HEADER, message));
        }

        if (accreditationProcessService.saveAccreditationProcess(id, documentAttach) == 1) {
            return ResponseEntity.ok().headers(AlertResponse.success(""))
                    .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.AccreditationProcess.ACCRED_SUCCESS));

        }
        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.ERR_HEADER, Messages.ERROR_SAVING));

    }

    @RequestMapping(value = "download/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void downloadFile(HttpServletRequest request, HttpServletResponse response, @PathVariable int id,
            @RequestBody DocumentAttach documentAttach) throws SQLException, IOException {

        // try {
        PrintWriter out = response.getWriter();
        String filePath = accreditationProcessService.getPath(id, documentAttach);
        File file = new File(filePath);


        String fileName = file.getName().substring(file.getName().lastIndexOf("\\") + 1, file.getName().length());
        String extension = file.getName().substring(file.getName().lastIndexOf(".") + 1, file.getName().length());

        FileInputStream fileToDownload = new FileInputStream(filePath);
        // ServletOutputStream output = response.getOutputStream();
        if (extension.equalsIgnoreCase("txt")) {
            response.setContentType("text/html");
        } else if (extension.equalsIgnoreCase("doc")) {
            response.setContentType("application/msword");
        } else if (extension.equalsIgnoreCase("pdf")) {
            response.setContentType("application/pdf");
        } else if (extension.equalsIgnoreCase("jpg")) {
            response.setContentType("image/jpeg");
        } else if (extension.equalsIgnoreCase("jpeg")) {
            response.setContentType("image/jpeg");
        }
        response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
        response.setContentLength(fileToDownload.available());
        int c;
        while ((c = fileToDownload.read()) != -1) {
            out.write(c);
        }
        out.flush();
        out.close();
        fileToDownload.close();

    }
}
