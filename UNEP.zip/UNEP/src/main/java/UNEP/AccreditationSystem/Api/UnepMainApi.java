/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Api;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.Services.UnepMainServices;

/**
 * Title: UnepMainApi.java<br>
 * Description: FIXME UnepMainApi.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 08, 2018
 */

@RestController
@RequestMapping(value = "UNEP/Accreditation")
public class UnepMainApi {

    @Inject
    private UnepMainServices unepMainServices;

    @RequestMapping(value = "Organization", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> SaveOrganization(@RequestBody OrganizationInfo organizationInformation) throws SQLException {

        int x = unepMainServices.SaveData(organizationInformation);


        return null;
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> GetOrganizationById(@PathVariable int id) throws SQLException, IOException {

        Map<String, Object> organizationInformationMap = new HashMap<>();

        OrganizationInfo organizationInformation = unepMainServices.GetOrganizationInformation(1);


        organizationInformationMap.put("organizationInformation", organizationInformation);

        return organizationInformationMap;

    }


}
