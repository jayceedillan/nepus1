/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Api;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;

import UNEP.AccreditationSystem.Common.AlertResponse;
import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Role;
import UNEP.AccreditationSystem.Common.Routines;
import UNEP.AccreditationSystem.Common.Status;
import UNEP.AccreditationSystem.Entities.AdditionalInfo;
import UNEP.AccreditationSystem.Entities.AuthenticationData;
import UNEP.AccreditationSystem.Entities.DocumentAttach;
import UNEP.AccreditationSystem.Entities.InternationalScope;
import UNEP.AccreditationSystem.Entities.OrganizationInfo;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Entities.UnepMain;
import UNEP.AccreditationSystem.Security.SecurityUtil;
import UNEP.AccreditationSystem.Services.AdditionalInfoServices;
import UNEP.AccreditationSystem.Services.AuthenticationService;
import UNEP.AccreditationSystem.Services.OrganizationInfoServices;
import UNEP.AccreditationSystem.Services.RespService;
import UNEP.AccreditationSystem.Services.TrackingApplicationService;
import UNEP.AccreditationSystem.Utilities.FileUtility;
import UNEP.AccreditationSystem.Utilities.WriteUpload;



/**
 * Title: OrganizationAPI.java<br>
 * Description: FIXME OrganizationAPI.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since May 28, 2018
 */

@RestController
@RequestMapping(value = "UNEP/OrganizationInfo")
public class OrganizationInfoAPI {

    @Inject
    private OrganizationInfoServices organizationInfoServices;

    @Inject
    private AdditionalInfoServices additionalInfoServices;

    @Inject
    private WriteUpload writeUpload;

    @Inject
    private TrackingApplicationService trackingApplicationService;

    @Inject
    AuthenticationService authService;

    @Inject
    private Role role;

    @Autowired
    private Environment env;

    @RequestMapping(value = "/getOrganizationInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public UnepMain getOrganizationInfoById() throws SQLException, IOException {

        // Map<String, Object> OrganizationInfoMap = new HashMap<>();
        UnepMain organizationInfoMap = new UnepMain();

        OrganizationProfile orgProfile = SecurityUtil.getCurrentLogin().getOrganizationProfile();

        InternationalScope internationalScope = organizationInfoServices.getData(Routines.organization_id);
        organizationInfoMap.setInternationalScopeInfo(internationalScope);

        organizationInfoMap.setOrganizationInfo(organizationInfoServices.getData(Routines.organization_id, Status.ACTIVE.toString()));
        organizationInfoMap.setAdditionalInfo(additionalInfoServices.getData(Routines.organization_id, Status.ACTIVE.toString()));
        organizationInfoMap.setOrgProfile(orgProfile);
        organizationInfoMap.setTrackingApplication(trackingApplicationService.getTrackingApp(Routines.organization_id, 1, ""));
        organizationInfoMap.setDocuments(additionalInfoServices.getDocumentsUploads(Routines.organization_id));
        organizationInfoMap.setDocumentsOthers(additionalInfoServices.getDocumentsOthers(Routines.organization_id));

        return organizationInfoMap;
    }

    @RequestMapping(value = "/getOrganizationInfo/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public UnepMain getOrganizationInfoById(@PathVariable int id) throws SQLException, IOException {


        UnepMain organizationInfoMap = new UnepMain();

        OrganizationProfile orgProfile = authService.getDataById(id);

        InternationalScope internationalScope = organizationInfoServices.getData(id);
        organizationInfoMap.setInternationalScopeInfo(internationalScope);

        organizationInfoMap.setOrganizationInfo(organizationInfoServices.getData(id, Status.ACTIVE.toString()));
        organizationInfoMap.setAdditionalInfo(additionalInfoServices.getData(id, Status.ACTIVE.toString()));
        organizationInfoMap.setOrgProfile(orgProfile);
        organizationInfoMap.setTrackingApplication(trackingApplicationService.getTrackingApp(id, 1, ""));
        organizationInfoMap.setUsers(role.getUserRoles());
        organizationInfoMap.setDocuments(additionalInfoServices.getDocumentsUploads(id));
        organizationInfoMap.setDocumentsOthers(additionalInfoServices.getDocumentsOthers(id));

        return organizationInfoMap;

    }

    @RequestMapping(value = "/getPrintPDFById/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getPrintPDFById(@PathVariable int id) throws SQLException, IOException {
        Map<String, Object> result = new HashMap<>();
        result.put("organizationInfo", organizationInfoServices.getData(id, Status.ACTIVE.toString()));

        return result;
    }

    @RequestMapping(value = "getLogo/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getLogo(@PathVariable int id) throws SQLException, IOException {

        String imageBase64 = organizationInfoServices.getLogoByBase64(id);

        Map<String, Object> base64 = new HashMap<>();
        base64.put("baseImage64", imageBase64);

        return base64;

    }


    @RequestMapping(value = "/getInternationalScopeInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getInternationalInfo() throws SQLException, IOException {

        Map<String, Object> result = new HashMap<>();

        result.put("orgProfile", organizationInfoServices.getData(Routines.organization_id));

        return result;
    }

    @RequestMapping(value = "/getAdditionalInfo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getAdditionalInfo() throws SQLException, IOException {

        Map<String, Object> result = new HashMap<>();

        result.put("additionalInfo", additionalInfoServices.getData(Routines.organization_id, Status.ACTIVE.toString()));

        return result;

    }

    @RequestMapping(value = "saveOrganizationInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> saveOrganizationInfo(@RequestBody OrganizationInfo organizationInfo) throws SQLException, IOException {

        if (organizationInfoServices.saveData(organizationInfo) == 1) {
            return ResponseEntity.ok().headers(AlertResponse.success(""))
                    .body(RespService.responseSuccess(Messages.OrgInfo.ORG_NEW_HEADER, Messages.OrgInfo.ORG_SUCCESS));
        }

        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.ERR_HEADER, Messages.ERROR_SAVING));


    }

    @RequestMapping(value = "internalScope", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> saveItems(@RequestBody InternationalScope internationalScope) throws SQLException {

        if (organizationInfoServices.saveDataInternational(internationalScope) == 1) {
            return ResponseEntity.ok().headers(AlertResponse.success(""))
                    .body(RespService.responseSuccess(Messages.OrgInfo.INT_NEW_HEADER, Messages.OrgInfo.INT_SUCCESS));

        }
        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.ERR_HEADER, Messages.ERROR_SAVING));


    }


    @RequestMapping(value = "/saveAdditional", method = RequestMethod.POST)
    public ResponseEntity<Object> saveAdditional(@RequestParam(value = "file", required = true) MultipartFile[] file, String additionalInfo)
            throws IOException, SQLException, ParseException {


        if (!writeUpload.writeAdditionalFiles(file, Routines.additionalFolder, Routines.organization_id)) {
            AdditionalInfo additionalInfos = new ObjectMapper().readValue(additionalInfo, AdditionalInfo.class);
            if (additionalInfoServices.saveData(additionalInfos) == 1) {
                return ResponseEntity.ok().headers(AlertResponse.success(""))
                        .body(RespService.responseSuccess(Messages.OrgInfo.ADD_NEW_HEADER, Messages.OrgInfo.ADD_SUCCESS));
            }

            return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                    .body(RespService.responseError(Messages.ERR_HEADER, Messages.ERROR_SAVING));


        } else {

            return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                    .body(RespService.responseError(Messages.ERR_HEADER, Messages.OrgInfo.ERR_UPLOAD_FILES));

        }

    }

    @RequestMapping(value = "/saveDocumentUploads", method = RequestMethod.POST)
    public ResponseEntity<Object> saveDocumentUploads(@RequestParam(value = "file", required = true) MultipartFile[] file, String[] colTagging,
            boolean isSubmit) throws IOException, SQLException, ParseException {

        if (file.length == 0 && colTagging.length == 0) {
            return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                    .body(RespService.responseError(Messages.ERR_HEADER, Messages.OrgInfo.ERR_EMPTY_UPLOAD_FILES));
        }

        if (!writeUpload.writeAdditionalFiles(file, Routines.documentFolder, Routines.organization_id)) {

            if (additionalInfoServices.saveAdditionalUploads(file, colTagging, Routines.organization_id, isSubmit) == 1) {
                return ResponseEntity.ok().headers(AlertResponse.success(""))
                        .body(RespService.responseSuccess(Messages.OrgInfo.DOC_NEW_HEADER, Messages.OrgInfo.DOC_SUCCESS));
            } else {
                return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                        .body(RespService.responseError(Messages.ERR_HEADER, Messages.ERROR_SAVING));
            }
        }
        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.ERR_HEADER, Messages.OrgInfo.ERR_UPLOAD_FILES));

    }

    @RequestMapping(value = "/trackApplication/{stageNo}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> validateActiveUser(@PathVariable int stageNo) throws Exception {

        Map<String, Object> result = new HashMap<>();
        result.put("trackingAppInfo", trackingApplicationService.getTrackingApp(Routines.organization_id, 1, ""));

        return result;
    }

    @RequestMapping(value = "/getTrackApplication/{orgId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getTrackApplication(@PathVariable int orgId) throws Exception {

        Map<String, Object> result = new HashMap<>();
        result.put("trackingAppInfo", trackingApplicationService.getTrackingApp(orgId, 1, ""));

        return result;
    }


    @RequestMapping(value = "/getAccreditationList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getAccreditationList(Pagination pagination) throws Exception {



        Map<String, Object> result = new HashMap<>();
        result.put("accreditationList", organizationInfoServices.getAccreditationList(pagination));
        result.put("totalRows", organizationInfoServices.totalRow(pagination));
        return result;
    }

    @RequestMapping(value = "export/pdf", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> exportToPdf(@RequestBody String imageBytes, @RequestParam int heigth, HttpServletResponse httpServletResponse) {
        String base65String = "data:image/png;base64,";
        byte[] decoded;
        ByteArrayInputStream byteArrayInputStream = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        ByteArrayOutputStream pdfOutputStream = null;
        BufferedImage bufferedImage = null;
        OutputStream outputStream = null;
        Rectangle rectangle;
        Document document;

        try {
            String decodedString = imageBytes.substring(base65String.length());

            // convert the string to byte array
            decoded = Base64.decodeBase64(decodedString.getBytes());

            // initialize streams
            outputStream = httpServletResponse.getOutputStream();
            byteArrayInputStream = new ByteArrayInputStream(decoded);
            byteArrayOutputStream = new ByteArrayOutputStream();
            pdfOutputStream = new ByteArrayOutputStream();

            bufferedImage = ImageIO.read(byteArrayInputStream);
            ImageIO.write(bufferedImage, "png", byteArrayOutputStream);

            // place the original image
            Image originalImage = Image.getInstance(byteArrayOutputStream.toByteArray());


            // initialize the document, the size of the document and the attributes

            rectangle = new Rectangle(originalImage.getWidth(), 841);
            document = new Document(rectangle);
            document.setMargins(0, 0, 0, 0);

            byteArrayOutputStream.reset();
            bufferedImage = bufferedImage.getSubimage(0, 0, (int) originalImage.getWidth(), (int) originalImage.getHeight());
            ImageIO.write(bufferedImage, "png", byteArrayOutputStream);
            Image image = Image.getInstance(byteArrayOutputStream.toByteArray());

            // initialize servlet output stream

            // open the pdf then add the first image page
            PdfWriter.getInstance(document, pdfOutputStream);
            document.open();
            document.add(image);

            int y = (int) rectangle.getHeight();

            while (y < heigth) {
                int rectangleHeight = (int) rectangle.getHeight();
                // if the next image page is smaller than the pdf page,
                // change the rectangle's height so the offset won't throw an error
                if ((y + rectangle.getHeight()) > originalImage.getHeight()) {
                    rectangleHeight = (int) originalImage.getHeight() - y;
                }

                // reset the sreams to re-read the bytes
                byteArrayInputStream.reset();
                byteArrayOutputStream.reset();

                bufferedImage = ImageIO.read(byteArrayInputStream);
                bufferedImage = bufferedImage.getSubimage(0, y, (int) originalImage.getWidth(), rectangleHeight);
                ImageIO.write(bufferedImage, "png", byteArrayOutputStream);
                document.add(Image.getInstance(byteArrayOutputStream.toByteArray()));
                y += rectangle.getHeight();
            }

            document.close();
            httpServletResponse.setHeader("Content-Disposition", "attachment; filename=" + "UNEP -" + Routines.getEkey().replace(".", "") + ".pdf");
            httpServletResponse.setContentType("application/pdf");
            httpServletResponse.setContentLength(pdfOutputStream.size());
            pdfOutputStream.writeTo(outputStream);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Unable to export the PDF");
        } finally {
            if (byteArrayInputStream != null) {
                try {
                    byteArrayInputStream.close();
                } catch (IOException ignored) {
                }
            }

            if (byteArrayOutputStream != null) {
                try {
                    byteArrayOutputStream.close();
                } catch (IOException ignored) {
                }
            }

            if (bufferedImage != null) {
                bufferedImage.flush();
            }

            if (pdfOutputStream != null) {
                try {
                    pdfOutputStream.close();
                } catch (IOException ignored) {
                }
            }

            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException ignored) {
                }
            }

            System.gc();
        }

        return ResponseEntity.ok().body("Successfully exported the pdf");
    }

    @RequestMapping(value = "/activeUser/{eventName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> validateActiveUser(@PathVariable String eventName) throws Exception {

        AuthenticationData authenticationData = SecurityUtil.getCurrentLogin();

        Map<String, Object> result = new HashMap<>();
        result.put("authenticationData", authenticationData);
        result.put("trackingAppInfo", trackingApplicationService.getTrackingApp(Routines.organization_id, 1, ""));

        if (authenticationData.getOrganizationProfile() != null) {
            if (organizationInfoServices.stateHasPermission(eventName)) {
                result.put("noPermission", "401");
            }
        } else {
            if (authenticationData.getUsers() != null) {
                if (eventName.equals("Organization")) {
                    result.put("noPermission", "401");
                }
            }
        }

        return result;
    }

    @RequestMapping(value = "downloadFile", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void downloadFile(@RequestBody DocumentAttach document, HttpServletResponse httpServletResponse) throws IOException {

        PrintWriter out = httpServletResponse.getWriter();
        String mainfolder = env.getProperty("mainFolder") + "/";
        FileInputStream fileToDownload = new FileInputStream(FileUtility.getFilePath(mainfolder, document));

        String extension = FileUtility.getFileExternsion(document.getName());
        httpServletResponse.setContentType(FileUtility.getContentType(extension));
        httpServletResponse.setHeader("Content-Disposition", "attachment; filename=" + document.getName());
        httpServletResponse.setContentLength(fileToDownload.available());
        int c;
        while ((c = fileToDownload.read()) != -1) {
            out.write(c);
        }
        out.flush();
        out.close();
        fileToDownload.close();
    }
}
