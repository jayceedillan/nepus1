/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Api;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Entities.Dashboard;
import UNEP.AccreditationSystem.Services.DashboardService;

/**
 * Title: DashboardAPI.java<br>
 * Description: FIXME DashboardAPI.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 27, 2018
 */

@RestController
@RequestMapping(value = "UNEP/Dashboard")
public class DashboardAPI {

    @Inject
    private DashboardService dashboardService;



    @RequestMapping(method = RequestMethod.GET)
    public Dashboard GetAreasOfExpertise() throws Exception {

        return dashboardService.getDashboard();
    }

}
