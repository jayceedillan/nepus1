/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Api;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.validation.Valid;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Common.AlertResponse;
import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Status;
import UNEP.AccreditationSystem.Entities.Users;
import UNEP.AccreditationSystem.Services.RespService;
import UNEP.AccreditationSystem.Services.UsersService;
import UNEP.AccreditationSystem.Validator.PasswordValidator;

/**
 * Title: UsersAPI.java<br>
 * Description: FIXME UsersAPI.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since June 13, 2018
 */

@RestController
@RequestMapping("UNEP/Users")
public class UsersAPI {


    @Inject
    private UsersService usersService;

    @Inject
    private PasswordValidator passwordValidator;

    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> saveUsers(@Valid @RequestBody Users users) throws SQLException, AddressException, MessagingException, IOException {

        if (users.getId() == 0) {
            if (usersService.getData(users.getEmail(), Status.ACTIVE.toString()).getId() != 0) {
                return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                        .body(RespService.responseError(Messages.FAILED_HEADER, Messages.Registration.EMAIL_ADDRESS_EXIST));
            }

            users.setChangePassword(1);
        } else {
            if (users.getPassword() != null) {
                if (!passwordValidator.isAlphaNumericWithUpperCase(users.getPassword())) {
                    return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                            .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ChangePassword.PASSWORD_FORMAT_INCORRECT));
                }
            }
            {
                users.setChangePassword(0);
            }
        }

        if (usersService.saveData(users) == 1) {

            return ResponseEntity.ok().headers(AlertResponse.success(""))
                    .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.User.SUCCESS_USER));
        }

        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SAVING));
    }

    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getUsers(Pagination pagination) throws SQLException, IOException {

        Map<String, Object> result = new HashMap<>();
        result.put("users", usersService.getData(pagination));
        result.put("usersCount", usersService.totalRows(pagination));

        return result;
    }

    @RequestMapping(value = "{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Users getUsersById(@PathVariable int id) throws SQLException, IOException {
        return usersService.getData(id, Status.ACTIVE.toString());
    }

    @RequestMapping(value = "update/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> updateUsers(@PathVariable int id) throws SQLException, AddressException, MessagingException, IOException {

        if (usersService.updateStatus(id, Status.DELETED.toString()) == 1) {
            return ResponseEntity.ok().headers(AlertResponse.success(""))
                    .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.User.DELETE_USER));
        }

        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SAVING));
    }

}
