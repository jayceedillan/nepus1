/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Api;

import java.sql.SQLException;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.validation.Valid;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Common.AlertResponse;
import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Services.OrganizationProfileService;
import UNEP.AccreditationSystem.Services.RespService;
import UNEP.AccreditationSystem.Validator.OrganizationValidation;

/**
 * Title: Organization.java<br>
 * Description: FIXME Organization.java Description
 *
 * @author: jessie.furigay
 * @author jean.delacruz
 * @version: 1.0
 * @since May 10, 2018
 */

@RestController
@RequestMapping(value = "UNEP/OrganizationProfile")
public class OrganizationProfileAPI {

    @Inject
    private OrganizationValidation validator;

    @Inject
    private OrganizationProfileService service;

    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> saveProfile(@Valid @RequestBody OrganizationProfile organizationProfile)
            throws SQLException, AddressException, MessagingException {

        String validationMessage = validator.validate(organizationProfile);
        if (validationMessage != null) {
            return ResponseEntity.badRequest().headers(AlertResponse.error(validationMessage)).body(RespService.responseError(Messages.FAILED_HEADER, validationMessage));
        }

        if (service.add(organizationProfile)) {
            return ResponseEntity.ok().headers(AlertResponse.success("")).body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.Registration.SUCCESS_REGISTRATION));

        } else {
            return ResponseEntity.badRequest().headers(AlertResponse.error("")).body(RespService.responseError(Messages.FAILED_HEADER, Messages.Registration.ERROR_REGISTRATION));
        }
    }

    @RequestMapping(value = "/verify", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> verifyOrganization(@RequestParam(required = true) String code)
            throws SQLException, AddressException, MessagingException {

    	try{
	        if (service.verifyRegistration(code)) {
	            return ResponseEntity.ok().headers(AlertResponse.success("")).body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.Registration.SUCCESS_VERIFY));
	        } else {
	            return ResponseEntity.badRequest().headers(AlertResponse.error("")).body(RespService.responseError(Messages.FAILED_HEADER, Messages.Registration.ERROR_VERIFY));
	        }
    	}catch(Exception e){
    		e.printStackTrace();
    		return ResponseEntity.badRequest().headers(AlertResponse.error("")).body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SYSTEM));
    	}
    }
}
