/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Api;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Common.AlertResponse;
import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Services.PasswordService;
import UNEP.AccreditationSystem.Services.RespService;
import UNEP.AccreditationSystem.Validator.PasswordValidator;

/**
 * 
 * @author jean.delacruz
 * @version: 1.0
 * @since Jun 1, 2018
 */

@RestController
@RequestMapping("UNEP/Password")
public class PasswordAPI {

    @Inject
    private PasswordValidator validator;

    @Inject
    PasswordService passwordService;

    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, value = "/forgot")
    public ResponseEntity<Object> forgotPassword(@RequestParam(required = true) String emailAddress) {

        try {
            if (passwordService.forgotPassword(emailAddress)) {
                return ResponseEntity.ok().headers(AlertResponse.error(""))
                        .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.ForgotPassword.SUCCESS));
            } else {
                return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                        .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ForgotPassword.ERROR));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                    .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SYSTEM));
        }
    }

    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, value = "/change")
    public ResponseEntity<Object> changePassword(@RequestParam(required = true) String oldPassword, @RequestParam(required = true) String newPassword,
            @RequestParam(required = true) String confirmPassword, @RequestParam(required = true) boolean isChangePassword) {

        try {
            String validationMessage = validator.validate(oldPassword, newPassword, confirmPassword);
            if (validationMessage != null) {
                return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                        .body(RespService.responseError(Messages.FAILED_HEADER, validationMessage));
            }

            if (passwordService.changePassword(newPassword, isChangePassword)) {
                return ResponseEntity.ok().headers(AlertResponse.error(""))
                        .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.ChangePassword.SUCCESS));
            } else {
                return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                        .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ChangePassword.ERROR));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                    .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SYSTEM));
        }
    }

}
