/*
 * Copyright (c) ADEC Innovations Inc. 2016. All Rights Reserved.
 *
 * BSD DEV Team
 */
package UNEP.AccreditationSystem.Api;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Common.AlertResponse;
import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Common.Pagination;
import UNEP.AccreditationSystem.Common.Status;
import UNEP.AccreditationSystem.Services.RespService;
import UNEP.AccreditationSystem.Services.SettingService;

/**
 * Title: SettingsAPI.java<br>
 * Description: FIXME SettingsAPI.java Description
 *
 * @author: jessie.furigay
 * @version: 1.0
 * @since July 03, 2018
 */

@RestController
@RequestMapping(value = "UNEP/Settings")
public class SettingsAPI {

    @Inject
    private SettingService settingService;

    @RequestMapping(value = "{settingType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> getSettings(@PathVariable int settingType, Pagination pagination) throws SQLException, IOException {

        Map<String, Object> result = new HashMap<>();
        result.put("setting", settingService.getData(pagination, settingType));
        result.put("settingCount", settingService.totalRows(pagination, settingType));

        return result;
    }

    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> SaveSetting(@RequestParam(required = true) int id, @RequestParam(required = true) String name,
            @RequestParam(required = true) int settingType) throws Exception {

        settingService.SaveSettings(id, name, settingType);
        return ResponseEntity.ok().headers(AlertResponse.success(""))
                .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, settingService.getMessage(settingType) + " successfully saved." ));
    }
    
    @RequestMapping(value = "update/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> updateSettings(@PathVariable int id, int settingType)throws IOException {

        if (settingService.updateSettings(id, settingType) == 1) {
            return ResponseEntity.ok().headers(AlertResponse.success(""))
                    .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, settingService.getMessage(settingType) + " successfully updated."));
        }

        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SAVING));
    }
    
    
}
