package UNEP.AccreditationSystem.Api;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import UNEP.AccreditationSystem.Common.AlertResponse;
import UNEP.AccreditationSystem.Common.Messages;
import UNEP.AccreditationSystem.Entities.OrganizationProfile;
import UNEP.AccreditationSystem.Security.SecurityUtil;
import UNEP.AccreditationSystem.Services.RespService;
import UNEP.AccreditationSystem.Services.TrackingApplicationService;

@RestController
@RequestMapping(value = "UNEP/TrackingApplication")
public class TrackingApplicationAPI {

    @Inject
    TrackingApplicationService trackApplicationService;

    @RequestMapping(value = "/sendFollowUp", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> sendFollowUp(@RequestParam(required = true) String content) throws AddressException, MessagingException {

        OrganizationProfile orgProfile = SecurityUtil.getCurrentLogin().getOrganizationProfile();
        if (trackApplicationService.sendFollowUp(content, orgProfile.getName(), orgProfile.getEmailAddress(), orgProfile.getId()) == 1) {
            return ResponseEntity.ok().headers(AlertResponse.success(""))
                    .body(RespService.responseSuccess(Messages.SUCCESS_HEADER, Messages.CommunicationOrg.SUCCESS_EMAIL));
        }
        return ResponseEntity.badRequest().headers(AlertResponse.error(""))
                .body(RespService.responseError(Messages.FAILED_HEADER, Messages.ERROR_SYSTEM));
    }
}
