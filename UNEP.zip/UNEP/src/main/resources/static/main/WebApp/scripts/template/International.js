app.directive("myInternational", function() {
  return {
    restrict: "A",   
    templateUrl: "main/WebApp/app/organization/international/InternationalScope.html",
    controller: 'InternationalController',
    controllerAs: 'vmInternational',
    replace:true,
    bindToController: true, //required in 1.3+ with controllerAs
  };
});