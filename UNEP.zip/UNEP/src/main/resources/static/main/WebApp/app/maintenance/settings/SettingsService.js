(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('SettingsService', SettingsService);

    SettingsService.$inject = ['$http'];
   
    function SettingsService($http) {
        var factory = {        
        	saveSettings:saveSettings,
        	getSettings:getSettings,
        	updateSettings:updateSettings
        };

        return factory;
        
       
        
        function saveSettings(id,name,settingType){
        	return $http({
                method: 'POST',
                url: 'UNEP/Settings',
                params: {id:id,name : name,
                	settingType:settingType}                
            })
        }     
        
        function getSettings(paginationObject,settingType){        	
        	return $http({
                method: 'GET',
                url: 'UNEP/Settings/' + settingType,
                params: paginationObject
            })
            
        }
        
        function updateSettings(id,settingType){
        	return $http({
                method: 'POST',
                url: 'UNEP/Settings/update/' + id,
                params: {settingType:settingType}   
            })
        }
        
        
    }
})();