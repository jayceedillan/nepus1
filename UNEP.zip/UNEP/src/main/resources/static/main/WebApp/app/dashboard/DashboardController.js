(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('DashboardController', DashboardController);

    DashboardController.$inject = ['$state','DashboardService','ValidationService','Constants','UnepOrganization'];   
    
    function DashboardController($state,DashboardService,ValidationService,Constants,UnepOrganization) {

        var vm = this;   
        
        vm.goTo=goTo;
        UnepOrganization.pageTitle();
        
        onInit();
        
        function onInit(){
        	
        	DashboardService.getDashboarInfo()
            .then(function (result) {
            	vm.dashboardInfo= result.data;
            	
            	if (result.data.countdown10Days !==0){
            		ValidationService.showAlert('REMINDER',
            				'You only have less than 10 days to accredit ' + result.data.countdown10Days + ' organisations. Please check your mailbox for details.'
            				, Constants.messageTypes.errorWarning);
            	}
             });  
        	
        }
        
        function goTo(id){
        	
        	switch (id){
        	case 1:
        		$state.go('AccreditationList');
        		return;
        	}
        	
        	ValidationService.showAlert('On going','Under constructions', Constants.messageTypes.errorWarning);
        }
        
    }
    
})();


