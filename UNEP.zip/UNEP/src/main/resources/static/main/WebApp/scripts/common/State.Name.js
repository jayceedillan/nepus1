app.constant(
	'Wizard',
	{
		StateName : {						
			Organization:'Organization',
			International:'International',
			AdditionalInformation: 'AdditionalInformation'
		}
	});
