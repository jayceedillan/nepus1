(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('ForgotPasswordController', ForgotPasswordController);

    ForgotPasswordController.$inject = ['ForgotPasswordServices','ValidationService', '$state', 'Constants'];   
    
    function ForgotPasswordController(ForgotPasswordServices,ValidationService, $state, Constants) {

        var vm = this;   
        vm.email = "";       
        vm.forgotPassword = forgotPassword;      
        
        function forgotPassword(forgotPasswordForm){
        	if (ValidationService.isValid(forgotPasswordForm) == 0){    		  	
        		ForgotPasswordServices.forgotPassword(vm.email)
                .then(function (result) {
                	$state.go('Login');  	
                	ValidationService.showAlert(result.data.header, result.data.success, Constants.messageTypes.successGritter); 	
                 })
                .catch(function (error){
                	ValidationService.showAlert(error.data.header, error.data.error, Constants.messageTypes.errorGritter); 	
               });        		
    		}
        }
    }
    
})();


