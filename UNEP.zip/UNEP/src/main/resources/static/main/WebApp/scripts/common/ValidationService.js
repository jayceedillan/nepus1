(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('ValidationService', ValidationService);

    ValidationService.$inject = [];

    function ValidationService() {

        var factory = {
              isValid:isValid,
              removeValidate:removeValidate,
              showError:showError,
              showAlert:showAlert,
              isValidByClass:isValidByClass
        };

        return factory;

        function isValid(myForm){       	
        	
        	var iError=  0;

        	angular.forEach(myForm.$error.required, function(field) {
      	      field.$setDirty();
      	      iError++;
      	    });  
        	
        	angular.forEach(myForm.$error.email, function(field) {
	      	      field.$setDirty();    	      
	      	    iError++;
	      	 });  
        	
        	angular.forEach(myForm.$error.matchPassword, function(field) {
	      	      field.$setDirty();    	      
	      	    iError++;
	      	 }); 
        	
        	return iError;
        	
        }
        
        function isValidByClass(className){
        	var iError=0;

        	$("." + className).each(function (index, ele) {
        		//alert($(this).attr('placeholder'));
        		console.log();
        		$(this).next().remove();
        		if ($(this).val() == "" || $(this).val() == "0") {	
        			$(this).addClass("error");
        		    $(this).after('<div class="error-msg" > Please provide a ' + $(this).attr('placeholder') + '.</div>')
        		}
        		else{
        			$(this).removeClass("error");
        			$(this).next().remove();
        		}
        	});		 

        	return iError;
        }
        
        function removeValidate(myForm){
        	angular.forEach(myForm.$error.required, function(field) {
        		 field.$dirty = false;
      	    });          	
        }
        
        function showError(myForm){
        	
        	angular.forEach(myForm.$error.required, function(field) {
        	      field.$setDirty();        	      
        	    });  
        	
	        angular.forEach(myForm.$error.email, function(field) {
	      	      field.$setDirty();    	      
	      	      
	      	 });  
	      	
	      	angular.forEach(myForm.$error.matchPassword, function(field) {
	      	      field.$setDirty();
	      	      
	      	});  
	      	
	      	angular.forEach(myForm.$error.minlength, function(field) {
	    	      field.$setDirty();
	    	      
	    	    });
	      	
	      	angular.forEach(myForm.$error.url, function(field) {
	      	      field.$setDirty();
	      	      
	      	 });
	      	
        }
        
        function showAlert(title,text, className  ){
         	$.gritter.add({
				title: title,
				text: text,
				class_name: className + ' gritter-center' + (false ? ' gritter-light' : '')
			});
	
			return false;
        }
        
    }

})();
