(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('ForgotPasswordServices', ForgotPasswordServices);

    ForgotPasswordServices.$inject = ['$http'];

    function ForgotPasswordServices($http) {
        var factory = {
        		forgotPassword: forgotPassword
        };

        return factory;
        
        function forgotPassword(email) {
            return $http({
                method: 'GET',
                url: 'UNEP/Password/forgot',
                params: {emailAddress : email}
            })
        }
        
    }
})();