app.directive("accreditationProcessing", function() {
  return {
    restrict: "A",   
    templateUrl: "/main/WebApp/app/organization/processing/accreditation/AccreditationProcess.html",
    controller: 'AccreditationProcessController',
    controllerAs: 'vmAccredProcessing',
    replace:true,
    bindToController: true
  };
});