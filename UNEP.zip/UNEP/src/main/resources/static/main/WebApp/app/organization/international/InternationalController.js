(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('InternationalController', InternationalController);

    InternationalController.$inject = ['$rootScope','OrganizationInfoService','ValidationService','Constants',
                                       'MultiSelectService','UnepOrganization'];   
    
    function InternationalController($rootScope,OrganizationInfoService,ValidationService,Constants,
    		                          MultiSelectService,UnepOrganization) {
    	
        var vm = this;   
        
        vm.InternalScope=$rootScope.internationalScopeInfo;        
        vm.geographicalList= vm.InternalScope.geographicalScope;
        vm.areasOfExpertise=vm.InternalScope.areasOfExpertise;
        vm.crossCutttingAreas=vm.InternalScope.crossCuttingAreas;
        vm.saveInternational=saveInternational;
        vm.clickOthers=clickOthers;
        vm.getLimits=getLimits;
        vm.readOnly = UnepOrganization.readOnly();
        
        function saveInternational(myForm, saveNext){
        	
            vm.NeedValidate=true;;
        	
        	if (saveNext){
        		if (ValidationService.isValid(myForm) !=0){        		
        		 return;			
        		}
        	}	
        	
        	vm.InternalScope.geographicalScope=vm.geographicalList;
        	vm.InternalScope.areasOfExpertise=vm.areasOfExpertise;
        	vm.InternalScope.crossCuttingAreas=vm.crossCutttingAreas;
        	
        	OrganizationInfoService.saveInternational(vm.InternalScope)
            .then(function (result) {
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
            	if (saveNext){
            	 getInternationalInfo();	 
           		 $rootScope.wizardsId =2;}
             })
            .catch(function(error){
            	ValidationService.showError(myForm); 
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
           });
        	
        }
        
        function getInternationalInfo(){
        	
        	OrganizationInfoService.getInternationalInfo()
            .then(function (result) {
            	$rootScope.internationalScopeInfo = result.data.orgProfile
            	
             })
            .catch(function(error){
            	ValidationService.showError(myForm); 
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
           });
        }
        
        function getLimits (array){
    	   return [
                 Math.floor(array.length / 2) ,
                 -Math.floor(array.length / 2)
             ];
        }

        function clickOthers(items){       	        	
        	MultiSelectService.clickOthers(items);
        }
    }
    
})();


