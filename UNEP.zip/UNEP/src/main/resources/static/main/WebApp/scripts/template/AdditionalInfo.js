app.directive("additionalInfo", function() {
  return {
    restrict: "A",   
    templateUrl: "main/WebApp/app/organization/additional/AdditionalInfo.html",
    controller: 'AdditionalInfoController',
    controllerAs: 'vmAdditionalInfo',
    replace:true,
    bindToController: true, 
  };
});