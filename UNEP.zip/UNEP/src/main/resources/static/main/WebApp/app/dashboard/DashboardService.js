(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('DashboardService', DashboardService);

    DashboardService.$inject = ['$http'];

    function DashboardService($http) {
        var factory = {
        		getDashboarInfo:getDashboarInfo
        };

        return factory;
        
        function getDashboarInfo() {
            return $http({
                method: 'GET',
                url: 'UNEP/Dashboard',                
            })
        }
        
    }
})();