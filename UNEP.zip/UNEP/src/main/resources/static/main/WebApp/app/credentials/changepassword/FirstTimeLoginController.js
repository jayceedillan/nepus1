(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('FirstTimeLoginController', FirstTimeLoginController);

    FirstTimeLoginController.$inject = ['ChangePasswordServices','ValidationService', '$state', 'Constants'];   
    
    function FirstTimeLoginController(ChangePasswordServices,ValidationService, $state,  Constants) {

        var vm = this;
        vm.oldPassword = "";
        vm.password = "";
        vm.confirmPassword = "";       
        
        vm.changePassword = changePassword;            
        
        function changePassword(changePasswordForm){
        	if (ValidationService.isValid(changePasswordForm) == 0){    		  	
        		ChangePasswordServices.changePassword(vm.oldPassword, vm.password, vm.confirmPassword)
                .then(function (result) {	
                	ValidationService.showAlert(result.data.header, result.data.success, Constants.messageTypes.successGritter);                	
                 })
                .catch(function (error){
                	ValidationService.showAlert(error.data.header, error.data.error, Constants.messageTypes.errorGritter); 
               });        		
    		}
        }
    }
    
})();


