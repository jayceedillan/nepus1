(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('AccreditationProcessService', AccreditationProcessService);

    AccreditationProcessService.$inject = ['$http'];
   
    function AccreditationProcessService($http) {
        var factory = {        		
        		getDocumentList:getDocumentList,
        		saveAccreditation:saveAccreditation,
        		download:download
        };

        return factory;
        
        function getDocumentList(id){
        	return $http({
                method: 'GET',
                url: 'UNEP/AccreditationProcess/' + id                
            })
        }
        
        function saveAccreditation(data,id){
        	return $http({
                method: 'POST',
                url: 'UNEP/AccreditationProcess/' + id,
                data: data
            })
        }
        
        function download(id,items){
//        	return $http({
//                method: 'POST',
//                url: 'UNEP/AccreditationProcess/' + id',
//                data: items,
//                responseType: 'arraybuffer'
//            })
        	
        	return $http({
                method: 'POST',
                url: 'UNEP/AccreditationProcess/download/' + id,
                data: items,
                responseType: 'arraybuffer'
            })
        }
    }
})();