(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('ModalService', ModalService);

    ModalService.$inject = ['$uibModal','$q'];

    function ModalService($uibModal,$q) {
        var factory = {
        		removeItems:removeItems,
        		
        };

        return factory;
        
        function removeItems(header, message) {
        	var q = $q.defer();        	 
        	$uibModal.open({
 			     templateUrl: 'main/Webapp/app/modal/Modal.html',
 				 backdrop: 'static',
 				 controller: 'ModalController',
 				 controllerAs: 'vmModal',
 				 resolve: {
 					 customMessage: function () {	                     
 	                       return {'data':header,message };
 	                   }
 	               }    
 			  }).result.catch(function (res) {
 				 q.resolve(res );
 			  })
        	
        	 return q.promise;
        }       
    }
})();

