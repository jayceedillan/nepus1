(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('OrganizationProfileServices', OrganizationProfileServices);

    OrganizationProfileServices.$inject = ['$http'];

    function OrganizationProfileServices($http) {
        var factory = {
        		SaveProfile:SaveProfile
        };

        return factory;
        
        function SaveProfile(Profile) {
            return $http({
                method: 'POST',
                url: 'UNEP/OrganizationProfile',
                data: Profile
            })
        }
        
    }
})();