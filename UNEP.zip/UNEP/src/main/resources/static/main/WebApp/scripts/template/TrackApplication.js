app.directive("trackingApplication", function() {
  return {
    restrict: "A",   
    templateUrl: "main/WebApp/app/organization/tracking/TrackingApplication.html",
    controller: 'TrackingApplicationController',
    controllerAs: 'vmTrackingApp',
    replace:true,
    bindToController: true, //required in 1.3+ with controllerAs
  };
});