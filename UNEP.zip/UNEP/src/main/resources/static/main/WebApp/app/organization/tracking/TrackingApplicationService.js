(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('TrackingApplicationService', TrackingApplicationService);

    TrackingApplicationService.$inject = ['$http'];
   
    function TrackingApplicationService($http) {
        var factory = {        		
        		sendFollowUp:sendFollowUp,
        };

        return factory;
        
        function sendFollowUp(content){    
             return $http({
                method: 'POST',
                url: 'UNEP/TrackingApplication/sendFollowUp',
                params: {
                	content:content
                }
            })            
        }

    }
})();