(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('UserService', UserService);

    UserService.$inject = ['$http'];
   
    function UserService($http) {
        var factory = {        
        	 getUsers:getUsers,
        	 getUserById:getUserById,
        	 saveUser:saveUser,
        	 updateUser:updateUser
        };

        return factory;
        
        function getUsers(paginationObject){        	
        	return $http({
                method: 'GET',
                url: 'UNEP/Users',
                params: paginationObject
            })
            
        }
        
        function getUserById(id){        	
        	return $http({
                method: 'GET',
                url: 'UNEP/Users/' + id                
            })
        }
        
        function saveUser(users){
        	return $http({
                method: 'POST',
                url: 'UNEP/Users',
                data: users
            })
        }
        
        function updateUser(id){
        	return $http({
                method: 'POST',
                url: 'UNEP/Users/update/' + id                
            })
        }
        
    }
})();