(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('QuadrennialsReportsController', QuadrennialsReportsController);

    QuadrennialsReportsController.$inject = ['$rootScope','$scope','$state','ValidationService','OrganizationInfoService','Constants',
                                             'UnepOrganization','$q','$uibModal','$uibModalStack'];   
    
    function QuadrennialsReportsController($rootScope,$scope,$state,ValidationService,OrganizationInfoService,Constants,
    		                                UnepOrganization,$q,$uibModal,$uibModalStack) {

        var vm = this;
        
        $rootScope.wizardsId=0;
        vm.wizards=wizards;
        vm.currentState =UnepOrganization.getCurrentState();        
        vm.showTracksApp=showTracksApp;
        vm.triggerRedButton=triggerRedButton;        
        vm.getInfo=getInfo;             
       
        function wizards(selectedId){
        	
        	if (validateWizards(selectedId)){
        		ValidationService.showAlert('Warning',Constants.messageTypes.wizardsWarning, Constants.messageTypes.errorWarning);
        		return;
        	}else{
        		$rootScope.wizardsId= selectedId;            	
        	}
        }
        
        function showTracksApp(stageNo){
        	if ($rootScope.trackingAppInfo.id  ===0){
        		ValidationService.showAlert('Warning',Constants.messageTypes.wizardsWarning, Constants.messageTypes.errorWarning);
        		return;
        	}
        	
        	 $rootScope.wizardsId=4;
        }
        
        function triggerRedButton(id){
        	$rootScope.wizardsId=id;
        }
  
        function validateWizards(index){
        	
        	switch (index)
        	{
        	 case 1:
        	  return   $rootScope.internationalScopeInfo.id === 0 && $rootScope.Organization.organizationInfo.id === 0 ? true : false;
        	 case 2:
           	  return   $rootScope.additionalInfo.id === 0 && $rootScope.internationalScopeInfo.id === 0 ? true : false;
        	 case 3:
        	  return   $rootScope.additionalInfo.id === 0 && $rootScope.trackingAppInfo.id === 0 ? true : false;
        	}
        } 
        
        function getInfo(){
        	$state.go('PrintPDF',{id:$rootScope.orgProfile.id});     	
        } 
    }
    
})();


