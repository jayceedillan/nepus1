(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('ChangePasswordServices', ChangePasswordServices);

    ChangePasswordServices.$inject = ['$http'];

    function ChangePasswordServices($http) {
        var factory = {
        		changePassword: changePassword
        };

        return factory;
        
        function changePassword(oldPassword, newPassword, confirmPassword,isChangePassword) {
            return $http({
                method: 'GET',
                url: 'UNEP/Password/change',
                params: {oldPassword: oldPassword,
           		 		 newPassword: newPassword,
                		 confirmPassword: confirmPassword,
                		 isChangePassword: isChangePassword}
            })
        }
        
    }
})();