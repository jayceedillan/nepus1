(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('VerifyRegistrationController', VerifyRegistrationController);

    VerifyRegistrationController.$inject = ['$state','VerifyRegistrationServices', 'ValidationService', '$stateParams','Constants'];   
    
    function VerifyRegistrationController($state,VerifyRegistrationServices, ValidationService, $stateParams,Constants) {

        var vm = this;   
                        
        if($stateParams.code != ''){
        	VerifyRegistrationServices.verify($stateParams.code)
            .then(function (result) {  
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
             })
            .catch(function (error){            	            	
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
            	$state.go('VerifyRegistrationFailed');
           });        
        }
    }
})();


