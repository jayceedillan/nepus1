(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('ChangePasswordController', ChangePasswordController);

    ChangePasswordController.$inject = ['ChangePasswordServices','ValidationService', '$state', '$uibModalInstance', 'Constants'];   
    
    function ChangePasswordController(ChangePasswordServices,ValidationService, $state, $uibModalInstance, Constants) {

        var vm = this;
        vm.oldPassword = "";
        vm.password = "";
        vm.confirmPassword = "";       
        
        vm.changePassword = changePassword;
        vm.closeModal = closeModal;      
        
        function changePassword(changePasswordForm){
        	if (ValidationService.isValid(changePasswordForm) == 0){    		  	
        		ChangePasswordServices.changePassword(vm.oldPassword, vm.password, vm.confirmPassword, false)
                .then(function (result) {	
                	ValidationService.showAlert(result.data.header, result.data.success, Constants.messageTypes.successGritter);
                	closeModal();
                 })
                .catch(function (error){
                	ValidationService.showAlert(error.data.header, error.data.error, Constants.messageTypes.errorGritter); 
               });        		
    		}
        }
        
        function closeModal() {
        	$uibModalInstance.close(false);
        }
    }
    
})();


