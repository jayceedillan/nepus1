(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('RegexPattern', RegexPattern);

    RegexPattern.$inject = [];

    function RegexPattern() {

        var factory = {
              EmailPattern:EmailPattern,
              URLPattern:URLPattern,
             
        };

        return factory;

        function EmailPattern(){
        	return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;        	
        }        
       
        function URLPattern(){
        	return /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;;
        }
        
    }

})();
