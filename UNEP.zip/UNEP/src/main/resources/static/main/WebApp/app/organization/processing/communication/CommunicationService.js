(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('CommunicationService', CommunicationService);

    CommunicationService.$inject = ['$http'];
   
    function CommunicationService($http) {
        var factory = {        		
                getEmailDocs:getEmailDocs,
        		saveCommunication:saveCommunication,
        		returnOfficer:returnOfficer,
        		approved:approved
        };

        return factory;

        
        function saveCommunication(files,content,subject,id,isReturn){
        	return $http({
                method: 'POST',
                url: 'UNEP/Communication',                
                headers: {'Content-Type': undefined},
                transformRequest: function () {                	
               	 	var formData=new FormData();
               	 	
                	formData.append("file",files[0]);               	
	               	formData.append("subject",subject);
	              	formData.append("content",content);
	              	formData.append("id",id);
	              	formData.append("isReturn",isReturn);
	              	
                  return formData;
                }               
            })            
        }
        
        function returnOfficer(id,subject,content){
        	return $http({
                method: 'POST',
                url: 'UNEP/Communication/returnOfficer/' + id,
                params: {subject:subject,
                	content : content}                
               
            })	
        }
        
        function approved(id,isApproved, remarks){
        	 return $http({
                 method: 'POST',
                 url: 'UNEP/Communication/Approved/' + id,
                 params: {isApproved:isApproved,remarks : remarks}
                
             })
        }
        
        function getEmailDocs(id){        	
          id = angular.isUndefined(id) == true  ? 0 : id;
          
       	 return $http({
                method: 'GET',
                url: 'UNEP/Communication/getEmailDocs/' + id               
               
            })
       }
        
    }
})();