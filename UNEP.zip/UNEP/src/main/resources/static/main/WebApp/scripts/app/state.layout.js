

app.config(function($stateProvider) {	
    $stateProvider    
    .state('root', {
            abstract: true,
            views: {
                '@': {
                    templateUrl: 'main/WebApp/app/profile/MainProfile.html'
                },'footer@root':{
                	templateUrl: 'main/WebApp/app/layout/Footer.html'                    	
                }
            }        
           
      }).state('app', {
          abstract: true,
          views: {
              '@': {
                  templateUrl: 'main/WebApp/app/organization/MainOrganization.html',
                 
              },
              'mainHeader@app': {
                  templateUrl: 'main/WebApp/app/organization/MainHeader.html',
                  controller:'MainOrganizationController',
                  controllerAs: 'vmMainOrganization' 
              },
              'quadrennials@app': {
                  templateUrl: 'main/WebApp/app/organization/quadrennial/QuadrennialsReports.html',
                  controller:'QuadrennialsReportsController',
                  controllerAs: 'vmQuadrennialsReports' 
              },
              'footer@app': {
            	  templateUrl: 'main/WebApp/app/layout/Footer.html'
               
              }
          } 
    }).state('mainapp', {
        abstract: true,
        views: {
            '@': {
                templateUrl: '/main/WebApp/app/layout/Main.html',
               
            } ,
            'mainHeader@mainapp': {
            	templateUrl: 'main/WebApp/app/organization/MainHeader.html',
            	controller:'MainOrganizationController',
                controllerAs: 'vmMainOrganization' 
             
            },'footer@mainapp': {
          	  templateUrl: 'main/WebApp/app/layout/Footer.html'
                  
            }
        } 
  });       
		      
});





