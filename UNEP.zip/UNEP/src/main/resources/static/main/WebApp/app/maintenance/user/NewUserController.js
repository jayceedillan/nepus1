(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('NewUserController', NewUserController);

    NewUserController.$inject = ['RoleList','users','UserService','ValidationService','Constants','$uibModalInstance'];   
    
    function NewUserController(RoleList,users,UserService,ValidationService,Constants,$uibModalInstance) {
       
    	var vm = this;       	
    	
    	vm.saveUser=saveUser;
    	vm.roleList = RoleList.data;
    	vm.user = users.data;
    	vm.closed=closed;
    	
    	function saveUser(myForm){
    		if (ValidationService.isValid(myForm) ==0){    			
    			UserService.saveUser(vm.user)
                .then(function (result) {
                	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
                	$uibModalInstance.dismiss('closed');
                 })
                .catch(function (error){
                	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
               });
    		}
    	}
    	
    	function closed(){
    		$uibModalInstance.dismiss('cancel');
    	}
    }
    
})();


