(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('MultiSelectService', MultiSelectService);

    MultiSelectService.$inject = [];

    function MultiSelectService() {

        var factory = {
              twoSelected:twoSelected,  
              clickOthers :clickOthers,
              addOptions:addOptions
        };

        return factory;

        function twoSelected(sVal){
        	
        	return sVal == 0 ? {"id":"0","name":"Yes"} : {"id":"1","name":"No"};  

        }
        
        function clickOthers(items){
	        if (items.name.toUpperCase() === 'OTHER' && items.isSelected === true){
	    		items.isSelectedOthers = true;
	    	}
	    	else{
	    		items.others='';
	    		items.isSelectedOthers = false;
	    	}
        }
        
        function addOptions(){
        	var options = [{
                id: "0",
                name: "Yes"
              }, {
                id: "1",
                name: "No"
              }];       	
        	
        	return options;
        }
    }

})();
