(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('LoginServices', LoginServices);

    LoginServices.$inject = ['$http'];

    function LoginServices($http) {
        var factory = {
        		authenticate: authenticate,
        		logout:logout
        };

        return factory;
        
        function authenticate(object) {
            return $http({
                method: 'POST',
                url: 'UNEP/Login',
                params: {emailAddress : object.email,
                		 password: object.password}
            })
        }
        
        function logout() {  		
        	return $http({
                method: 'POST',
                url: 'UNEP/Login/Logout'
            })

    	  }
        
        
    }
})();