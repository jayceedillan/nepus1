
var app = angular.module('UNEP.AccreditationSystem', ['ui.router','ui.bootstrap','colorpicker.module',
                                                      'vcRecaptcha', 'ngResource']).run(run);

run.$inject = ['stateHandler'];
function run(stateHandler) {
    stateHandler.initialize();
}
