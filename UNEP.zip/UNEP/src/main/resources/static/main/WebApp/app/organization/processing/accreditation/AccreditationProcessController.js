(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('AccreditationProcessController', AccreditationProcessController);

    AccreditationProcessController.$inject = ['$stateParams','AccreditationProcessService','ValidationService','Constants','UnepOrganization'];   
    
    function AccreditationProcessController($stateParams,AccreditationProcessService,ValidationService,Constants,UnepOrganization) {
        
        var vm = this;
        vm.send=send;
        vm.setCheck=setCheck;
        vm.show =UnepOrganization.showElement();
        vm.userRoles = UnepOrganization.getRoles();
        vm.download=download;
        
        onInit();
        
        function onInit(){
        	if ($stateParams.id != undefined){
	        	AccreditationProcessService.getDocumentList($stateParams.id)
	            .then(function (result) {           	
	                 vm.docList=result.data.docList.documentAttach;
	                 vm.recommendation=result.data.recommendationContent;
	                 vm.chief= result.data.chief;	                
	                 vm.secretary= result.data.secretary;
	                 vm.subjectChief= result.data.subjectChief;
	                 vm.subjectsecretary= result.data.subjectsecretary;
	             });        	
        	}
        }
        
      
        
        function setCheck(item, index){        	
        	if (index ===1){
        		item.decision = true;
        	}else{
        		item.decision = false;
        	}
        }
        
        function send(){
        	
        	var contentMessage = CKEDITOR.instances.editor1.getData();
        	  
        	vm.document={};
        	vm.document.documentAttach=vm.docList;
        	vm.document.content =contentMessage;
        	AccreditationProcessService.saveAccreditation(vm.document,$stateParams.id)
            .then(function (result) {
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
             })
            .catch(function(error){
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter); 
           });  
        }
        
        function download(items){
        	
        	items.hasDownloaded=true;
        	AccreditationProcessService.download($stateParams.id,items)
            .then(function (result) {
            	
            	 var type = result.headers('Content-Type');
                 var disposition = result.headers('Content-Disposition');
                 var defaultFileName = "";

                 if (disposition) {
                     var match = disposition.match(/.*filename="?([^;"]+)"?.*/);
                     if (match[1])
                         defaultFileName = match[1];
                 }

                 defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');

                 var blob = new Blob([result.data], {
                     type: type
                 });

                 saveAs(blob, defaultFileName);
                 items.hasDownloaded=false;
            	ValidationService.showAlert('SUCCESS','You have successfully downloaded file.', Constants.messageTypes.successGritter);
             })
            .catch(function(error){
            	items.hasDownloaded=false;
            	ValidationService.showAlert('FAILED','File not found/Corrupted file.', Constants.messageTypes.errorGritter); 
           }); 
        	
        }
    }
    
})();


