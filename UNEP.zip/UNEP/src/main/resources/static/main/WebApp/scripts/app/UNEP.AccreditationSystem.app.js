app.config(function($stateProvider, $urlRouterProvider,$urlMatcherFactoryProvider,$locationProvider) {
	
	
	$locationProvider.html5Mode(true);
    $urlRouterProvider.otherwise("Login");
    $locationProvider.hashPrefix('');	
    $stateProvider    
    .state('/',{
    	 templateUrl:'/main/WebApp/app/credentials/login/Login.html',
         parent: 'root',
         url:'/Login',
         controller:'LoginController',
         controllerAs: 'vmLogin' 
        }).state('Register',{
          templateUrl:'/main/WebApp/app/profile/OrganizationProfile.html',
          parent: 'root',
          url:'/Register',
          controller:'OrganizationProfileController',
          controllerAs: 'vmOrganizationProfile'     
      }).state('VerifyRegistration',{
          templateUrl:'/main/WebApp/app/registrationverification/VerifyRegistration.html',       
          url:'/VerifyRegistration/:code',
          controller:'VerifyRegistrationController',
          controllerAs: 'vmVerifyRegistration'     
      }).state('VerifyRegistrationFailed',{
          templateUrl:'/main/WebApp/app/registrationverification/VerifyRegistrationError.html',       
          url:'/VerifyRegistration/Failed'    
      }).state('Login',{
    	 templateUrl:'/main/WebApp/app/credentials/login/Login.html',
         parent: 'root',
         url:'/Login',
         controller:'LoginController',
         controllerAs: 'vmLogin' 
      }).state('ForgotPassword',{
          templateUrl:'/main/WebApp/app/credentials/forgotpassword/forgotPassword.html',
          parent: 'root',
          url:'/ForgotPassword',
          controller:'ForgotPasswordController',
          controllerAs: 'vmForgotPassword'   
      }).state('Dashboard',{
          templateUrl:'/main/WebApp/app/dashboard/Dashboard.html',
          parent: 'mainapp',
          url:'/Dashboard',
          controller:'DashboardController',
          controllerAs: 'vmDashboard'     
      })
      .state('Organization', {
     	 parent: 'app',
         url: '/Organization',
         templateUrl:'/main/WebApp/app/organization/OrganizationInfo.html',
         controller:'OrganizationInfoController',
         controllerAs: 'vmOrgInfo',
        	 resolve: {
                 DropdownList: ['DropdownService',
                     function (DropdownService) {                 	      
                         return DropdownService.getDropdownOrg();
                     }],
                 Organization: ['OrganizationInfoService',
                     function (OrganizationInfoService) {                	 
                          return OrganizationInfoService.getOrganizationInfo();
                     }]
             } 
    }).state('AccreditationProcessing', {
     	 parent: 'app',
         url: '/AccreditationProcessing',
         templateUrl:'/main/WebApp/app/organization/processing/accreditation/AccreditationProcessing.html',
         controller:'AccreditationProcessingController',
         controllerAs: 'vmAccredProcessing',
    }).state('Users', {
     	 parent: 'mainapp',
         url: '/Maintenance/Users',
         templateUrl:'/main/WebApp/app/maintenance/user/Users.html',
         controller:'UsersController',
         controllerAs: 'vmUsers',
         resolve: {
             UserList: ['UserService','Pagination',
                 function (UserService,Pagination) {
            	     var pagination = Pagination.validateUndefined(pagination);     
            	     pagination.limit = ((1 -1 ) * pagination.offset);   
                     return UserService.getUsers(pagination);
                 }]
         }
    }).state('Settings', {
     	 parent: 'mainapp',
         url: '/Maintenance/Settings',
         templateUrl:'/main/WebApp/app/maintenance/settings/Settings.html',
         controller:'SettingsController',
         controllerAs: 'vmSettings',
         resolve: {             
             settingData: ['SettingsService','Pagination',
                        function (SettingsService,Pagination) {  
        	                 var pagination = Pagination.initPage(pagination,0,'10');
                            return SettingsService.getSettings(pagination,0);
                       }]
         } 
    }).state('AccreditationList', {
     	 parent: 'mainapp',
         url: '/Accreditation/List',
         templateUrl:'/main/WebApp/app/accreditation/AccreditationList.html',
         controller:'AccreditationListController',
         controllerAs: 'vmAccreditationList',
         resolve: {             
             Accreditation: ['OrganizationInfoService','Pagination',
                        function (OrganizationInfoService,Pagination) {  
        	                 var pagination = Pagination.initPage(pagination,0,'10');
                            return OrganizationInfoService.getAccreditationList(pagination);
                       }]
         } 
    }).state('AccreditationByOrg', {
     	 parent: 'app',
         url: '/Accreditation/List/:id',
         templateUrl:'/main/WebApp/app/organization/OrganizationInfo.html',
         controller:'OrganizationInfoController',
         controllerAs: 'vmOrgInfo',
        	 resolve: {
                 DropdownList: ['DropdownService',
                     function (DropdownService) {                 	      
                         return DropdownService.getDropdownOrg();
                     }],
                 Organization: ['OrganizationInfoService','$stateParams',
                     function (OrganizationInfoService,$stateParams) {                	 
                          return OrganizationInfoService.getOrganizationInfoById($stateParams.id);
                     }]
           }  
    }).state('PrintPDF', {
     	// parent: 'app',
         url: '/PrintPDF/:id',
         templateUrl: '/main/WebApp/app/organization/pdfform/PrintPDF.html',	     
	     controller: 'PdfController',
	     controllerAs: 'vmPdf',
	     resolve: {            
             Organization: ['OrganizationInfoService','$stateParams',
                 function (OrganizationInfoService,$stateParams) {
                      return OrganizationInfoService.getOrganizationInfoById($stateParams.id);
                 }]
       }  
    });	      
});