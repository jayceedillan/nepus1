(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('NewSettingsController', NewSettingsController);

    NewSettingsController.$inject = ['mainType','Settings','SettingsService','DropdownService','ValidationService','Constants','$uibModalInstance'];   
    
    function NewSettingsController(mainType,Settings,SettingsService,DropdownService,ValidationService,Constants,$uibModalInstance) {

        var vm = this;  
        
        vm.settingType=mainType.data;
        vm.save=save;
        vm.cancel=cancel;

       onInit();
       
       
       function save(){
    	  var id= angular.isUndefined(mainType.item) == true ? 0 : mainType.item.id;
    	   SettingsService.saveSettings(id,vm.name,vm.settingType)
	           .then(function (result) {
	           	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
	           	$uibModalInstance.dismiss('closed');
	            })
	           .catch(function(error){
	           	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
          });    
    	   
       }
       
       function onInit(){
           
    	   switch(mainType.data){
    	   case 0:
    		   vm.header = Settings.Types.majorGroup;
    		   break;
    	   case 1:
    		   vm.header = Settings.Types.hQ;
    		   break;
    	   case 2:
    		   vm.header = Settings.Types.geoScope;
    		   break;
    	   case 3:
    		   vm.header = Settings.Types.areasOfExpertise;
    		   break;
    	   case 4:
    		   vm.header = Settings.Types.crossCuttingAreas; 
    		   break;
    	   case 5:
    		   vm.header = Settings.Types.countryOfReg;
    		   break;
    	   case 6:
    		   vm.header = Settings.Types.companyCategory;
    		   break;
    	   case 7:
    		   vm.header = Settings.Types.emailAddress;
    		   vm.showEmail=true;
    		   break;
    	   }
    	   
    	   
    	   vm.name = angular.isUndefined(mainType.item) == true ? '' : mainType.item.name;
    	  // bindRoles();
       }
       
//       function bindRoles(){
//    	   DropdownService.getRole();
//    	   
//    	   DropdownService.getRole()
//           .then(function (result) {
//        	   vm.userRoles =result.data;
//            });
//       }
       
       function cancel(){
    	   $uibModalInstance.dismiss('cancel');
       }
    }
    
})();


