(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .directive('allowOnlyNumbers', allowOnlyNumbers);

    allowOnlyNumbers.$inject = [];

    function allowOnlyNumbers() {
        var directive = {
            restrict: 'A',            
            link: linkFunc
        };

        return directive;

        function linkFunc(scope, elm, attrs, ctrl) {
        	elm.on('keydown', function (event) {
        		//alert(event.keyCode);
        		if (  event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
        	            (event.keyCode == 65 && event.ctrlKey === true) ||
        	            (event.keyCode >= 35 && event.keyCode <= 39)) {
        	            return;
        	        }
        	        else {
        	            // Ensure that it is a number and stop the keypress
        	            if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
        	                event.preventDefault();
        	            }
        	        }        		

            });  
        }

    }

})();