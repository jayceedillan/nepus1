app.directive("communicationOrg", function() {
  return {
    restrict: "A",   
    templateUrl: "/main/WebApp/app/organization/processing/communication/Communication.html",
    controller: 'CommunicationController',
    controllerAs: 'vmCommunication',
    replace:true,
    bindToController: true, //required in 1.3+ with controllerAs
  };
});