$(document).ready(function() {
	// User icon
	$('#user').click(function(){
		alert('xxx');
		$('#logout').toggleClass('active');
	})
	
	alert('xxx');
});