(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('AccreditationListController', AccreditationListController);

    AccreditationListController.$inject = ['Accreditation','OrganizationInfoService','Pagination','UnepOrganization'];   
    
    function AccreditationListController(Accreditation,OrganizationInfoService,Pagination,UnepOrganization) {

        var vm = this;   
        vm.accreditationList=Accreditation.data.accreditationList;
        vm.totalRows = Accreditation.data.totalRows;
        vm.pagination = Pagination.initPage(vm.pagination,vm.totalRows,'5');   
        vm.filterByStatus = filterByStatus
        vm.pageChanged=pageChanged;
        vm.setPager=setPager;
        UnepOrganization.pageTitle();
        
        function filterByStatus(){        	 
        	
        	OrganizationInfoService.getAccreditationList(vm.pagination)
            .then(function (result) {
            	vm.accreditationList=result.data.accreditationList;
            	vm.pagination.totalRows = result.data.totalRows;
            	vm.pagination = Pagination.initPage(vm.pagination);
             }) .catch(function (error){
             	
            });  
        }
        
        function pageChanged(){
        	  vm.pagination = Pagination.initPage(vm.pagination);  
        	  filterByStatus();
        	  
        }
        
        function setPager(e){
        	
       	 var code = e.keyCode || e.which;
           	
          	 if(code == 13) {       
          		 if( vm.pagination.currentPage >  vm.pagination.totalPages){
          			 vm.pagination.currentPage=vm.pagination.totalPages;
          			 return;
          		 }
          		 pageChanged();
          	 }
         }
         
    }
    
})();


