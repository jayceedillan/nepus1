app.constant(
	'Constants',
	{
		messageTypes : {						
			LoginRequired:'Employee No. or Password is required.',	
			newRecords:'entry successfully saved.',
			updatedRecords:'entry successfully updated.',
			successGritter:'gritter-success',
			errorGritter:'gritter-error',
			errorWarning:'gritter-warning',
			wizardsWarning:'You don\'\t allowed to proceed',
		}
	});
