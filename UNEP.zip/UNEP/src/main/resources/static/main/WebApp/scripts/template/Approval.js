app.directive("approval", function() {
  return {
    restrict: "A",   
    templateUrl: "/main/WebApp/app/organization/processing/approval/Approval.html",
    controller: 'ApprovalController',
    controllerAs: 'vmApproval',    
    replace:true,
    bindToController: true,
  };
});