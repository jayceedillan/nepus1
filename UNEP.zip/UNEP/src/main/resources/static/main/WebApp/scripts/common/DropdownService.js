(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('DropdownService', DropdownService);

    DropdownService.$inject = ['$http'];

    function DropdownService($http) {
        var factory = {
        		getDropdownOrg:getDropdownOrg,
        		getCheckboxInter:getCheckboxInter,
        		getRole:getRole
        };

        return factory;
        
        function getDropdownOrg() {
        	return $http({
                method: 'GET',
                url: 'UNEP/Dropdown/GetDropdownOrg'
            })
        }
        
        function getCheckboxInter(){
        	return $http({
                method: 'GET',
                url: 'UNEP/Dropdown/GetCheckboxInter'
            })
        }
        
        function getRole(){
        	return $http({
                method: 'GET',
                url: 'UNEP/Dropdown/Role'
            })
        }
    }
})();