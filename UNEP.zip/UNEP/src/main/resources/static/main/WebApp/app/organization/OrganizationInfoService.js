(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('OrganizationInfoService', OrganizationInfoService);

    OrganizationInfoService.$inject = ['$http'];
   
    function OrganizationInfoService($http) {
        var factory = {        		
        		getOrganizationInfo:getOrganizationInfo,
        		getInternationalInfo:getInternationalInfo,
        		saveOrganizationInfo:saveOrganizationInfo,
        		saveInternational:saveInternational,
        		saveAdditionalInfo:saveAdditionalInfo,
        		getProfilePics:getProfilePics,
        		validateActiveUser:validateActiveUser,
        		saveDocumentUpload:saveDocumentUpload,
        		getTrackingApplication:getTrackingApplication,
        		getAdditionalInfo:getAdditionalInfo,
        		getAccreditationList:getAccreditationList,
        		getOrganizationInfoById:getOrganizationInfoById,
        		getPrintPDFById:getPrintPDFById,
        		exportPDF:exportPDF,
        		download:download,
        		getNewTrackApplication:getNewTrackApplication,
        		
        };

        return factory;
        
        function getOrganizationInfo(){    
        	
             return $http({
                method: 'GET',
                url: 'UNEP/OrganizationInfo/getOrganizationInfo'                
            })            
        }
        
        function getOrganizationInfoById(id){
        	return $http({
                method: 'GET',
                url: 'UNEP/OrganizationInfo/getOrganizationInfo/' + id                
            })
        }
        
        function getProfilePics(id){        	
        	return $http({
        		method: 'GET',
        		url: 'UNEP/OrganizationInfo/getLogo/' + id
        	})
        }        
                
        function getInternationalInfo(){        	
            return $http({
               method: 'GET',
               url: 'UNEP/OrganizationInfo/getInternationalScopeInfo'                
           })            
        }        
        
        function saveOrganizationInfo(organizationInfo){
        	return $http({
                method: 'POST',
                url: 'UNEP/OrganizationInfo/saveOrganizationInfo',
                data: organizationInfo
            })
        }
        
        function saveInternational(internalScope) {
            return $http({
                method: 'POST',
                url: 'UNEP/OrganizationInfo/internalScope',
                data: internalScope
            })
        }
        
        function saveAdditionalInfo(files,additionalInfo){            
        	return $http({
                method: 'POST',
                url: 'UNEP/OrganizationInfo/saveAdditional',                
                headers: {'Content-Type': undefined},
                transformRequest: function () {
                	
               	 	var formData=new FormData();              	 
	               
	               	for (var i = 0, len = files.length; i < len; i++) {
	               	 formData.append("file",files[i]);	               
	                }
	            	formData.append("additionalInfo",JSON.stringify(additionalInfo));
                  return formData;
                }
               
            })
        }
        
        function saveDocumentUpload(files, isSubmit){            
        	return $http({
                method: 'POST',
                url: 'UNEP/OrganizationInfo/saveDocumentUploads',                
                headers: {'Content-Type': undefined},
                transformRequest: function () {                	
               	 	var formData=new FormData();
               	    var tagging = [];
	               	for (var i = 0, len = files.length; i < len; i++) {

	               	 formData.append("file",files[i]);
	               	 if (typeof  files[i] !== 'undefined'){
	               	     tagging.push(files[++i]);	               	    
	               	   }
	                }
	               	
	               	formData.append("colTagging",tagging);
	               	formData.append("isSubmit", isSubmit)
                  return formData;
                }
               
            })
        }        
        
        function validateActiveUser(eventName){        	
            	return $http({
                    method: 'GET',
                    url: 'UNEP/OrganizationInfo/activeUser/' + eventName,
                })             
        }
        
        function getTrackingApplication(stageNo){
        	return $http({
                method: 'GET',
                url: 'UNEP/OrganizationInfo/trackApplication/' + stageNo,
            }) 
        }
        
        function getNewTrackApplication(orgId){
        	return $http({
                method: 'GET',
                url: 'UNEP/OrganizationInfo/getTrackApplication/' + orgId,
            }) 
        }
        
        function getAdditionalInfo(){
        	return $http({
                method: 'GET',
                url: 'UNEP/OrganizationInfo/getAdditionalInfo'                
            })  
        }
        
        function getAccreditationList(pagination){        	
        	return $http({
        		method: 'GET',
        		url: 'UNEP/OrganizationInfo/getAccreditationList',
        		params: pagination
        	})
        } 
        
        function getPrintPDFById(id){
        	return $http({
        		method: 'GET',
        		url: 'UNEP/OrganizationInfo/getPrintPDFById/' + id
        	})
        }
        
       
        
        function exportPDF(imgData,heigth){
        	
        	return $http({
                method: 'POST',
                url: 'UNEP/OrganizationInfo/export/pdf',
                data: imgData,
                params: {
                	heigth: heigth
                },
                responseType: 'arraybuffer'
            })
            
        }
        
        function download(document){
        	
        	return $http({
                method: 'POST',
                url: 'UNEP/OrganizationInfo/downloadFile',
                data: document,
                responseType: 'arraybuffer'
            })
        }
    }
})();