(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('OrganizationProfileController', OrganizationProfileController);

    OrganizationProfileController.$inject = ['OrganizationProfileServices','ValidationService','RegexPattern','Constants','$state',
                                             'vcRecaptchaService'];   
    
    function OrganizationProfileController(OrganizationProfileServices,ValidationService,RegexPattern,Constants,$state,
    		                                 vcRecaptchaService) {

        var vm = this;   
                        
        vm.SaveProfile = SaveProfile;
        vm.EmailPattern = RegexPattern.EmailPattern();        
        
        function SaveProfile(myForm){
        	if (ValidationService.isValid(myForm) == 0){
        		if (vcRecaptchaService.getResponse() !==''){
	        		OrganizationProfileServices.SaveProfile(vm.OrganizationProfile)
	                .then(function (result) {
	                	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
	                	$state.go('Login');
	                 })
	                .catch(function (error){
	                	ValidationService.showError(myForm); 
	                	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);   	
	               });        		
        		}
        		else{
        			ValidationService.showAlert('FAILED','Re Captcha verification failed', Constants.messageTypes.errorGritter);
        		}
    		}
        }
    }
    
})();


