(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('LunchComplainController', LunchComplainController);

    LunchComplainController.$inject = ['$uibModalInstance', 'TrackingApplicationService', 'ValidationService', 'Constants'];   
    
    function LunchComplainController($uibModalInstance, TrackingApplicationService, ValidationService, Constants) {

        var vm = this;   
        vm.message;
        
        //methods
        vm.closeModal=closeModal;
        vm.sendFollowup=sendFollowup;

        function sendFollowup(){
        	var content = CKEDITOR.instances.editor1.getData();
        	
        	TrackingApplicationService.sendFollowUp(content)
            .then(function (result) {
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
             })
            .catch(function(error){
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter); 
            })
        	.finally(function () {
        		closeModal();
            }); 
        }
        
        function closeModal() {
        	$uibModalInstance.close(false);
        }
    }
    
})();


