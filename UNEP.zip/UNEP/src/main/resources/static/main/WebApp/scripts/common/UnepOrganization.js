(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('UnepOrganization', UnepOrganization);

    UnepOrganization.$inject = ['$rootScope','$state','OrganizationInfoService'];

    function UnepOrganization($rootScope,$state,OrganizationInfoService) {

        var factory = {       		
                
        		initLandingPage:initLandingPage,
        		initPageTitle:initPageTitle,
        		pageTitle:pageTitle,
        		initValue:initValue,
        		setProfile:setProfile,
        		getCurrentState:getCurrentState,
        		readOnly:readOnly,
        		showElement:showElement,
        		getRoles:getRoles,
        		needApproval:needApproval
        };

        return factory;        
        
        function firstTimeLogin(){
	        $uibModal.open({
			     templateUrl: '/main/WebApp/app/credentials/changepassword/ChangePassword.html',
				  backdrop: 'static',
				  keyboard: false,			
		          controller:'ChangePasswordController',
		          controllerAs: 'vmChangePassword'
			  }).result.then(function () {				     
				  
			  })
        }
        
        function initLandingPage(){        	
        	 OrganizationInfoService.validateActiveUser()
             .then(function (result) {            	 
            	if ( result.data.authenticationData.organizationProfile !=null){
            		$state.go('Organization');
            	}
            	else{$state.go('Dashboard');}
             });     
        	 
        }
        
        function setProfile(result){
        	if ( result.data.authenticationData.organizationProfile !=null){
	        	 $rootScope.orgProfile= result.data.authenticationData.organizationProfile;
	        	 $rootScope.currentUser= result.data.authenticationData.organizationProfile.name;
	        	 $rootScope.orgID=result.data.authenticationData.organizationProfile.id;
	        	 $rootScope.trackingAppInfo=result.data.trackingAppInfo;
        	}
        	
        	if (result.data.authenticationData.users !=null){
        		$rootScope.userInfo=result.data.authenticationData.users;
        		$rootScope.currentUser= result.data.authenticationData.users.name;
        	}
        }
        function initValue(Organization,DropdownList){
        	
        	 $rootScope.Organization = Organization.data;
             $rootScope.orgProfile = Organization.data.orgProfile;
             $rootScope.trackingAppInfo = Organization.data.trackingApplication;
             $rootScope.internationalScopeInfo = $rootScope.Organization.internationalScopeInfo;
             $rootScope.additionalInfo =$rootScope.Organization.additionalInfo;
             $rootScope.countryList=DropdownList.data.country;
             $rootScope.companyCategory=DropdownList.data.companyCategory;                   

             if (Organization.data.users !=null){
               $rootScope.userInfo=Organization.data.users;
             }
        }
        
        function initPageTitle(title){
        	$rootScope.titlePage=title;
        }
        
        function getCurrentState(){
        	return $state.current.name;
        }
        
        function readOnly(){
        	
        	switch ($state.current.name.toUpperCase()){
        	     case "ACCREDITATIONBYORG":        	    	   
        		 return true;
        		 default:
        			 return false;
        	}     
        }
        
       function pageTitle(){
        	
        	switch ($state.current.name.toUpperCase()){
        	     case "USERS":        
        	    	 $rootScope.titlePage='User Maintenance';        	    	
        		 return true;
        		 
        	     case "ORGANIZATION":        
        	    	 $rootScope.titlePage='Quadrennial';        	    	
        		 return true;
        		 
        	     case "DASHBOARD":        
        	    	 $rootScope.titlePage='Dashboard';        	    	
        		 return true;
        		 
        	     case "ACCREDITATIONBYORG":        
        	    	 $rootScope.titlePage='Quadrennial';        	    	
        		 return true;
        		 
        	     case "ACCREDITATIONLIST":        
        	    	 $rootScope.titlePage='Accreditation List';        	    	
        		 return true;
        		 default:
        			 return false;
        	}     
        }

         function showElement(){
        	if ($rootScope.userInfo !=null){
	        	if ($rootScope.userInfo.roles.id === 2 && $rootScope.trackingAppInfo.stageNo >1){        		
	         		return false;
	         	}
	        	 
	        	if ($rootScope.userInfo.roles.id === 3 && $rootScope.trackingAppInfo.stageNo >2){        		
	        		return false;
	        	}
	        	
	        	if ($rootScope.userInfo.roles.id === 4 && $rootScope.trackingAppInfo.stageNo <3){        		;
	        		return false;
	        	}
        	}
        	return true;
        } 
         
         function getRoles(){
        	 
        	 if ($rootScope.userInfo !=null){
        	    return $rootScope.userInfo.roles;
        	  }
        	 return null;
         }
        
        function needApproval(){
        	
        	if ($rootScope.trackingAppInfo !=null && $rootScope.userInfo !=null){
        		if (($rootScope.userInfo.roles.id === 3 || $rootScope.userInfo.roles.id === 4) 
        			 && $rootScope.trackingAppInfo.stageNo >=3 
        			 && $rootScope.trackingAppInfo.status =='APPROVED'){
        			return true;
        		}
        	}
        	
        	return false;
        }
    }

})();
