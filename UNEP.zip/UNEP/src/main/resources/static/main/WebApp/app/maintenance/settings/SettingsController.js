(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('SettingsController', SettingsController);

    SettingsController.$inject = ['settingData','SettingsService','Pagination','ValidationService',
    	'DropdownService','ModalService','$uibModal','Constants'];   
    
    function SettingsController(settingData,SettingsService,Pagination,ValidationService,
    		DropdownService,ModalService,$uibModal,Constants) {

        var vm = this;   
        
        vm.maintenanceType=maintenanceType;
        vm.newSettings =newSettings;
        vm.settingList=settingData.data.setting;
        vm.totalRows = settingData.data.settingCount;      
        vm.pagination = Pagination.initPage(vm.pagination,vm.totalRows,'5');
        vm.pageChanged=pageChanged;
        vm.search = search
        vm.setPager=setPager;
        vm.remove=remove;
            
        maintenanceType(0);
        function maintenanceType(id){
        	vm.maintenanceId = id;
        	vm.pagination.currentPage =1;
        	pageChanged();
        }
        
        function setPager(e){
      	  
       	 var code = e.keyCode || e.which;
           	
          	 if(code == 13) {       
          		 if(vm.CurrentPage > vm.totalPages){
          			 return;
          		 }
          		 pageChanged();
          	 }
         }
               
        function search(e){
          	var code = e.keyCode || e.which;
          	vm.pagination.currentPage=1;
          	 if(code == 13) {
          		 pageChanged();
          	 }
          }
        
        function pageChanged(){
      	  vm.pagination = Pagination.initPage(vm.pagination);
      	  refresh();
      	  
        }
        function refresh(){
        	SettingsService.getSettings(vm.pagination,vm.maintenanceId)
            .then(function (result) {          	
          	  vm.settingList=result.data.setting;
              vm.pagination.totalRows = result.data.settingCount;
              vm.pagination = Pagination.initPage(vm.pagination);
             }) .catch(function (error){
             	
            });  
        }
       
        function newSettings(item){        	 
       	 $uibModal.open({
			     templateUrl: '/main/WebApp/app/maintenance/settings/NewSettings.html',
				  backdrop: 'static',
				  keyboard: false,			
		          controller:'NewSettingsController',
		          controllerAs: 'vmNewSettings',
		          resolve: {		                           
		        	  mainType: function () {	                     
	                       return {'data':vm.maintenanceId,item };
	                   }
		          } 
			  }).result.catch(function (result) {				     
				  if(result.toLowerCase() == 'closed'){
					  pageChanged();  
				  }
			  })		  
        }
        
        function updateSetting(id){        	
        	SettingsService.updateSettings(id,vm.maintenanceId)
              .then(function (result) {
              	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
               })
              .catch(function(error){
              	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
             });         	
          }
        
        function remove(item){
          	ModalService.removeItems('Remove','Are you sure you want to remove' + ' "' +item.name +'"?')
          	.then(function (result) { 
          		  if (result.toUpperCase() ==='YES'){
          			  updateSetting(item.id);
          			  pageChanged();
          		  }
              	}, function () {
              	  
              });
          } 
        
    }
    
})();


