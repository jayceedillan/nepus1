(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('DocumentUploadController', DocumentUploadController);

    DocumentUploadController.$inject = ['$rootScope','$q','OrganizationInfoService','ValidationService','Constants','UnepOrganization'];   
    
    function DocumentUploadController($rootScope,$q,OrganizationInfoService,ValidationService,Constants,UnepOrganization) {

        var vm = this;   
        vm.organization = $rootScope.Organization;
        vm.others1;
        vm.others2;
        
        vm.uploadFiles = uploadFiles;
        vm.isSaving=false;
        vm.readOnly = UnepOrganization.readOnly();
        vm.downloadFile=downloadFile;
        
        onInit();
        
        function onInit(){
        	if (vm.organization.documentsOthers.length !=0){
        		if (vm.organization.documentsOthers.length !=1){
        			vm.others1=vm.organization.documentsOthers[0].name;
        			vm.others2=vm.organization.documentsOthers[1].name;
        		}
        		else{
        			vm.others1=vm.organization.documentsOthers[0].name;
        		}
        	}
        }
        
        function uploadFiles(saveNext){   
        	vm.isSaving=true;
        	loadFiles();
        	OrganizationInfoService.saveDocumentUpload(vm.files, saveNext)
            .then(function (result) {
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
            	vm.isSaving=false;
            	getOrganizationInfo();
            	if (saveNext){            		
            		showTracksApp($rootScope.orgProfile.id);
            	}
             })
            .catch(function(error){
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
            	vm.isSaving=false;
           }); 
        	
        }
        
        function loadFiles(){
        	vm.files=[];
        	
        	if (vm.constitution !== undefined){
        		vm.files.push(vm.constitution,'constitution');} 
        	
        	if (vm.audit !== undefined){
        		vm.files.push(vm.audit,'audit');} 
        	
        	if (vm.anyOther1 !== undefined){
        		vm.files.push(vm.anyOther1,'other1');} 
        	
        	if (vm.anyOther2 !== undefined){
        		vm.files.push(vm.anyOther2,'other2');} 
        	
        }
        
        function showTracksApp(orgId){        
        	
        	OrganizationInfoService.getNewTrackApplication(orgId)
            .then(function (result) {
            	if (result.data.trackingAppInfo !=null){
            		$rootScope.wizardsId =4;
            		$rootScope.trackingAppInfo =result.data.trackingAppInfo;
            	}
            	else{ValidationService.showAlert('Warning',Constants.messageTypes.wizardsWarning, Constants.messageTypes.errorWarning);}
             })
            .catch(function(error){
            	ValidationService.showAlert(result.data.header,result.data.error, Constants.messageTypes.errorGritter); 
           }); 	
        }
        
        function downloadFile(id, type, name){
        	var document = {
        		id: id,
        		type: type,
        		name: name
        	}
        	
        	var deferred = $q.defer();
        	
        	OrganizationInfoService.download(document)
            .then(function (result) {
                console.log(result);

                var type = result.headers('Content-Type');

                var blob = new Blob([result.data], {
                    type: type
                });

                saveAs(blob, document.name);
                deferred.resolve(document.name);
              
            })
            .catch(function (error) {
                deferred.reject(error.data);
            })
        }
        
        function getOrganizationInfo(){
        	OrganizationInfoService.getOrganizationInfo()
            .then(function (result) {
            	vm.organization = result.data;
            	onInit();
             })
            .catch(function(error){            	
            	ValidationService.showAlert(result.data.header,result.data.error, Constants.messageTypes.errorGritter);
            });
        }
    }
    
})();


