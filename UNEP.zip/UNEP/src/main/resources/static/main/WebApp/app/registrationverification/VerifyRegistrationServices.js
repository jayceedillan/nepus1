(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('VerifyRegistrationServices', VerifyRegistrationServices);

    VerifyRegistrationServices.$inject = ['$http'];

    function VerifyRegistrationServices($http) {
        var factory = {
        		verify:verify
        };

        return factory;
                
        function verify(code) {
            return $http({
                method: 'GET',
                url: 'UNEP/OrganizationProfile/verify',
                params: {code: code}
            })
        }
    }
})();