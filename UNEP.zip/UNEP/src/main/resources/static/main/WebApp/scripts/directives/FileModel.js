app.directive('fileModel', ['$parse','Constants','ValidationService', function ($parse,Constants,ValidationService) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function(){
            	
            	if (!(/\.(pdf|jpg|jpeg|doc|docx|png)$/i).test(element[0].files[0].name)) {
                	ValidationService.showAlert('FAILED','Invalid file type: ' + element[0].files[0].name+ '.  Please use DOC, PDF, JPG or PNG.', Constants.messageTypes.errorGritter);                	
                	return;
            	    }
            	else if (element[0].files[0].size >=5242880){
            		ValidationService.showAlert('FAILED','File size is too large.', Constants.messageTypes.errorGritter);                	
                	return;            	    
            	}
            	else{
	                scope.$apply(function(){
	                    modelSetter(scope, element[0].files[0]);
	                });
            	}
            });
        }
    };
}]);