(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('PdfController', PdfController);

    PdfController.$inject = ['$rootScope','$stateParams','$state','Organization','$q','ValidationService','OrganizationInfoService','Constants',
                             'UnepOrganization'];   
    
    function PdfController($rootScope,$stateParams,$state,Organization,$q,ValidationService,OrganizationInfoService,Constants,
            UnepOrganization) {

        var vm = this;
        vm.exportReportToPDF=exportReportToPDF;       
        vm.getLimits=getLimits;
        vm.home=home;
        onInit()
        
        function onInit(){
        	 getInfo();
        	
        }
        
        function getInfo(){       	
        	
        	vm.organization= Organization.data;            
        	vm.organizationInfo= vm.organization.organizationInfo;
        	vm.orgProfile= vm.organization.orgProfile;
        	vm.InternalScope=vm.organization.internationalScopeInfo;
        	vm.geographicalList= vm.InternalScope.geographicalScope;
            vm.areasOfExpertise=vm.InternalScope.areasOfExpertise;
            vm.crossCutttingAreas=vm.InternalScope.crossCuttingAreas;
            
            vm.isnetworkmember1 =vm.organization.additionalInfo.isnetworkmember1 == false ? 'No' : 'Yes';
            vm.isnetworkmember2 =vm.organization.additionalInfo.isnetworkmember2 == false ? 'No' : 'Yes';
            processOthersDocs();
            getProfileLogo(vm.orgProfile.id);
    	}
        
        function getProfileLogo(id){
    		OrganizationInfoService.getProfilePics(id)
            .then(function (result) {
                  vm.profileImage  =result.data.baseImage64            
             });    
    		
    	}
        
        function processOthersDocs(){
        	if (vm.organization.documentsOthers.length !=0){
        		if (vm.organization.documentsOthers.length !=1){
        			vm.others1=vm.organization.documentsOthers[0].name;
        			vm.others2=vm.organization.documentsOthers[1].name;
        		}
        		else{
        			vm.others1=vm.organization.documentsOthers[0].name;
        		}
        	}
        }
        
//       function generatePDF(){ 
//    	
//    	
//    	//getDropdownChoices();
//    	
//    	
//    	
//    	
//    	function getDropdownChoices(){
//    		DropdownService.getDropdownOrg()
//            .then(function (result) {
//            	vm.dropdown= result.data;
//            	vm.countryList =vm.dropdown.country;
//                vm.companyCategory=vm.dropdown.companyCategory;
//                vm.majorGroupList =vm.dropdown.majorGroup; 
//             })
//            .catch(function(error){
//            	
//           }); 
//    	}
//    	
//    	function processPDF(){
//    		var rep = angular.element('#pdfRep');	
//    		var doc = new jsPDF('l', 'mm', 'a4');
//        	
//        	html2canvas(rep, {
//        		onrendered: function (orgTabCanvas){
//        			var img = orgTabCanvas.toDataURL("image/png");
//        			doc.addImage(img, 'PNG', 0, 0, doc.internal.pageSize.width, orgTabCanvas.height * doc.internal.pageSize.width /  orgTabCanvas.width, '', 'FAST');
//        			doc.save('test.pdf');
//        		}
//        			
//        	});
//        	
//    	}	
//       }

        
        function processPDF(){
    		var rep = angular.element('#pdfRep');	
    		var doc = new jsPDF('l', 'mm', 'a4');
        	
        	html2canvas(rep, {
        		onrendered: function (orgTabCanvas){
        			var img = orgTabCanvas.toDataURL("image/png");
        			doc.addImage(img, 'PNG', 0, 0, doc.internal.pageSize.width, orgTabCanvas.height * doc.internal.pageSize.width /  orgTabCanvas.width, '', 'FAST');
        			doc.save('test.pdf');
        		}
        			
        	});
        	
    	}	
        
        
        function exportReportToPDF(){
            exportReportToPDFs();        	
        }
        

       
       function exportReportToPDFs() {
//    	   var report_section = angular.element('#divPDF');
//    	   html2canvas(report_section, {
//               onrendered: function (canvas) {
//                   var imgData = canvas.toDataURL("image/png");                  
//                   var doc = new jsPDF();
//                   doc.addImage(imgData,'JEPG',20,20)
//                   doc.save('test.pdf');
//               }
//           });
//    	   
//    	   
//    	   return;
    	   
    	   var deferred = $q.defer();

           var report_section = angular.element('#content');
           var divHeight = report_section.height();
           var divWidth = report_section.width();
           
           html2canvas(report_section, {
               onrendered: function (canvas) {
                   var imgData = canvas.toDataURL();                   
                   OrganizationInfoService.exportPDF(imgData,divHeight)
                       .then(function (result) {
                           console.log("EXPORT TO PDF SUCCESS");
                           console.log(result);

                           var type = result.headers('Content-Type');
                           var disposition = result.headers('Content-Disposition');
                           var defaultFileName = "";

                           if (disposition) {
                               var match = disposition.match(/.*filename="?([^;"]+)"?.*/);
                               if (match[1])
                                   defaultFileName = match[1];
                           }

                           defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');

                           var blob = new Blob([result.data], {
                               type: type
                           });

                           saveAs(blob, defaultFileName);
                           deferred.resolve(defaultFileName);
                         
                       })
                       .catch(function (error) {
                           deferred.reject(error.data);
                       })
                       .finally(function () {                        
                       });                  
               }
           });

           return deferred.promise;       
       }    
       
       function getLimits (array){
    	
    	  if ( angular.isUndefined(array)){
    		  return 0;
    	  }
    	    
    		   return    [Math.floor(array.length / 2) , -Math.floor(array.length / 2)]; 	
        }
           
       function home(){        	 
    	   if ($rootScope.userInfo !=null){    		   
    		   $state.go('AccreditationByOrg',{id:$stateParams.id});
    		   return;
    	   }
    	   
    	   $state.go('Organization');
       }
    }
    
})();


