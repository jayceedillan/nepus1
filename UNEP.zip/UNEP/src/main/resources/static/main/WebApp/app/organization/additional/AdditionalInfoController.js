(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('AdditionalInfoController', AdditionalInfoController);

    AdditionalInfoController.$inject = ['$rootScope','$scope', '$q', 'MultiSelectService','OrganizationInfoService','ValidationService',
    	                                'Constants','UnepOrganization'];   
    
    function AdditionalInfoController($rootScope,$scope,$q,MultiSelectService,OrganizationInfoService,ValidationService,
    		                          Constants,UnepOrganization) {

        var vm = this;
        vm.countryList =$rootScope.countryList;
        vm.companyCategory=$rootScope.companyCategory;
        vm.additionalInfo= $rootScope.additionalInfo;
        vm.fundsource;
        vm.document1;
        vm.document2;
        
        vm.clickOthers =clickOthers;
        vm.change= change;
        vm.isSaving=false;
        vm.save=save;
        vm.readOnly = UnepOrganization.readOnly();
        vm.downloadFile = downloadFile;
        
        onInit();
        function onInit(){ 
        	if ($rootScope.additionalInfo.id !=0){
		        vm.additionalInfo.registrationdate = new Date(vm.additionalInfo.registrationdate);
        	  }
        	 else{vm.additionalInfo.registrationdate = new Date();}
        	    vm.isnetworkmember1 = vm.additionalInfo.isnetworkmember1 ==false ? '1' : '0';
		        vm.isnetworkmember2 = vm.additionalInfo.isnetworkmember2 ==false ? '1' : '0';
		        
		        vm.explain1 =vm.isnetworkmember1 == '0' ? true : false;
		        vm.explain2 =vm.isnetworkmember2 == '0' ? true : false;
		        
		        vm.options1 = MultiSelectService.addOptions();
		        vm.options2 = MultiSelectService.addOptions();
		        
		        vm.isnetworkmember1 =  MultiSelectService.twoSelected(vm.isnetworkmember1);
		        vm.isnetworkmember2 =  MultiSelectService.twoSelected(vm.isnetworkmember2);
		        
		        vm.fundsource = vm.additionalInfo.fundsource;
		        vm.document1 = vm.additionalInfo.document1;
		        vm.document2 = vm.additionalInfo.document2;
		        
		        clickOthers(vm.additionalInfo.companyCategory);
        }
        
        function clickOthers(items){
        	if (items !=null){
	    	   vm.enableOthers= false;
	       	   if (items.name.toUpperCase() === 'OTHER' ){
	       		  vm.enableOthers= true;
	       	   }else{vm.additionalInfo.companycategoryother='';}
        	}
        }
        
        function change(item, type){        	
        	
        	if (type === 0){
        		vm.explain1 =false;
        		if(item.id ==='0' && type === 0){
            		vm.explain1 =true;            		
            	}	else{vm.additionalInfo.remarks1 ='';}
        	}
        	
        	if (type === 1){
        		vm.explain2 =false;
        		if(item.id ==='0' && type === 1){
            		vm.explain2 =true;            		
            	}	
        		else{vm.additionalInfo.remarks2 ='';}
        	}
        }
        
        function save(myForm, saveNext){
        	vm.isSaving=true;
        	vm.NeedValidate=true;
        	
        	if (saveNext){
        		if (ValidationService.isValid(myForm) !=0){
        		 return;			
        		}
        	}	
        	
        	pushFiles();
        	
 	        vm.additionalInfo.isnetworkmember1 =  processNetWork(vm.isnetworkmember1);
 	        vm.additionalInfo.isnetworkmember2 =  processNetWork(vm.isnetworkmember2);
 	        
 	        if (vm.sourceFile!= undefined){
 	        	vm.additionalInfo.fundsource = vm.sourceFile.name;
 	        } else if (vm.fundsource){
 	        	vm.additionalInfo.fundsource = vm.fundsource; 
 	        } else {
 	        	vm.additionalInfo.fundsource = '';
 	        }
 	        
 	       if (vm.network1File!= undefined){
 	    	   vm.additionalInfo.document1 = vm.network1File.name;
	       } else if (vm.document1){
	    	   vm.additionalInfo.document1 = vm.document1; 
	       } else {
	    	   vm.additionalInfo.document1 = '';
	       }
 	       
 	       if (vm.network2File!= undefined){
	    	   vm.additionalInfo.document2 = vm.network2File.name;
	       } else if (vm.document2){
	    	   vm.additionalInfo.document2 = vm.document2; 
	       } else {
	    	   vm.additionalInfo.document2 = '';
	       }
// 	        vm.additionalInfo.fundsource = vm.sourceFile== undefined ? '' : vm.sourceFile.name; 
// 	        vm.additionalInfo.document1 = vm.network1File== undefined ? '' : vm.network1File.name;
// 	        vm.additionalInfo.document2 = vm.network2File== undefined ? '' : vm.network2File.name;
 	       
        	OrganizationInfoService.saveAdditionalInfo(vm.files,vm.additionalInfo)
            .then(function (result) {
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
            	if (saveNext){
            		getAdditionalInfo();
            		$rootScope.wizardsId =3;
             	}
            	vm.isSaving=false;
            	
             })
            .catch(function(error){
            	vm.isSaving=false;
            	ValidationService.showAlert(result.data.header,result.data.error, Constants.messageTypes.errorGritter);
           });

        }
        
        function getAdditionalInfo(){        	
        	OrganizationInfoService.getAdditionalInfo()
            .then(function (result) {
            	$rootScope.additionalInfo = result.data.additionalInfo;            	
             })
            .catch(function(error){            	
            	ValidationService.showAlert(result.data.header,result.data.error, Constants.messageTypes.errorGritter);
           });
        }
        
        function pushFiles(){
        	vm.files=[];
        	vm.files.push(vm.sourceFile);
        	vm.files.push(vm.network1File);
        	vm.files.push(vm.network2File);
        }
        
        function processNetWork(items){
        	
        	if (items.id === "1"){
        		return false;
        	}        	
        	return true;
        }
        
        function downloadFile(id, type, name){
        	var document = {
        		id: id,
        		type: type,
        		name: name
        	}
        	
        	var deferred = $q.defer();
        	
        	OrganizationInfoService.download(document)
            .then(function (result) {
                console.log(result);

                var type = result.headers('Content-Type');

                var blob = new Blob([result.data], {
                    type: type
                });

                saveAs(blob, document.name);
                deferred.resolve(document.name);
              
            })
            .catch(function (error) {
                deferred.reject(error.data);
            })
        }
    }
    
})();


