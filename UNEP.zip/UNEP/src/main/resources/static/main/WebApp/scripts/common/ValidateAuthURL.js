(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('ValidateAuthURL', ValidateAuthURL);

    ValidateAuthURL.$inject = ['$location'];

    function ValidateAuthURL($location) {

        var factory = {
        		authorizationURL:authorizationURL
        		
        };

        return factory;

        function authorizationURL(){        	
            
        	if ($location.absUrl().toString().indexOf('Login') > -1 
        		|| $location.absUrl().toString().indexOf('Register') > -1
        		|| $location.absUrl().toString().indexOf('VerifyRegistration') > -1
        		|| $location.absUrl().toString().indexOf('ForgotPassword') > -1        		
        		){
        		return true;
        	}
            return false; 
        }
    }

})();
