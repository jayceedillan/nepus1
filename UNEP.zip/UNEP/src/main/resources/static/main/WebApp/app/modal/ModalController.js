(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('ModalController', ModalController);
   
    ModalController.$inject = ['customMessage','$uibModalInstance'];
    function ModalController(customMessage,$uibModalInstance) {
    	
    	var vm = this;  	
    	
        vm.No = No;
        vm.Yes = Yes;
        vm.Header = customMessage.data;
        vm.Message =customMessage.message;        
        
        function Yes(){
        	$uibModalInstance.dismiss('Yes');
        }
        
        function No(){
        	$uibModalInstance.dismiss('No');
        }        
    }
})();
