app.constant(
	'Settings',
	{
		Types : {						
			majorGroup:'Major Groups',	
			hQ:'Headquarter Office',
			geoScope:'Geographical Scope of Activities',
			areasOfExpertise:'Areas of Expertise',
			crossCuttingAreas:'Cross Cutting Areas',
			countryOfReg:'Country of Registration',
			companyCategory:'Company Category',
			emailAddress:'Email Address'
			
		}
	});
