(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('CommunicationController', CommunicationController);

    CommunicationController.$inject = ['$stateParams','AccreditationProcessService','CommunicationService','ValidationService',
                                          'Constants','UnepOrganization'];   
    
    function CommunicationController($stateParams,AccreditationProcessService,CommunicationService,ValidationService,
    		                              Constants,UnepOrganization) {

        var vm = this;       
        vm.send=send;
        vm.show =UnepOrganization.showElement();
      //  onInit();
        
        function onInit(){        	
        	if ($stateParams.id != undefined){
	        	AccreditationProcessService.getDocumentList($stateParams.id)
	            .then(function (result) {           	
	                 vm.docList=result.data.docList.documentAttach;
	             });        	
        	}
        }
        
        function send(myForm, isReturn){  
        	
        	
        	if (ValidationService.isValid(myForm) ==0){
        		
        	}
        	var contentMessage = CKEDITOR.instances.editor2.getData();        	         	
        	
        	vm.files = [];
        	vm.files.push(vm.File);
        	
        	CommunicationService.saveCommunication(vm.files,contentMessage,vm.subject,$stateParams.id,isReturn)
            .then(function (result) {
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
             })
            .catch(function(error){
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter); 
           }); 
        }
    }
    
})();


