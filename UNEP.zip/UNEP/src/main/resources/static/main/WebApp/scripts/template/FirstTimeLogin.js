app.directive("firstTimeLogin", function() {
  return {
    restrict: "A",   
    templateUrl: "/main/WebApp/app/credentials/changepassword/FirstTimeLogin.html",
//    controller: 'FirstTimeLoginController',
//    controllerAs: 'vmFirstTimeLogin',
    replace:true,
 //   bindToController: true, //required in 1.3+ with controllerAs
  };
});