(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('MainOrganizationController', MainOrganizationController);

    MainOrganizationController.$inject = ['$state','$rootScope','LoginServices','$uibModal','ValidationService','Constants'];   
    
    function MainOrganizationController($state,$rootScope,LoginServices,$uibModal,ValidationService,Constants) {

        var vm = this;   
                
         vm.showMenu = showMenu;
         vm.showActive = false;
         vm.changePassword= changePassword;
         vm.logout = logout;
 
         function showMenu(){
        	 vm.showActive =vm.showActive == false ? true: false;
         }
        
         function changePassword(){        	 
        	 $uibModal.open({
			     templateUrl: '/main/WebApp/app/credentials/changepassword/ChangePassword.html',
				  backdrop: 'static',
				  keyboard: false,			
		          controller:'ChangePasswordController',
		          controllerAs: 'vmChangePassword'
			  }).result.then(function () {				     
				  
			  })			  
         }
         
         function logout(){        	 
        	 LoginServices.logout().then(function() 
        	  {
 			      $state.go('Login');
	           }).catch(function(error){         	    
              });
        	 
         }
    }
    
})();


