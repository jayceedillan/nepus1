(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('OrganizationInfoController', OrganizationInfoController);

    OrganizationInfoController.$inject = ['$rootScope','$state','$scope','Organization','DropdownList',
                                          'OrganizationInfoService', 'ValidationService','Constants','RegexPattern','UnepOrganization'];   
    
    function OrganizationInfoController($rootScope,$state,$scope,Organization,DropdownList,OrganizationInfoService,
    		                              ValidationService,Constants,RegexPattern,UnepOrganization) {

        var vm = this;   
        
        UnepOrganization.initValue(Organization,DropdownList);        
        vm.organizationInfo = $rootScope.Organization.organizationInfo;      
        vm.majorGroupList =DropdownList.data.majorGroup; 
        vm.countryList =DropdownList.data.country;
        vm.save=save;
        
        vm.readOnly = UnepOrganization.readOnly();
        UnepOrganization.pageTitle();
        onInit();
        function onInit(){        	
        	if ($rootScope.Organization.organizationInfo.id !=0){
	        	vm.fileName= vm.organizationInfo.logo;
	        	LoadLoad();
        	}
        }
        
        function LoadLoad(){
        	OrganizationInfoService.getProfilePics($rootScope.Organization.organizationInfo.organization_id)
            .then(function (result) {
            	vm.organizationInfo.profileImage  =result.data.baseImage64
             });                    	
        }          
                        
         $scope.ProfilePics = function(event) {
        	 
            var files = event.target.files;
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var reader = new FileReader();
                reader.onload = $scope.imageIsLoaded;
                reader.readAsDataURL(file);                
                vm.organizationInfo.logo= file.name;
            }        	
        }
        
        $scope.imageIsLoaded = function (e) {
        	$scope.$apply(function () {  	    	  
        		vm.organizationInfo.profileImage= e.target.result.replace(/^data:image\/[a-z]+;base64,/, "");        		
    		});
        }
        
        function save(myForm, saveNext){ 
              
        	vm.NeedValidate=true;;
        	vm.invalidURL=false;        
        		if (ValidationService.isValid(myForm) !=0){
        			var pattern =RegexPattern.URLPattern();
        			
//        			if (!RegexPattern.URLPattern().test(vm.organizationInfo.webSite)){
//        				 vm.invalidURL=true;
//        				 myForm.orgInfoWebSite.$invalid = true;
//        				 myForm.orgInfoWebSite.$setDirty();
//        			}

        		 return;			
        		}
        
        	
        	vm.organizationInfo.filesInfo={fileName:vm.organizationInfo.logo,
        			                       content:vm.organizationInfo.profileImage == undefined ? '' : vm.organizationInfo.profileImage} ;
        	
        	OrganizationInfoService.saveOrganizationInfo(vm.organizationInfo)
            .then(function (result) {
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);          
            	if (saveNext){
            		 $rootScope.wizardsId =1;}
             })
            .catch(function(error){
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter); 
           });        	
        }
    }
    
})();


