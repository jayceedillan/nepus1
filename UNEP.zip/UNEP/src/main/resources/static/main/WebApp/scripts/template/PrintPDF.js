app.directive("printPdfile", function() {
  return {
    restrict: "A",   
    templateUrl: "main/WebApp/app/organization/pdfform/PrintPDF.html",   
    replace:true,    
    bindToController: true,
   
  };
});