
(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .factory('stateHandler', stateHandler);

    stateHandler.$inject = ['$rootScope', '$state', '$window','OrganizationInfoService','ValidateAuthURL','$uibModalStack','UnepOrganization'];

    function stateHandler($rootScope, $state, $window,OrganizationInfoService,ValidateAuthURL,$uibModalStack,UnepOrganization) {
        
    	return {
            initialize: initialize
        };

        function initialize() {
            var stateChangeStart = $rootScope.$on('$stateChangeStart', function (event, toState, toParams) {
            	     
            	OrganizationInfoService.validateActiveUser(toState.name)
                 .then(function (result) {
                	 
                	 if (result.data.noPermission ==='401'){
                		// alert('xxx');
                		 return;
                	 }               	 
                
                	 UnepOrganization.setProfile(result);
                	 
                 }).catch(function(error){    
                	 if (error.data.error.toLocaleUpperCase() ==='UNAUTHORIZED'){ 
                		 if (!ValidateAuthURL.authorizationURL()){                			
                    	    $state.go('Login');                    		    
                    	 }
                	 }
                 });     
            });

            var stateChangeSuccess = $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams) {            	 
            	 $uibModalStack.dismissAll();
            });

            var stateChangeError =  $rootScope.$on('$stateChangeError', function(event, toState, toParams,  error){ 
            	 $uibModalStack.dismissAll();     
            });
            
            $rootScope.$on('$destroy', function () {
                if (angular.isDefined(stateChangeStart) && stateChangeStart !== null) {
                    stateChangeStart();
                }
                if (angular.isDefined(stateChangeSuccess) && stateChangeSuccess !== null) {
                    stateChangeSuccess();
                }
            });
            
          
            		
            

        }

    }

})();