(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('LoginController', LoginController);

    LoginController.$inject = ['LoginServices','ValidationService','ChangePasswordServices', '$state','Constants','UnepOrganization'];   
    
    function LoginController(LoginServices,ValidationService,ChangePasswordServices, $state,Constants,UnepOrganization) {

        var vm = this;
        
        vm.loginObj={};
        vm.firstTimeLogin = true;
        vm.login = login;      
        vm.changePassword=changePassword;
        function login(loginForm){
        	if (ValidationService.isValid(loginForm) == 0){    		  	
        		LoginServices.authenticate(vm.loginObj)
                .then(function (result) {     
                	processResults(result)
                 })
                .catch(function (error){                	  
                	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
               });        		
    		}
        }
        
        function processResults(result){
        
        	if (result.data.organizationProfile !=null){
        		if (result.data.organizationProfile.isTemporaryPassword == false){
        	        vm.firstTimeLogin =false;
        			return;
        		}
        	}
        	
        	else if (result.data.users !=null){
        		if (result.data.users.isTemporaryPassword == false){
        	        vm.firstTimeLogin =false;
        			return;
        		}
        	}
        	
        	UnepOrganization.initLandingPage();        	
        }
        
        function changePassword(changePasswordForm){
        	if (ValidationService.isValid(changePasswordForm) == 0){    		  	
        		ChangePasswordServices.changePassword(vm.oldPassword, vm.password, vm.confirmPassword, true)
                .then(function (result) {	
                	ValidationService.showAlert(result.data.header, result.data.success, Constants.messageTypes.successGritter);
                	UnepOrganization.initLandingPage();
                 })
                .catch(function (error){
                	ValidationService.showAlert(error.data.header, error.data.error, Constants.messageTypes.errorGritter); 
               });        		
    		}
        }
    }
    
})();


