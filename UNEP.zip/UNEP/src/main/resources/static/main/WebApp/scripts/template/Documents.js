app.directive("documentUpload", function() {
  return {
    restrict: "A",   
    templateUrl: "main/WebApp/app/organization/document/DocumentUpload.html",
    controller: 'DocumentUploadController',
    controllerAs: 'vmDocumentUpload',
    replace:true,
    bindToController: true, 
  };
});