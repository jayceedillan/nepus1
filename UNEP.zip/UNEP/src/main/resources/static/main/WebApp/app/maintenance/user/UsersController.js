(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('UsersController', UsersController);

    UsersController.$inject = ['UserList','$uibModal','UserService','ValidationService','DropdownService','ModalService','Pagination',
    	                       'Constants','UnepOrganization'];   
    
    function UsersController(UserList,$uibModal,UserService,ValidationService,DropdownService,ModalService,Pagination,
    		                   Constants,UnepOrganization) {

        var vm = this;   
                
      vm.addNewOrUpdateUser = addNewOrUpdateUser;
      vm.userList=UserList.data.users;
      vm.totalRows = UserList.data.usersCount;      
      vm.pagination = Pagination.initPage(vm.pagination,vm.totalRows,'10');
      vm.search = search        
      vm.remove=remove;
      vm.pageChanged=pageChanged;
      vm.refresh = refresh;
      vm.setPager=setPager;
      UnepOrganization.pageTitle();
      
      function setPager(e){
    	  
    	 var code = e.keyCode || e.which;
        	
       	 if(code == 13) {       
       		 if(vm.CurrentPage > vm.totalPages){
       			 return;
       		 }
       		 pageChanged();
       	 }
      }
      
      function search(e){
      	var code = e.keyCode || e.which;
      	
      	 if(code == 13) {         	  
      		 pageChanged();
      	 }
      }
      function addNewOrUpdateUser(id){        	
     	 $uibModal.open({
			     templateUrl: '/main/WebApp/app/maintenance/user/NewUser.html',
				 backdrop: 'static',
				 keyboard: false,			
		          controller:'NewUserController',
		          controllerAs: 'vmNewUser',
		          resolve: {
		              RoleList: ['DropdownService',
		                  function (DropdownService) {                 	      
		                      return DropdownService.getRole();
		                  }],
	                  users: ['UserService',
		                  function (UserService) {                 	      
		                      return UserService.getUserById(id);
		                  }]
		          } 
			  }).result.catch(function (result) {				     
				  if(result.toLowerCase() == 'closed'){
					  pageChanged();
					  }
			  })
			  
      }
      
      function remove(id){ 
      	ModalService.removeItems('Remove User','Are you sure you want to remove this user?')
      	.then(function (result) { 
      		  if (result.toUpperCase() ==='YES'){
      			  updateUser(id);
      			  pageChanged();
      		  }
          	}, function () {
          	  
          });
      }       
    
      function updateUser(id){        	
      	UserService.updateUser(id)
          .then(function (result) {
          	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
          	pageChanged();
           })
          .catch(function(error){
          	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter);
         });         	
      }
      
      function pageChanged(){
    	  vm.pagination = Pagination.initPage(vm.pagination);
    	  refresh();
    	  
    }
      function refresh(){
      	UserService.getUsers(vm.pagination)
          .then(function (result) {
        	vm.userList=result.data.users;
          	vm.pagination.totalRows = result.data.usersCount;
          	vm.pagination = Pagination.initPage(vm.pagination);
           }) .catch(function (error){
           	
          });  
      }
     
  }
})();


