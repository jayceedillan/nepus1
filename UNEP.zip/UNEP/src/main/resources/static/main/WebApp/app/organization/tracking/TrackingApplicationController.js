(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('TrackingApplicationController', TrackingApplicationController);

    TrackingApplicationController.$inject = ['$uibModal'];   
    
    function TrackingApplicationController($uibModal) {

        var vm = this;   
             
        vm.complain=complain;
        
        function complain(){
        	$uibModal.open({
			     templateUrl: '/main/WebApp/app/organization/tracking/complain/LunchComplain.html',
				  backdrop: 'static',
				  keyboard: false,
				  windowClass: 'modal-dialog-complain',
				  controller: 'LunchComplainController',
				  controllerAs: 'vmLunchComplain'
			  }).result.then(function () {				     
				  
			})		
        }
    }
    
})();


