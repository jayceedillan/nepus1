(function () {
    'use strict';

    angular
        .module('UNEP.AccreditationSystem')
        .controller('ApprovalController', ApprovalController);

    ApprovalController.$inject = ['$rootScope','$stateParams','CommunicationService','ValidationService',
                                   'Constants','UnepOrganization'];   
    
    function ApprovalController($rootScope,$stateParams,CommunicationService,ValidationService,
    		                    Constants,UnepOrganization) {

        var vm = this;
        
        vm.approved=approved;        
        vm.send=send;        
        vm.needApproval =UnepOrganization.needApproval();
        
        onInit();
        
        function onInit(){        	
            CommunicationService.getEmailDocs($stateParams.id)
            .then(function (result) {            	
              vm.emaildocs =result.data.emaildocs;
           });
           
            initApproval();
        }
        
       function initApproval(){
        	
        	if ($rootScope.userInfo !=null){
        		
        		if ( $rootScope.trackingAppInfo.stageNo ===1){
        			vm.disabledApproval =true;
        			return;
        		}
        		
        		if ($rootScope.userInfo.roles.id === 3){
        			 if ($rootScope.trackingAppInfo.stageNo >=3){
        				vm.disabledApproval =true;
             			return;	 
        			 }        			
        		}
        		
        		if ($rootScope.userInfo.roles.id === 4){
	       			 if ($rootScope.trackingAppInfo.stageNo ===4){
	       				 vm.disabledApproval =true;
	            		 return;	 
	       			 }        			
	       			 else if ($rootScope.trackingAppInfo.stageNo <=2){
	       				 vm.disabledApproval =true;
	            		 return;	 
	       			 }
       		   }
        		
//        		if ($rootScope.userInfo.roles.id ===4 &&  $rootScope.trackingAppInfo.stageNo >=3){
//        			vm.disabledApproval =true;
//        			return;
//        		}
//        		
//                if ($rootScope.userInfo.roles.id ===4 &&  ($rootScope.trackingAppInfo.stageNo ===3){
//        			
//        		}
        	}
        	
        	vm.disabledApproval =false;
        }
  
        function approved(isApproved){
        	
        	alert('xxx');
        	return;
        	if (angular.isUndefined(vm.remarks) || vm.remarks ==''){
            	ValidationService.showAlert('REQUIRED.','Please specify the valid remarks.', Constants.messageTypes.errorGritter);
            	return;
        	}
        	
        	CommunicationService.approved($stateParams.id,isApproved,vm.remarks)
            .then(function (result) {
            	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
             })
            .catch(function(error){
            	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter); 
           });
        }
        
        
        
        function send(myForm){
        	
        	var contentMessage = CKEDITOR.instances.editor3.getData();
        
        	
            if (ValidationService.isValid(myForm) ==0){
            	CommunicationService.returnOfficer($stateParams.id,vm.subject,contentMessage)
                .then(function (result) {
                	ValidationService.showAlert(result.data.header,result.data.success, Constants.messageTypes.successGritter);
                 })
                .catch(function(error){
                	ValidationService.showAlert(error.data.header,error.data.error, Constants.messageTypes.errorGritter); 
               });	
        	}     
        }     
    }
    
})();


